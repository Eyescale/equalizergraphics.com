import os
arch = "Darwin"
crdir = "/opt/tg/cr"
crbindir = os.path.join(crdir,'bin',arch)
crlibdir = os.path.join(crdir,'lib',arch)
