"""Utilities for parsing CEI's dconfig.* files."""

import os, re, sys
import pvcutil
from mothership import *


def _GetWallResolution(filename):
	"""Look for the 'wallresolution' line in the file and return the
	tuple (width, height)."""
	f = open(filename, "r")
	assert f
	pattern = "[ \t]*wallresolution ([0-9]+) ([0-9]+).*"

	while 1:
		line = f.readline()
		if not line:
			break
		m = re.match(pattern, line)
		if m:
			res = (int(m.group(1)), int(m.group(2)))
			f.close()
			return res

	f.close()
	return (0, 0)


def _GetScreens(filename):
	"""Parse the given dconfig.* file and return list of tuples
	of (hostid, displayid, (xorig, yorig), (xres, yres))."""
	screens = []
	hostid = ""
	displayid = ""
	wallorigin = [0, 0]
	resolution = [0, 0]

	f = open(filename, "r")
	assert f

	screenPattern = "[ \t]*screen.*"
	hostidPattern = "[ \t]*hostid (\S+).*"
	displayidPattern = "[ \t]*displayid (\S+).*"
	walloriginPattern = "[ \t]*wallorigin ([0-9]+) ([0-9]+).*"
	resolutionPattern = "[ \t]*resolution ([0-9]+) ([0-9]+).*"

	screenCount = 0

	while 1:
		line = f.readline()
		if not line:
			break

		# Parse the line
		m = re.match(screenPattern, line)
		if m:
			screenCount += 1
			if screenCount > 1:
				screens.append((hostid, displayid, wallorigin, resolution))
			continue

		m = re.match(hostidPattern, line)
		if m:
			hostid = m.group(1)
			continue

		m = re.match(displayidPattern, line)
		if m:
			displayid = m.group(1)
			continue

		m = re.match(walloriginPattern, line)
		if m:
			x = int(m.group(1))
			y = int(m.group(2))
			wallorigin = (x, y)
			continue

		m = re.match(resolutionPattern, line)
		if m:
			x = int(m.group(1))
			y = int(m.group(2))
			resolution = (x, y)
			continue

	# add last one to list
	screens.append((hostid, displayid, wallorigin, resolution))

	f.close()
	return screens


def ParseDConfigFile(filename):
	"""Parse the dconfig file to determine the image size, number of rendering
	nodes, hostnames, etc.
	Return a tuple (width, height, hostslist) with results."""

	# Make sure filename contains "dconfig"
	assert filename.find("dconfig") >= 0

	(width, height) = _GetWallResolution(filename)
	screens = _GetScreens(filename)
	assert len(screens) > 0
	hosts = []
	for (host, display, pos, size) in screens:
		hosts.append(host)
		(x, y) = pos
		(w, h) = size
		assert x == 0
		assert y == 0
		assert w == width
		assert h == height
	print "Verified: crconfig.last compatible with dconfig.last"
	return (width, height, hosts)



def ParsePRDistFile(filename):
	"""Parse the named prdist file to determine the number of rendering
	nodes, hostnames, etc.
	Return a tuple of ([hostslist], muralname, (winwidth, winheight))."""

	# Make sure filename contains "prdist"
	assert filename.find("prdist") >= 0

	f = open(filename, "r")
	assert f

	clientPattern = "^client\s+(\S+)[ \t]*"
	tgMuralPattern = "#TGmural\s+(\S+)"
	tgSizePattern = "#TGsize\s+(\d+)\s+(\d+)"

	clients = []
	muralfile = None
	width = 0
	height = 0

	while 1:
		line = f.readline()
		if not line:
			break

		# Parse the line
		m = re.match(clientPattern, line)
		if m:
			host = m.group(1)
			clients.append(host)
			continue

		m = re.match(tgMuralPattern, line)
		if m:
			muralfile = m.group(1)
			print "Found mural = %s" % muralfile
			continue

		m = re.match(tgSizePattern, line)
		if m:
			width = int(m.group(1))
			height = int(m.group(2))
			print "Found size = %d x %d" % (width, height)
			continue

	#endwhile

	f.close()
	return (clients, muralfile, (width, height))



# Global vars
DefaultWidth = 1280
DefaultHeight = 1024


def Log(msg):
	"""Log debug message"""
	return # turn off
	f = open("/tmp/mslog", "a")
	assert f
	f.write(msg)
	f.write("\n")
	f.close()


# NOTES:
# 1. This routine is called from prdist.tg and prdist.tgmural files.
# 2. This config file parses the prdist.tmp file to determine how many
#    rendering nodes to create (and on which hosts)
# 3. In mothership.py the DebugLevel MUST BE 1.  Otherwise, ensight8
#    won't autostart the remote rendering processes.
def StartEnsightSortLastConfig(prdistFile):
	"""Start a cr config for sort last rendering with CEI Ensight.
	prdistFile describes how many nodes to render on, their hostnames, etc."""

	Log("ARGV=%s" % str(sys.argv))

	# Constants (generally don't touch these)
	Program = 'ensight8.client' # Not really significant
	CompositeSPU = "tgcomp"   # Either "tgcomp", "readback" or "binaryswap"
	Resizable = 0
	UsePbuffers = 1
	AutoStart = 0

	pvcutil.ModuleInit()

	# Parse the prdist file to determine how many rendering nodes, hosts, etc.
	(slaveHosts, muralFilename, windowSize) = ParsePRDistFile(prdistFile)
	Log("prdist.tg.config found hosts: %s" % str(slaveHosts))
	numSlaveNodes = len(slaveHosts)
	assert(numSlaveNodes > 1)

	Log('numSlaveNodes=%d' % numSlaveNodes)

	# Get some cluster information
	cluster = pvcutil.GetClusterConfiguration()
	protocol = cluster['Protocol']
	shell = cluster['Shell']
	shellOpts = cluster['ShellOptions']

	# On which host are we running?
	localHost = pvcutil.GetHostname()

	# Get screen information and overall width, height
	if muralFilename:
		screens = pvcutil.ParseDMXConfigFile(muralFilename)
		if screens:
			(width, height) = pvcutil.ComputeMuralSize(screens)
	else:
		screens = None
		(width, height) = windowSize
		if width == 0:
			width = DefaultWidth
		if height == 0:
			height = DefaultHeight

	# Choose port for server communication
	serverPort = pvcutil.AllocatePort()

	# Mothership URL
	mothershipURL = localHost + ":" + str(DefaultMothershipPort)

	# Create mothership instance
	cr = CR()
	cr.MTU(16*1024*1024) ### check on this


	#
	# Set up the network/display nodes
	#
	networkNodes = []
	if screens:

		# Create the tile/screen crservers with render SPUs
		for index in range(len(screens)):
			tile = screens[index]
			tileHost = tile['display'].split(':')[0]
			tileHost = string.replace(tileHost, "sdp", "")

			Log("Creating crserver %d on %s" % (index, tileHost))

			tx = tile['xorigin']
			ty = tile['yorigin']
			tw = tile['width']
			th = tile['height']

			netnode = CRNetworkNode(tileHost)
			netnode.AddTile(tx, ty, tw, th)
			#netnode.Conf('use_dmx', 1)
			netnode.Conf('optimize_bucket', 1)
			netnode.Conf('shared_windows', 1)
			netnode.Conf('only_swap_once', 0) # XXX why zero?
			netnode.Conf('debug_barriers', 0)

			renderspu = SPU('render')
			renderspu.Conf('display_string', ':0')
			#renderspu.Conf('render_to_app_window', 1)
			renderspu.Conf('title', "Chromium Render SPU %d" % index)
			renderspu.Conf('window_geometry', [0, 0, tw, th])
			renderspu.Conf('borderless', 1)
			netnode.AddSPU(renderspu)

			# XXX this is for debug only!
			if AutoStart:
				Log("Starting crserver on %s" % tileHost)
				env = "LD_LIBRARY_PATH=" + crlibdir + " PATH=" + pvcutil.GetCurrentPath()
				prog = crbindir + "/crserver -mothership " + mothershipURL
				cmd = "/bin/sh -c '" + env + " " + prog + "'"
				pvcutil.Autostart(netnode, [shell, shellOpts, tileHost, cmd])
									
				# If you want to run locally with /bin/sh, try this:
				#Autostart(netnode, ["/bin/sh", "-c", env + " " + prog])

			cr.AddNode(netnode)
			networkNodes.append(netnode)
		#endfor
	else:
		# Just rendering to a single screen, no tiling.
		netnode = CRNetworkNode(localHost)
		netnode.Conf('only_swap_once', 0)
		netnode.Conf('shared_windows', 1)
		renderspu = SPU('render')
		renderspu.Conf('window_geometry', [100, 100, width, height])
		renderspu.Conf('display_string', ':0')
		renderspu.Conf('resizable', Resizable)
		renderspu.Conf('title', 'Final Composited Result window')
		netnode.AddSPU(renderspu)

		cr.AddNode(netnode)
		networkNodes.append(netnode)
	#endif

	compositingMode = 'depth'

	# make the peers string needed for SPU configuration
	peers = pvcutil.GeneratePeersString(slaveHosts[0:numSlaveNodes], protocol)

	# Set up the slave/rendering/application nodes
	for i in range(numSlaveNodes):

		appnode = CRApplicationNode(slaveHosts[i])
		appnode.Conf('force_pbuffers', UsePbuffers)
		appnode.SetApplication(Program)
		#appnode.StartDir(Directory)

		# Create/configure the application SPU (binaryswap, readback or tgrb)
		appspu = SPU(CompositeSPU)
		if CompositeSPU == 'binaryswap' or CompositeSPU == "tgcomp":
			appspu.Conf('title', '%s SPU %d' % (CompositeSPU, i))
			appspu.Conf('type', compositingMode)
			appspu.Conf('peers', peers)
			appspu.Conf('node_number', i)
			appspu.Conf('composite_method', 'software')
			if screens:
				appspu.Conf('display_method', 'drawpixels')
			else:
				appspu.Conf('display_method', 'texture')

			appspu.Conf('window_geometry', [0, 0, width, height])
		else:
			assert CompositeSPU == 'readback'
			appspu.Conf('title', 'Readback SPU %d' % i)
			if compositingMode == 'depth':
				appspu.Conf('extract_depth', 1)
			elif compositingMode == 'alpha':
				appspu.Conf('extract_alpha', 1)
			appspu.Conf('window_geometry', [0, 0, width, height])
			appspu.Conf('use_glxchoosevisual', 1)
			appspu.Conf('resizable', Resizable)
		#endif

		# TEMP-DEBUG
		#appspu.Conf('system_gl_path', "/home/demo/brian/cvs/Mesa-32/lib")

		#appspu.Conf('ignore_window_moves', 1)
		appspu.Conf('display_string', ':0')
		appspu.Conf('pbuffer_size', [width, height])
		appnode.AddSPU(appspu)

		if screens:
			# many-to-many
			tilesortspu = SPU('tilesort')
			###tilesortspu.Conf('bucket_mode', 'Non-Uniform Grid')
			tilesortspu.Conf('bucket_mode', 'Uniform Grid')
			###tilesortspu.Conf('display_string', Display)
			tilesortspu.Conf('lazy_send_dlists', 0)
			tilesortspu.Conf('dlist_state_tracking', 0)
			###tilesortspu.Conf('use_dmx', 1)
			###tilesortspu.Conf('retile_on_resize', 1)
			###tilesortspu.Conf('render_to_crut_window', 1)
			###tilesortspu.Conf('track_window_position', 1)
			tilesortspu.Conf('fake_window_dims', [100, 100])
			appnode.AddSPU(tilesortspu)
			for server in networkNodes:
				tilesortspu.AddServer(server, protocol, serverPort)
		else:
			# many-to-one
			packspu = SPU('pack')
			#packspu.Conf('single_thread', 1)
			packspu.AddServer(networkNodes[0], protocol, serverPort)
			appnode.AddSPU(packspu)
		#endif

		cr.AddNode(appnode)

	#endfor i

	Log("cr.Go!!!")
	cr.Go()
#enddef
