# Utility functions used by the various TVC configs.
# The various many-to-foo-bar.conf, etc. files are just simple
# scripts which use these functions to do all the real work.


import string, sys, os, socket, random
from mothership import *

LOCAL_CLUSTER_CONFIG_FILE = os.getenv("HOME") + "/.cr/cluster"
GLOBAL_CLUSTER_CONFIG_FILE = os.getenv("TG") + "/configs/cluster"


def ModuleInit():
	# This code used to be global (not in a function) but for some
	# reason, that caused the ceiutil module to hang when we imported
	# pvcutil.
	# If CR_DEBUG is set, tell the CR mothership to print debug info:
	debug = os.getenv("CR_DEBUG")
	if debug:
		if debug == "2":
			CRSetDebugLevel(2)
		else:
			CRSetDebugLevel(1)
	else:
		# Do nothing.
		# Calling CRSetDebugLevel(0) causes trouble with Ensight.
		pass
	

def _OpenFile(filename):
	"""Helper routine.  Try opening the named file.  Return file object
	if success, None otherwise."""
	try:
		f = file(filename, 'r')
	except:
		return None
	else:
		return f
	return None
	

def GetHostname():
	"""Wrapper for library gethostname call."""
	h = socket.gethostname()
	return h

def GetHostAddress(interface="eth0"):
	"""This returns the externallly visible address for the
	specified interface, or "eth0" if nothing is specified."""
	# It turns out this is pretty hard to do; various combinations
	# of socket.gethostbyname() and socket.getaddrinfo() all seem
	# to return 127.0.0.1, the loopback interface, where for the
	# mothership we need to tell the servers the ethernet
	# interface's address.  We'll call out to our own program,
	# tgd, to get the information.
	pipe = os.popen(os.path.expandvars("$TG/sbin/tgd -c 'config %s'" % interface))
	address = pipe.readline().strip()
	pipe.close()
	return address

def GetSDPSuffix():
	"""Check the CR_SDP_SUFFIX env var to determine the suffix to be added to
	hostnames for SDP.  If the env var is not set, default to 'sdp'."""
	suffix = os.getenv("CR_SDP_SUFFIX");
	if suffix:
		return suffix
	return "sdp"

def GetDisplayName(interface="eth0"):
	"""Return the DISPLAY env var value.  If it starts with a colon, prepend
	the hostname."""
	display = os.getenv("DISPLAY")
	if display[0] == ':':
		display = GetHostAddress(interface) + display
	return display


def GetCurrentPath():
	"""Return the current shell's search path."""
	p = os.getenv("PATH")
	return p


def GetParallelSize():
	"""Query the PARALLEL_SIZE env var, return integer"""
	size = os.getenv("PARALLEL_SIZE");
	if size:
		size = int(size)
	else:
		print "WARNING: The application did not set the PARALLEL_SIZE env var."
		print "This configuration file may not work."
		size = 0
	return size


def GetDMXScreens(displayName):
	""" Call the dmx_config to get information about the DMX backend screens.
	Return value will be a list of dictionaries, one per back-end screen.
	Each dictionary will have the keys 'yorigin', 'xorigin', 'xoff', 'yoff',
	'display', 'width', and 'height'.
	"""
	cmd = "%s/dmx_config %s 2>/dev/null" % (crbindir, displayName)
	dmxScreens = os.popen(cmd).read()
	if not dmxScreens:
		# Try again to see if dmx_config is in our $PATH.
		cmd = "dmx_config %s 2>/dev/null" % (displayName)
		dmxScreens = os.popen(cmd).read()
	if not dmxScreens:
		print "TG-VC Error: Chromium does not appear to have been compiled with DMX support."
		sys.exit(1)
	dmxScreens = eval(dmxScreens)

	if dmxScreens:
		# The screens listed may be machine names, or may be 
		# addresses.  Convert them to addresses if they aren't
		# already; this will prevent lower-level code from messing
		# with them (like adding the "sdp" suffix).
		for screen in dmxScreens:
			dpyName = screen['display']
			machine, displayNumber = dpyName.split(":")
			address = socket.gethostbyname(machine)
			screen['display'] = "%s:%s" % (address, displayNumber)

	return dmxScreens


def GetDMXMuralSize(dmxScreens):
	"""Given a list of DMX Screens info, return the mural size as
	the tuple (width, height)."""
	width = 0
	height = 0
	for tile in dmxScreens:
		xMax = tile['xorigin'] + tile['width']
		yMax = tile['yorigin'] + tile['height']
		if xMax > width:
			width = xMax
		if yMax > height:
			height = yMax
	#end for
	return (width, height)


def GetDisplaySize(displayName):
	"""Query the size of the named X display and return the
	tuple (width, height)"""
	# fallback/default size
	width = 1600
	height = 1200
	if displayName:
		xdpyinfo = os.popen("xdpyinfo -display %s 2>/dev/null" % displayName).read()
	else:
		xdpyinfo = os.popen("xdpyinfo 2>/dev/null").read()
	if xdpyinfo:
		# Look for "dimensions: WIDTHxHEIGHT pixels" line
		pattern = "dimensions:\s+(\d+)x(\d+)"
		m = re.search(pattern, xdpyinfo)
		if m:
			width = int(m.group(1))
			height = int(m.group(2))
		else:
			print "Error: failed to parse xdpyinfo output!"
	else:
		print ("Warning: couldn't determine screen size.  "
			   "Using default %d x %d" % (width, height))
	return (width, height)


def ParseDMXConfigFile(filename, config=None):
	"""Open the named DMX configuration file and return the contents
	as a list in the format returned by GetDMXScreens().
	config indicates which configuration in the file to parse.
	if config is None, return the first configuration in the file.
	Print an error and return None if there's any problems."""
	f = _OpenFile(filename)
	if not f:
		print "pvcutil.ParseDMXConfigFile: unable to open " + filename
		return None
	lines = f.readlines()
	f.close()

	# XXX Parsing is a little loose here, but it should be OK.
	foundConfig = 0
	screenList = []
	for line in lines:
		if line[0] == '#':
			# comment line
			continue

		#pattern = "virtual\s+(\S+)\s+\{"
		pattern = "virtual\s+(\S+)"
		m = re.search(pattern, line)
		if m:
			name = m.group(1)
			if not config or name == config:
				assert foundConfig == 0
				foundConfig = 1
			continue

		if foundConfig:
			pattern = "display\s+(\S+)\s+(\d+)x(\d+)\s+@(\d+)x(\d+);"
			m = re.search(pattern, line)
			if m:
				dpyName = m.group(1)
				w = int(m.group(2))
				h = int(m.group(3))
				x = int(m.group(4))
				y = int(m.group(5))
				scrn = { 'display' : dpyName,
						 'width' : w,
						 'height' : h,
						 'xoff' : 0,
						 'yoff' : 0,
						 'xorigin' : x,
						 'yorigin' : y
						 }
				screenList.append(scrn)
				continue
			#endif

			pattern = "\}"
			m = re.search(pattern, line)
			if m:
				# all done
				if len(screenList) == 0:
					print "pvcutil.ParseDMXConfigFile: no DMX screens found!"
					return None
				else:
					return screenList
				#endif
			#endif
		#endif
	#endfor

	if not foundConfig:
		print "pvcutil.ParseDMXConfigFile: no DMX configuration found!"
	else:
		print "pvcutil.ParseDMXConfigFile: syntax error!"
	return None


def ComputeMuralSize(screens):
	"""Given a list of screens, as returned by ParseDMXConfigFile() or
	GetDMXScreens(), compute the overall mural size and return it as a
	(width, height) tuple."""
	xmax = 0
	ymax = 0
	for screen in screens:
		x = screen['xorigin'] + screen['width']
		y = screen['yorigin'] + screen['height']
		if x > xmax:
			xmax = x
		if y > ymax:
			ymax = y
	return (xmax, ymax)


def GetClusterConfiguration():
	"""Find the cluster configuration file, open it, evaluate it, and return
	a Python dictionary of values if successful.
	Otherwise, return None."""
	f = None
	if os.getenv("CLUSTER_CONFIG_FILE"):
		f = _OpenFile(os.getenv("CLUSTER_CONFIG_FILE"))
	if not f:
		f = _OpenFile(LOCAL_CLUSTER_CONFIG_FILE)
	if not f:
		f = _OpenFile(GLOBAL_CLUSTER_CONFIG_FILE)
	if not f:
		print "TG-VC Error: Unable to find/open cluster configuration file"
		sys.exit(1)

	v = f.read()
	info = eval(v)
	f.close()

	# Allow some fields to be overridden.  In particular, in
	# parallel configurations on LSF-administered clusters, the 
	# LSB_HOSTS variable will be set to the list of hosts
	# available as render slaves.
	if os.getenv("RENDER_HOSTS"):
		info['RenderNodes'] = os.getenv("RENDER_HOSTS").split(" ")
	elif os.getenv("LSB_HOSTS"):
		info['RenderNodes'] = os.getenv("LSB_HOSTS").split(" ")

	# Fill in missing values that we can use safe defaults for
	if not info.has_key('Protocol'):
		info['Protocol'] = 'tcpip'
	if not info.has_key('Shell'):
		info['Shell'] = '/usr/bin/rsh'
	if not info.has_key('ShellOptions'):
		info['ShellOptions'] = ''
	if not info.has_key('VRAMSize'):
		info['VRAMSize'] = 256
	if not info.has_key('Interface'):
		if info['Protocol'] == 'sdp':
			info['Interface'] = 'ib0'
		else:
			info['Interface'] = 'eth0'

	# make sure 'VRAMSize' is an integer
	info['VRAMSize'] = int(info['VRAMSize'])
	return info


_UsedPorts = []
def AllocatePort():
	"""Choose a port number for client/server or peer-peer communication.
	This allows us to run multiple OpenGL apps at once.  Each instance
	needs unique server port numbers so they don't step on each other."""
	# Ports in [10001,10100] are reserved for the Mothership (see load.c)
	# Ports in [7000,7049] are used here.
	# Port 7050 is the default for the tgcomp SPU.
	# Port 7090 is the default for the tgprd program.
	# Other ports?
	while 1:
		# XXX a non-random solution would probably be better.
		p = random.randint(7000, 7050)
		# Make sure it's not already allocated
		if not (p in _UsedPorts):
			_UsedPorts.append(p)
			return p
	return 7000 # fallback


def GeneratePeersString(hosts, protocol):
	"""Generate the peers string which is used to configure the binaryswap
	or tgcomp SPUs.
	hosts is a list of hostnames (and specifies the number of compositors).
	Return a string such as 'sdp://node1:7030,sdp://node2:7030' """

	# port for first SPU:
	compPort = AllocatePort()
	ports = [compPort]

	# Are any hostnames duplicated in hosts[]?  If so, we need
	# to assign unique port numbers to SPU instances on the same host.
	count = len(hosts)
	for i in range(1, count):
		dups = hosts[0:i].count(hosts[i])
		ports.append(compPort + dups)
				
	# Generate the peers string to configure the SPU
	peers = ""
	for i in range(count):
		peers += protocol + "://" + hosts[i] + ":" + str(ports[i])
		if i != count - 1:
			peers += ","

	return peers


def Autostart(node, protocol, arglist):
	"""Wrapper for the Chromium node.Autostart() call.  Basically make sure
	the arglist doesn't contain any empty strings.  This can happen when
	the ShellOpts variable is ''."""
	# The arglist is [shellprogram, shellopts, hostname, command]

	# If we're using rsh and sdp, append the "sdp" suffix onto the hostname.
	# This is because we probably only enabled password-less rsh on the
	# sdp interface.
	if arglist[0][-3:] == "rsh" and protocol == "sdp":
		arglist[2] += GetSDPSuffix()

	newlist = []
	for arg in arglist:
		if arg != '':
			newlist.append(arg)
	node.AutoStart(newlist)
	return


def ParseCommandLine(argv):
	"""Parse the sys.argv argument list.
	Return tuple (mothershipPort, directory, program, params, autoStart)"""
	# The expected argv is
	# ['/opt/tg/configs/foobar.conf', msPort, dir, program]
	if len(sys.argv) <= 3:
		# no arguments - probably doing in-house test/devel work
		print "Start everything manually!"
		mothershipPort = DefaultMothershipPort
		directory = crbindir
		if len(sys.argv) > 1:
			program = sys.argv[1]
		else:
			program = ""
		if len(sys.argv) > 2:
			params = sys.argv[2:]
		else:
			params = []
		autoStart = 0
	elif len(sys.argv) >= 4:
		# this is the normal case when using the CR_CONFIG env var:
		mothershipPort = int(sys.argv[1])  # %m
		directory = sys.argv[2]            # %d
		program = sys.argv[3]              # %p
		params = sys.argv[4:]              # typically an empty list: []
		if "-manual" in params:
			autoStart = 0
		else:
			autoStart = 1
	else:
		print "TG-VC Error in ParseCommandLine!"
		sys.exit(2)
	return (mothershipPort, directory, program, params, autoStart)

DynamicClusterHosts = None
def GetDynamicClusterHosts():
	global DynamicClusterHosts
	if DynamicClusterHosts:
		return DynamicClusterHosts

	pipe = os.popen(os.path.expandvars("$TG/sbin/getclusterconfig"), "r")
	DynamicClusterHosts = pipe.read().split("\n")
	pipe.close()
	return DynamicClusterHosts

DynamicResourceMapping = None
def GetDynamicResourceMapping():
	global DynamicResourceMapping
	if DynamicResourceMapping:
		return DynamicResourceMapping

	hosts = GetDynamicClusterHosts()

	# Each line will be of the form
	#	clustertype clustername role <n> <2*n interfaces> <n> <n resources>
	# The returned mapping will work like:
	#	mapping[resource] = [{interface,address},{interface,address},...]
	# Note that if a single node marks that it has multiple copies of a 
	# resource (say, "render render"), its addresses will appear twice in this list,
	# on purpose (so we can do multiple operations on a single sufficiently powerful
	# node)
	DynamicResourceMapping = {}
	for host in hosts:
		if not host:
			# Blank lines can appear at the end
			continue
		fields = host.split()
		for resource in fields[3 + 2*int(fields[3]):]:
			if not DynamicResourceMapping.has_key(resource):
				DynamicResourceMapping[resource] = []
			# Add all the possible addresses where this resource can be reached
			for interfaceNumber in range(int(fields[3])):
				DynamicResourceMapping[resource].append(
					{'interface': fields[4+2*interfaceNumber], 
					'address': fields[5+2*interfaceNumber]}
				)

	return DynamicResourceMapping

# Pull all the dynamic resources available on a given interface
def GetDynamicResourceAddresses(resource, interface = None):
	mapping = GetDynamicResourceMapping()
	if not mapping.has_key(resource):
		return None

	# If no interface was specified, return the whole array.
	if interface == None:
		return mapping[resource]

	# mapping[resource] is an array of [{interface, address}...].  Pull out
	# the ones for the interface we need.
	returnedAddresses = []
	for addressPair in mapping[resource]:
		if addressPair['interface'] == interface:
			returnedAddresses.append(addressPair['address'])

	# If we actually have any addresses, return them.
	if len(returnedAddresses) > 0:
		return returnedAddresses

	# Otherwise, flag that we don't have any.
	return None
	
DynamicAddressMapping = None
def GetDynamicAddressMapping():
	global DynamicAddressMapping
	if DynamicAddressMapping:
		return DynamicAddressMapping

	clusterHosts = GetDynamicClusterHosts()
	# Each line will be of the form
	#	clustertype clustername role n interface0 address0 interface1 address1...
	# The returned mapping will work like:
	#	mapping["role1,eth0"] = 192.168.1.101
	# 	mapping["role1,ib0"] = 172.22.0.1
	# etc.
	DynamicAddressMapping = {}
	for host in clusterHosts:
		if not host:
			# Blank lines can appear at the end
			continue
		fields = host.split()
		for interfaceNumber in range(int(fields[3])):
			DynamicAddressMapping["%s,%s" % (fields[2], fields[4+2*interfaceNumber])] = fields[5+2*interfaceNumber]

	return DynamicAddressMapping

# This one maps all addresses for a role to the role name
DynamicRoleMapping =None
def GetDynamicRoleMapping():
	global DynamicRoleMapping
	if DynamicRoleMapping:
		return DynamicRoleMapping

	clusterHosts = GetDynamicClusterHosts()
	DynamicRoleMapping = {}
	for host in clusterHosts:
		if not host:
			# Blank lines can appear at the end
			continue
		fields = host.split()

		# Add all the interface addresses
		for interfaceNumber in range(int(fields[3])):
			DynamicRoleMapping[fields[5+2*interfaceNumber]] = fields[2]
	return DynamicRoleMapping


DynamicAddressListMapping = None
def GetDynamicAddressListMapping():
	global DynamicAddressListMapping
	if DynamicAddressListMapping:
		return DynamicAddressListMapping

	clusterHosts = GetDynamicClusterHosts()

	# Each line will be of the form
	#	clustertype clustername role n interface0 address0 interface1 address1...
	DynamicAddressListMapping = []
	for host in clusterHosts:
		addresses = []
		if not host:
			# Blank lines can appear at the end
			continue
		fields = host.split()

		# The role is one equivalence
		addresses.append(fields[2])

		# Add all the interface addresses
		for interfaceNumber in range(int(fields[3])):
			addresses.append(fields[5+2*interfaceNumber])

		DynamicAddressListMapping.append(addresses)
	return DynamicAddressListMapping

def GetDynamicHostAddressList(host):
	mapping = GetDynamicAddressListMapping()
	address = socket.gethostbyname(host)
	for addressList in mapping:
		if address in addressList:
			return addressList
	return None

def GetDynamicHostInterfaceAddress(host, interface):
	mapping = GetDynamicAddressMapping()
	key = "%s,%s" % (host, interface)
	if mapping.has_key(key):
		return mapping[key]
	else:
		return None

def GetDynamicAddressRole(address):
	mapping = GetDynamicRoleMapping()
	if mapping.has_key(address):
		return mapping[address]
	else:
		return None

def StartParallelConfiguration(AppSPU, mode='depth', vnc=0):
	"""This giant function will create a mothership configuration for
	parallel rendering, such as for TGPRD.
	This is used by the many-to-one-reassembly, many-to-one-composite
	and many-to-many-composite configurations.
	The AppSPU parameter may either be 'binaryswap' or 'readback' for
	sort-last Z compositing, or 'tgrb' for image reassembly.
    If doing compositing, 'mode' must either be 'depth' or 'alpha' to
	control Z vs. alpha compositing.
	If vnc==1, we'll enable the 'vnc' SPU for rendering instead of
	the 'render' SPU so that it will be seen by VNC clients and the
	vncproxy."""

	ModuleInit()

	assert (AppSPU == 'binaryswap' or
			AppSPU == 'tgcomp' or
			AppSPU == 'readback' or
			AppSPU == 'tgrb')
	assert mode == 'depth' or mode == 'alpha'
	assert vnc == 0 or vnc == 1

	(MothershipPort, Directory, Program, Params, AutoStart) = ParseCommandLine(sys.argv)

	# Allow a parameter to control depth or alpha compositing.
	if '-alpha' in Params:
		mode='alpha'
	elif '-depth' in Params:
		mode='depth'
	# Allow a parameter to control composition method
	compositionMethod = 'software'
	if '-texture' in Params:
		compositionMethod = 'texture'
	elif '-software' in Params:
		compositionMethod = 'software'
	elif '-drawpixels' in Params:
		compositionMethod = 'drawpixels'

	# Get some cluster information.  Note that environment variables
	# (e.g. LSB_HOSTS) can override the values in configuration files.
	Cluster = GetClusterConfiguration()
	SlaveHosts = Cluster['RenderNodes']
	Protocol = Cluster['Protocol']
	Interface = Cluster['Interface']

	# Call dmx_config to get information about the DMX tile layout.
	Display = GetDisplayName(Interface)
	dmxScreens = GetDMXScreens(Display)
	displayMethod = None
	if dmxScreens:
		#print "DMX is running on display %s" % Display
		(DisplayWidth, DisplayHeight) = GetDMXMuralSize(dmxScreens)
		#print "Mural size: %d x %d" % (DisplayWidth, DisplayHeight)
		UsingDMX = 1
		displayMethod = 'drawpixels'
	else:
		#print "DMX is not running on display %s" % Display
		(DisplayWidth, DisplayHeight) = GetDisplaySize(Display)
		UsingDMX = 0
		displayMethod = 'texture'

	# Let parameters override the choice of display method
	if '-display-texture' in Params:
		displayMethod = 'texture'
	elif '-display-pixels' in Params:
		displayMethod = 'drawpixels'

	# Here's a nasty bug that was found by CCLRC.  If the
	# tgcomp "texture" display_method is used, and the vnc 
	# "use_bounding_boxes" value is set, vncviewers will
	# see nothing, because the "texture" display method doesn't
	# set any bounding boxes and the vnc SPU requires them.
	# So if the "texture" method is in use, force the 
	# use_bounding_boxes value off.
	vnc_bounding_boxes = 1
	if '-vnc' in Params:
		vnc = 1
	if '-nobb' in Params or displayMethod == 'texture':
		vnc_bounding_boxes = 0

	# Make sure the SlaveHosts can be resolved.  In a dynamic 
	# configuration, we may need to query for host addresses,
	# and some hosts may not be up.
	addressMapping = None
	tmpSlaveHosts = []
	for i in range(len(SlaveHosts)):
		address = GetDynamicHostInterfaceAddress(SlaveHosts[i], Interface)
		if address:
			tmpSlaveHosts.append(address)
	# Put it back into the master list of slave hosts.
	SlaveHosts = tmpSlaveHosts

	Size = GetParallelSize()
	if Size > len(SlaveHosts):
		print "TG-VC Error: %d nodes requested, but only %d available." % (Size, len(SlaveHosts))
		sys.exit(1)
	NumSlaveNodes = Size
	Shell = Cluster['Shell']
	ShellOpts = Cluster['ShellOptions']

	# Assume master instance of application is running on this host too
	MasterHost = GetHostAddress(Interface)

	MothershipURL = MasterHost + ":" + str(MothershipPort)

	# choose port number for server communication
	serverPort = AllocatePort()

	# make the peers string needed for SPU configuration
	if AppSPU == "binaryswap" or AppSPU == "tgcomp":
		peers = GeneratePeersString( SlaveHosts[0:NumSlaveNodes], Protocol )
		# Do some error checking here
		if (AppSPU == "binaryswap" and
			not (Size in [2, 4, 8, 16, 32, 64, 128, 256, 512])):
			print "TG-VC Error: Invalid size (%d) for binaryswap.  Must be power of two." % Size
			sys.exit(1)

	cr = CR()


	# Set up the main app node
	# We'll grab the app's X window ID, then no-op its normal rendering.
	# This will resolve locally (which is good because application nodes
	# don't resolve by address)
	appnode = CRApplicationNode()
	# NOTE: We do NOT call SetApplication() here.  That's because
	# the application was started by the user in the first place so
	# there's no need to specify the application name here.  Also,
	# this prevents the crappfakers (which we auto-start below) from
	# claiming this node (and getting the wrong SPU chain, etc).
	appnode.StartDir(Directory)
	cr.AddNode(appnode)

	grabber = SPU('grabber')
	grabber.Conf('current_window_attribute_name', 'crut_drawable')
	appnode.AddSPU(grabber)

	if os.getenv("CR_DEBUG"):
		spu = SPU('print')
		spu.Conf('log_file', '/tmp/chromium.out')
		spu.Conf('marker_signal', 12) # SIGUSR2
		appnode.AddSPU(spu)

	nop = SPU('nop')
	appnode.AddSPU(nop)

	#
	# Set up the network/display nodes
	#
	NetworkNodes = []
	if UsingDMX:
		# Set up server/network nodes on the DMX back-ends
		for index in range(len(dmxScreens)):
			tile = dmxScreens[index]
			tileHost = tile['display'].split(':')[0]

			addressList = GetDynamicHostAddressList(tileHost)
			if not addressList:
				print "TG-VC Error: cannot map parallel host '%s', address '%s' to our dynamic configuration." % (tileHost, address)
				sys.exit(1)
			netnode = CRNetworkNode(tileHost, "address", addressList)
			netnode.AddTile(0, 0, 10, 10)  # Not really significant
			netnode.Conf('use_dmx', 1)
			netnode.Conf('optimize_bucket', 0)
			netnode.Conf('shared_windows', 1)
			netnode.Conf('only_swap_once', 1)
			netnode.Conf('debug_barriers', 0)

			# Debug if desired
			if os.getenv("CR_DEBUG"):
				spu = SPU('print')
				spu.Conf('log_file', '/tmp/dmxserver.out')
				spu.Conf('marker_signal', 12) # SIGUSR2
				netnode.AddSPU(spu)

			if vnc:
				renderspu = SPU('vnc')
				renderspu.Conf('screen_size', [DisplayWidth, DisplayHeight])
				renderspu.Conf('max_update_rate', 20)
				renderspu.Conf('force_direct', 0)
				renderspu.Conf('use_bounding_boxes', vnc_bounding_boxes)
			else:
				renderspu = SPU('render')
			renderspu.Conf('display_string', tile['display'])
			renderspu.Conf('render_to_app_window', 1)
			renderspu.Conf('title', "Chromium Render SPU %d" % index)
			netnode.AddSPU(renderspu)

			env = "LD_LIBRARY_PATH=" + crlibdir + " PATH=" + GetCurrentPath() + " CR_HOSTNAME=" + tileHost
			# Add the debug flag for the kids, if it's set for us
			if os.getenv("CR_DEBUG"):
				env += " CR_DEBUG=" + os.getenv("CR_DEBUG")

			if os.getenv("CR_DEBUG_FILE"):
				env += " CR_DEBUG_FILE=" + os.getenv("CR_DEBUG_FILE")

			prog = crbindir + "/crserver -mothership " + MothershipURL
			if os.getenv("LSB_HOSTS"):
				cmd = "/bin/sh -c 'touch /var/tg/lsf/render.$$; " + env + " " + prog + "'"
			else:
				cmd = "/bin/sh -c '" + env + " " + prog + "'"

			if AutoStart:
				Autostart(netnode, Protocol, [Shell, ShellOpts, tileHost, cmd])
			else:
				print "Manually start on %s: %s" % (tileHost, cmd)
			# If you want to run locally with /bin/sh, try this:
			#Autostart(netnode, ["/bin/sh", "-c", env + " " + prog])

			cr.AddNode(netnode)
			NetworkNodes.append(netnode)
		#endfor
	else:
		# Non-DMX: Create render/display node on the main display
		addressList = GetDynamicHostAddressList(MasterHost)
		if not addressList:
			print "TG-VC Error: cannot map parallel host '%s' to an address list" % MasterHost
			sys.exit(1)
		# We want the nodename to be the address servers use to
		# connect, so it should be the interface-appropriate address.
		role = GetDynamicAddressRole(MasterHost)
		ibAddress = GetDynamicHostInterfaceAddress(role, Interface)
		netnode = CRNetworkNode(ibAddress, "address", addressList)
		netnode.Conf('shared_windows', 1)
		netnode.Conf('only_swap_once', 1)

		# Debug if desired
		if os.getenv("CR_DEBUG"):
			spu = SPU('print')
			spu.Conf('log_file', '/tmp/dmxserver.out')
			spu.Conf('marker_signal', 12) # SIGUSR2
			netnode.AddSPU(spu)

		if vnc:
			renderspu = SPU('vnc')
			renderspu.Conf('screen_size', [DisplayWidth, DisplayHeight])
			renderspu.Conf('max_update_rate', 20)
			renderspu.Conf('force_direct', 0)
			renderspu.Conf('use_bounding_boxes', vnc_bounding_boxes)
		else:
			renderspu = SPU('render')

		renderspu.Conf('render_to_app_window', 0)
		renderspu.Conf('render_to_crut_window', 1)
		renderspu.Conf('resizable', 1)
		renderspu.Conf('title', "Chromium Render SPU")
		role = GetDynamicAddressRole(MasterHost)
		ibAddress = GetDynamicHostInterfaceAddress(role, Interface)
		renderspu.Conf('display_string', '%s:0' % ibAddress)
		netnode.AddSPU(renderspu)

		# Prepare the autostart
		env = "LD_LIBRARY_PATH=" + crlibdir + " PATH=" + GetCurrentPath() + " CR_HOSTNAME=" + ibAddress
		# Add the debug flag for the kids, if it's set for us
		if os.getenv("CR_DEBUG"):
			env += " CR_DEBUG=" + os.getenv("CR_DEBUG")
		if os.getenv("CR_DEBUG_FILE"):
			env += " CR_DEBUG_FILE=" + os.getenv("CR_DEBUG_FILE") + "-crserver"

		prog = crbindir + "/crserver -mothership " + MothershipURL
		if os.getenv("LSB_HOSTS"):
			cmd = "/bin/sh -c 'touch /var/tg/lsf/render.$$; " + env + " " + prog + "'"
		else:
			cmd = "/bin/sh -c '" + env + " " + prog + "'"
		if AutoStart:
			Autostart(netnode, Protocol, [Shell, ShellOpts, MasterHost, cmd])
		else:
			print "Manually start on %s: %s" % (MasterHost, cmd)

		cr.AddNode(netnode)
		NetworkNodes.append(netnode)

	# Set up the slave application nodes
	for i in range(NumSlaveNodes):

		addressList = GetDynamicHostAddressList(SlaveHosts[i])
		if not addressList:
			print "TG-VC Error: cannot map parallel slave host '%s', address '%s' to our dynamic configuration." % (SlaveHosts[i], address)
			sys.exit(1)
		role = GetDynamicAddressRole(SlaveHosts[i])
		if not role:
			print "TG-VC Error: cannot map parallel slave host '%s' to a role." % SlaveHosts[i]
		#primaryAddress = GetDynamicHostInterfaceAddress(role, "eth0")
		primaryAddress = GetDynamicHostInterfaceAddress(role, Interface)
		if not primaryAddress:
			print "TG-VC Error: cannot map parallel slave host '%s' to a primary address" % SlaveHosts[i]
			sys.exit(1)
		appnode = CRApplicationNode(primaryAddress)
		appnode.StartDir(Directory)
		appnode.SetApplication(Program)

		# Prepare for autostart
		# The environment will include the necessary
		# values for the MASTER_HOST and SLAVE_RANK, so
		# that the slave executable can figure out its place
		env = "LD_LIBRARY_PATH=" + crlibdir + " PATH=" + GetCurrentPath() + " CR_HOSTNAME=" + primaryAddress + " MASTER_HOST=" + MasterHost + (" SLAVE_RANK=%d"%i)
		# Add the debug flag for the kids, if it's set for us
		if os.getenv("CR_DEBUG"):
			env += " CR_DEBUG=" + os.getenv("CR_DEBUG")
		if os.getenv("CR_DEBUG_FILE"):
			env += " CR_DEBUG_FILE=" + os.getenv("CR_DEBUG_FILE")

		prog = "%s/crappfaker -mothership %s" % (crbindir, MothershipURL)
		if os.getenv("RENDER_HOSTS"):
			cmd = "/bin/sh -c 'touch /var/tg/lsf/render.$$; " + env + " " + prog + "'"
		else:
			cmd = "/bin/sh -c '" + env + " " + prog + "'"
		if AutoStart:
			Autostart(appnode, Protocol, [Shell, ShellOpts, SlaveHosts[i], cmd])
		else:
			print "Manually start on %s: %s" % (SlaveHosts[i], cmd)

		# Create/configure the application SPU (binaryswap, readback or tgrb)
		appspu = SPU(AppSPU)
		if AppSPU == 'binaryswap' or AppSPU == "tgcomp":
			appspu.Conf('title', '%s SPU %d' % (AppSPU, i))
			appspu.Conf('type', mode)
			appspu.Conf('peers', peers)
			appspu.Conf('node_number', i)
			appspu.Conf('composite_method', compositionMethod)
			appspu.Conf('display_method', displayMethod)
		elif AppSPU == 'tgrb':
			appspu.Conf('title', 'TGRB SPU %d' % i)
			if Size == 2:
				if i == 0:
					DisplayWidth = DisplayWidth / 2 + 1
				read = [0.5, 1.0]  # half width, full height
				if i == 0:
					draw = [0.0, 0.0]
				else:
					draw = [0.5, 0.0]
			elif Size == 4:
				if i == 0:
					DisplayWidth = DisplayWidth / 2 + 1
					DisplayHeight = DisplayHeight / 2 + 1
				read = [0.5, 0.5]  # half width, half height
				if i == 0:
					draw = [0.0, 0.0]
				elif i == 1:
					draw = [0.5, 0.0]
				elif i == 2:
					draw = [0.0, 0.5]
				elif i == 3:
					draw = [0.5, 0.5]
			else:
				print 'TG-VC Error: Invalid Size (%d) for tile reassembly' % Size
				sys.exit(1)
			appspu.Conf('read_size', read)
			appspu.Conf('draw_offset', draw)
			appspu.Conf('viewport_scaling', 0)
			appspu.Conf('extract_depth', 0)
		else:
			assert AppSPU == 'readback'
			appspu.Conf('title', 'Readback SPU %d' % i)
			if mode == 'depth':
				appspu.Conf('extract_depth', 1)
			elif mode == 'alpha':
				appspu.Conf('extract_alpha', 1)
		#endif
		appspu.Conf('resizable', 1)
		#appspu.Conf('window_geometry', [0, 0, 10, 10])
		appspu.Conf('ignore_window_moves', 1)
		appspu.Conf('display_string', ':0')
		# use fixed pbuffer size to avoid VRAM fragmentation from window resizes
		appspu.Conf('pbuffer_size', [DisplayWidth, DisplayHeight])
		appnode.AddSPU(appspu)

		# Each binaryswap or readback SPU then drives a tilesort or packSPU:
		if UsingDMX:
			tilesortspu = SPU('tilesort')
			tilesortspu.Conf('bucket_mode', 'Non-Uniform Grid')
			tilesortspu.Conf('display_string', Display)
			tilesortspu.Conf('draw_bbox', 0)
			tilesortspu.Conf('bbox_scale', 1.0)
			tilesortspu.Conf('lazy_send_dlists', 0)
			tilesortspu.Conf('dlist_state_tracking', 0)
			tilesortspu.Conf('use_dmx', 1)
			tilesortspu.Conf('retile_on_resize', 1)
			tilesortspu.Conf('render_to_crut_window', 1)
			tilesortspu.Conf('track_window_position', 1)
			tilesortspu.Conf('fake_window_dims', [100, 100])
			appnode.AddSPU(tilesortspu)
			for server in NetworkNodes:
				tilesortspu.AddServer(server, Protocol, serverPort)
		else:
			packspu = SPU('pack')
			appnode.AddSPU(packspu)
			packspu.AddServer(netnode, Protocol, serverPort)

		cr.AddNode(appnode)
	#endfor

	# Compute MTU
	# Estimate from the DMX screen size (or max image size)

	if UsingDMX:
		MTU = DisplayWidth * DisplayHeight * 3 + 10000
	else:
		MTU = DisplayWidth * DisplayHeight * 4 + 10000
	cr.MTU(MTU)

	cr.Go(MothershipPort)

#enddef StartParallelConfiguration



def StartDMXConfiguration(sendImages, appSPU):
	"""Start a DMX mothership configuration.
	The sendImages parameter controls whether we send geometry or images
	to the display servers.
	This function is used for the one-to-many-reassemble and
	one-to-many-broadcast configurations.
	The appSPU may be 'tilesort' or 'broadcast' to indicate which SPU to
	use for talking to the server nodes.
	"""

	ModuleInit()

	assert sendImages == 0 or sendImages == 1
	assert appSPU == 'tilesort' or appSPU == 'broadcast'

	if sendImages == 1:
		assert(appSPU == 'tilesort')

	(MothershipPort, Directory, Program, Params, AutoStart) = ParseCommandLine(sys.argv)

	# Read the cluster configuration file to get SlaveHosts, Protocol and Shell
	Cluster = GetClusterConfiguration()
	Protocol = Cluster['Protocol']
	Shell = Cluster['Shell']
	ShellOpts = Cluster['ShellOptions']
	Interface = Cluster['Interface']

	# Call dmx_config to get information about the DMX tile layout.
	Display = GetDisplayName(Interface)
	dmxScreens = GetDMXScreens(Display)
	if not dmxScreens:
		print "TG-VC Error: DMX does not appear to be running."
		sys.exit(1)

	# Find the DMX mural size
	(MuralWidth, MuralHeight) = GetDMXMuralSize(dmxScreens)
	CRInfo("Mural size: %d x %d" % (MuralWidth, MuralHeight))



	MothershipURL = GetHostAddress(Interface) + ":" + str(MothershipPort)

	# choose port number for server communication
	serverPort = AllocatePort()


	cr = CR()
	if sendImages:
		MTU = MuralWidth * MuralHeight * 3 + 64000
	else:
		MTU = 10*1024*1024
	cr.MTU(MTU)


	# Set up the main application node.  This corresponds to the
	# OpenGL app which the user started in the first place.
	appnode = CRApplicationNode()
	appnode.StartDir(Directory)
	# No need to call SetApplication() here since the user already started
	# the application (which in turn started this mothership config).
	appnode.Conf('track_window_size', 1)
	appnode.Conf('track_window_position', 1)
	appnode.Conf('force_pbuffers', sendImages)
	cr.AddNode(appnode)

	# Application/GL logging for debugging/support
	logFile = os.getenv("CR_LOG_FILE")
	if logFile:
		print "NOTICE: Logging Chromium/GL commands to %s" % logFile
		printSPU = SPU('print')
		printSPU.Conf('log_file', logFile)
		appnode.AddSPU(printSPU)

	if sendImages:
		if 1:
			readbackspu = SPU('readback')
		else:
			# xxx experimental code
			readbackspu = SPU('tgrb')
			readbackspu.Conf('use_threads', 0)
			readbackspu.Conf('barrier_size', 1)
		readbackspu.Conf('display_string', ':0')
		readbackspu.Conf('title', 'Readback SPU')
		readbackspu.Conf('resizable', 1)
		readbackspu.Conf('ignore_window_moves', 1)
		readbackspu.Conf('pbuffer_size', [MuralWidth, MuralHeight])
		appnode.AddSPU(readbackspu)

	sendingspu = SPU(appSPU)
	if appSPU == 'tilesort':
		sendingspu.Conf('bucket_mode', 'Non-Uniform Grid')
		sendingspu.Conf('use_dmx', 1)
		sendingspu.Conf('retile_on_resize', 1)  # the default
		sendingspu.Conf('draw_bbox', 0)
		sendingspu.Conf('bbox_scale', 1.0)
		sendingspu.Conf('lazy_send_dlists', 0)
		sendingspu.Conf('dlist_state_tracking', 0)
	else:
		assert appSPU == 'broadcast'
		sendingspu.Conf('use_dmx', 1)
		sendingspu.Conf('swapbuffer_sync', 1)
	appnode.AddSPU(sendingspu)

	# Set up server/network nodes on the DMX back-ends.
	for index in range(len(dmxScreens)):
		tile = dmxScreens[index]
		tileHost = tile['display'].split(':')[0]

		# In static configurations, 'tilehost' will hold a
		# resolvable host name; in dynamic configurations, it
		# will hold a dotted-decimal address. Either resolves
		# to an address here:
		address = socket.gethostbyname(tileHost)

		# When a crserver announces itself, the announcement will
		# come in on the Ethernet interface (or one of them), with
		# a name that may not be resolvable (in dynamic configurations,
		# the name might be meaningless, e.g. "localhost.localdomain").
		# So instead of trying to match on the name, we'll try to match
		# on the incoming address of the socket.  So find the list
		# of valid addresses associated with this host, and allow a
		# match on any of them.
		netnode = None
		addressList = GetDynamicHostAddressList(tileHost)
		if not addressList:
			print "TG-VC Error: cannot map host '%s', address '%s' to our dynamic configuration." % (tileHost, address)
			sys.exit(1)
		netnode = CRNetworkNode(tileHost, "address", addressList)
		netnode.AddTile(0, 0, tile['width'], tile['height'])
		netnode.Conf('use_dmx', 1)
		netnode.Conf('optimize_bucket', 0)
		cr.AddNode(netnode)

		renderspu = SPU('render')
		renderspu.Conf('display_string', tile['display'])
		renderspu.Conf('render_to_app_window', 1)
		renderspu.Conf('title', "Chromium Render SPU %d" % index)
		# Mesa debug:
		#renderspu.Conf('system_gl_path', "/home/demo/brian/cvs/Mesa/lib64")
		netnode.AddSPU(renderspu)

		env = "LD_LIBRARY_PATH=" + crlibdir + " PATH=" + GetCurrentPath() + " CR_HOSTNAME=" + tileHost

		# Add the debug flag for the kids, if it's set for us
		if os.getenv("CR_DEBUG"):
			env += " CR_DEBUG=" + os.getenv("CR_DEBUG")
		if os.getenv("CR_DEBUG_FILE"):
			env += " CR_DEBUG_FILE=" + os.getenv("CR_DEBUG_FILE")

		prog = crbindir + "/crserver -mothership " + MothershipURL
		cmd = "/bin/sh -c '" + env + " " + prog + "'"
		if AutoStart:
			Autostart(netnode, Protocol, [Shell, ShellOpts, tileHost, cmd])
		else:
			print "Manually start on %s: %s" % (tileHost, cmd)

		sendingspu.AddServer(netnode, Protocol, serverPort)

	cr.Go(MothershipPort)

#enddef StartDMXConfiguration

def ConfigIfSet(spu, envvar, spuvar, default):
	try:
		val=int(os.getenv(envvar))
	except:
		val=default
	spu.Conf(spuvar, val)
	return

def StartOneToRemoteConfiguration():
	"""Start a one-to-remote configuration.
	Basically, we just make applications use the "vnc" SPU, which
	talks directly to the vncproxy server.  Note that this configuration
	does not need a license to run; this is intentional."""

	ModuleInit()

	(MothershipPort, Directory, Program, Params, AutoStart) = ParseCommandLine(sys.argv)

	Cluster = GetClusterConfiguration()
	Interface = Cluster['Interface']

	MothershipURL = GetHostAddress(Interface) + ":" + str(MothershipPort)

	(width, height) = GetDisplaySize(None)

	#print "Params = %s" % str(Params)
	#print "Interval = %f" % Interval

	cr = CR()
	# MTU doesn't matter; we're not using the network

	# Set up the main application node.  This corresponds to the
	# OpenGL app which the user started in the first place.
	appnode = CRApplicationNode()
	# No need to call SetApplication() here since the user already started
	# the application (which in turn started this mothership config).
	appnode.Conf('track_window_size', 1)
	appnode.Conf('track_window_position', 1)
	cr.AddNode(appnode)

	vncspu = SPU('vnc')
	vncspu.Conf('screen_size', [width, height])
	vncspu.Conf('max_update_rate', 20)
	vncspu.Conf('render_to_app_window', 1)
	vncspu.Conf('display_string', ':0')
	vncspu.Conf('force_direct', 0)
	ConfigIfSet(vncspu, "VNC_USEBOUNDS", 'use_bounding_boxes', 0)
	ConfigIfSet(vncspu, "VNC_COALESCE", 'coalesce_writes', 0)
	ConfigIfSet(vncspu, "VNC_BOUNDINGBOX", 'draw_bbox', 0)
	ConfigIfSet(vncspu, "VNC_FRAMEDROP", 'frame_drop', 1)
	ConfigIfSet(vncspu, "VNC_DOUBLE_BUFFER", 'double_buffer', 0)
	appnode.AddSPU(vncspu)

	cr.Go(MothershipPort)

#enddef StartOneToRemoteConfiguration
