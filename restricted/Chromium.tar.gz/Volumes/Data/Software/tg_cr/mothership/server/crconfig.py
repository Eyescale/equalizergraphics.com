import os
arch = "Darwin"
crdir = "/Volumes/Data/Software/tg_cr"
crbindir = os.path.join(crdir,'bin',arch)
crlibdir = os.path.join(crdir,'lib',arch)
