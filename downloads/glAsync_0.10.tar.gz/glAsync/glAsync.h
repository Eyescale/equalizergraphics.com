
/* Copyright (c) 2005-2006, Stefan Eilemann <eilemann@gmail.com> 
   All rights reserved. */

#ifndef _GL_ASYNC_H_
#define _GL_ASYNC_H_

#include <list>
#include <vector>
#include <GL/glx.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/XUtil.h>

#ifdef __GNUC__              // GCC 3.1 and later
#  include <ext/hash_map>
namespace Sgi = ::__gnu_cxx; 
#else                        //  other compilers
#  include <hash_map>
namespace Sgi = std;
#endif


/**
 * @namespace glAsync
 * @brief Provides asynchronous OpenGL functions
 *
 * The glAsync functions deliver asynchronous OpenGL downloads in the spirit of
 * the SGIX_async extension. A second thread uses a shared context to the main
 * context for asynchronous downloads. The application can map more than one
 * context, but only one context can be current at a given time. All commands
 * are executed in the order they are submitted. The asynchronous helper thread
 * is only running when at least one context is mapped.
 * 
 * The functions are not thread-safe. For thread-safety and performance
 * multi-threaded rendering codes are advised to use one glAsync::Thread
 * instance per rendering thread.
 */
namespace glAsync
{
    /** 
     * Map a context to be used for asynchronous functions.
     * 
     * This function creates a hidden shared context and drawable to be used the
     * asynchronous functions.
     *
     * @param display the connection to the X server.
     * @param visInfo the visual information.
     * @param context the GLX rendering context.
     * @return <code>True</code> on success, <code>False</code> otherwise.
     */
    Bool XMapContext( Display* display, XVisualInfo* visInfo,
                      GLXContext context );

    /** 
     * Unmap a context to be used for asynchronous functions.
     * 
     * This function deregisters the context from the glAsync library and
     * deallocates all associated resources. For performance reasons it does not
     * check that all outstanding commands for this context have been
     * executed. The application has to explicitly wait for the commands to be
     * finished before calling the function.
     *
     * @param display the connection to the X server.
     * @param context the GLX rendering context.
     * @sa finish(), finishAll()
     */
    void XUnmapContext( Display* display, GLXContext context );

    /** 
     * Attach a rendering context to the asynchronous thread.
     *
     * @param display the connection to the X server.
     * @param context  the GLX rendering context.
     * @return <code>True</code> if successful, <code>False</code> otherwise.
     * @sa glXMakeCurrent
     */
    Bool XMakeCurrent( Display* display, GLXContext context );


    /** 
     * Bind a named texture to a texturing target for the following asynchronous
     * texture operations on the target.
     * 
     * @sa glBindTexture
     */
    void bindTexture( GLenum target, GLuint texture );

    /** 
     * Specify a two-dimensional texture image.
     *
     * @return the marker associated with the asynchronous operation.
     * @sa glTexImage2D
     */
    GLuint texImage2D( GLenum target, GLint level, GLint internalformat,
                       GLsizei width, GLsizei height, GLint border,
                       GLenum format, GLenum type, const GLvoid *pixels );

    /** 
     * Specify a three-dimensional texture image.
     *
     * @return the marker associated with the asynchronous operation.
     * @sa glTexImage3D
     */
    GLuint texImage3D( GLenum target, GLint level, GLint internalformat,
                       GLsizei width, GLsizei height, GLsizei depth,
                       GLint border, GLenum format, GLenum type,
                       const GLvoid *pixels );
    
    /** 
     * Poll for the completion of an operation.
     * 
     * @param marker the marker of the operation.
     * @return <code>True</code> if the operation has completed,
     *         <code>False</code> if it is in progress.
     */
    Bool poll( GLuint marker );

    /** 
     * Poll for the completion of all operations.
     * 
     * @return <code>True</code> if the helper thread is idle, i.e. all
     *         operations have completed, <code>False</code> if there are still
     *         outstanding operations.
     */
    Bool isIdle();

    /** 
     * Finish an operation.
     * 
     * Finish blocks until the operation has completed.
     *
     * @param marker the marker of the operation.
     */
    void finish( GLuint marker );

    /**
     * Finish all pending operations.
     */
    void finishAll();

    /**
     * For multi-threaded rendering, use one instance of this class for each
     * rendering thread. 
     *
     * Please refer to the static functions in the glAsync namespace for
     * documentation.
     */
    class Thread
    {
    public: 
        Bool XMapContext( Display* display, XVisualInfo* visInfo,
                          GLXContext context );
        void XUnmapContext( Display* display, GLXContext context );
        Bool XMakeCurrent( Display* display, GLXContext context );

        void bindTexture( GLenum target, GLuint texture );
        GLuint texImage2D( GLenum target, GLint level, GLint internalformat,
                           GLsizei width, GLsizei height, GLint border,
                           GLenum format, GLenum type, const GLvoid *pixels );
        GLuint texImage3D( GLenum target, GLint level, GLint internalformat,
                           GLsizei width, GLsizei height, GLsizei depth,
                           GLint border, GLenum format, GLenum type,
                           const GLvoid *pixels );

        Bool poll( GLuint marker );
        Bool isIdle();

        void finish( GLuint marker );
        void finishAll();

    private:
        pthread_t _thread;

        GLuint _marker;
        GLuint _markerCompleted;

        struct ContextInfo
        {
            Display*   display;
            GLXContext context;
            XID        drawable;
        };
    
        struct ContextKey
        {
            Display*   display;
            GLXContext context;
        };

        struct HashContextKey
        {
            size_t operator()(const ContextKey& ctx) const
                {  
                    return ((size_t)(ctx.context));
                }

            bool operator()(const ContextKey& ctx1,const ContextKey& ctx2) const
                {
                    return ( ctx1.display == ctx2.display &&
                             ctx1.context == ctx2.context );
                }
        };

        struct Command
        {
        public:
            enum ID
            {
                ID_XMAKECURRENT,
                ID_BINDTEXTURE,
                ID_TEXIMAGE2D,
                ID_TEXIMAGE3D,
                ID_ALL
            };

            Command( ID commandID ) : id(commandID) {}

            ID     id;
            GLuint marker;
            union
            {
                struct
                {
                    ContextKey    key;
                } XMakeCurrent;
                
                struct
                {
                    GLenum        target;
                    GLuint        texture;
                } bindTexture;
                
                struct
                {
                    GLuint        texture;
                    GLenum        target;
                    GLint         level;
                    GLint         internalformat;
                    GLsizei       width;
                    GLsizei       height;
                    GLint         border;
                    GLenum        format;
                    GLenum        type;
                    const GLvoid *pixels;
                } texImage2D;

                struct
                {
                    GLuint        texture;
                    GLenum        target;
                    GLint         level;
                    GLint         internalformat;
                    GLsizei       width;
                    GLsizei       height;
                    GLsizei       depth;
                    GLint         border;
                    GLenum        format;
                    GLenum        type;
                    const GLvoid *pixels;
                } texImage3D;
            } data;
        };

        typedef
        Sgi::hash_map<ContextKey, ContextInfo, HashContextKey, HashContextKey>
        ContextMap;

        ContextMap            _mappedContexts;
    
        std::list<Command*>   _commands;
        std::vector<Command*> _commandCache;

        class Sync
        {
        public:
            Sync() 
                {
                    pthread_mutex_init( &mutex, NULL );
                    pthread_cond_init(  &cond,  NULL );
                }
            ~Sync()
                {
                    pthread_cond_destroy(  &cond  );
                    pthread_mutex_destroy( &mutex );
                }
            
            pthread_mutex_t mutex;
            pthread_cond_t  cond;
        };
    
        Sync     _commandSync, _markerSync;

        Command*     _newCommand( Command::ID commandID );

        // helper thread
        static void* _childEntry( void* arg );
        void*        _child();
        void         _initChild();

        void _XMakeCurrent( Command* command );
        void _bindTexture( Command* command );
        void _texImage2D( Command* command );
        void _texImage3D( Command* command );

        void (glAsync::Thread::*_cmdHandler[Command::ID_ALL])( Command* command );
    };
}

#endif // _GL_ASYNC_H_
