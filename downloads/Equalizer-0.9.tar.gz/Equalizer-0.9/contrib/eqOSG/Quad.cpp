/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008 by Felix Heide                                       *
 * felix.heide@student.uni-siegen.de                                       *
 *                                                                         *
 * Copyright (C) 2008 by Thomas McGuire                                    *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#include "Quad.h"

#include <osg/Geode>
#include <osg/Geometry>

osg::ref_ptr<osg::Node> Quad::createQuad() const
{
    // Create geode to attach drawable
    osg::ref_ptr<osg::Geode> geode= new osg::Geode;
    geode->addDrawable(createDrawable().get());
    geode->setDataVariance(osg::Object::STATIC);
    return geode.get();
}


osg::ref_ptr<osg::Drawable> Quad::createDrawable() const
{
    // ######Begin of Definition of Geometry geom
    osg::ref_ptr<osg::Geometry> geom = new osg::Geometry;

    // 1) ##Definition of Data
    // Define Vertices
    osg::ref_ptr<osg::Vec3Array> data = new osg::Vec3Array;
    data->push_back( osg::Vec3(-1.f, 0.f, -1.f));
    data->push_back( osg::Vec3(-1.f, 0.f,  1.f));
    data->push_back( osg::Vec3( 1.f, 0.f,  1.f));
    data->push_back( osg::Vec3( 1.f, 0.f, -1.f));

    // Define Color
    osg::ref_ptr<osg::Vec4Array> color = new osg::Vec4Array;
    color->push_back( osg::Vec4(1.0f, 0.f, 0.f, 0.0));

    // Define Normals
    osg::ref_ptr<osg::Vec3Array> normals= new osg::Vec3Array;
    normals->push_back( osg::Vec3(0.f, -1.f, 0.f));

    // 2) ##Assign of Data
    // Assign Vertex-Data
    geom->setVertexArray(data.get());
    geom->addPrimitiveSet( new osg::DrawArrays(osg::PrimitiveSet::QUADS,0,4));
    // Assign Color
    geom->setColorBinding( osg::Geometry::BIND_OVERALL );
    geom->setColorArray(color.get());
    // Assign Normals
    geom->setNormalBinding( osg::Geometry::BIND_OVERALL );
    geom->setNormalArray(normals.get());

    geom->setDataVariance(osg::Object::STATIC);
    // #######End of Definition of Geometry geom
    return geom.get();
}
