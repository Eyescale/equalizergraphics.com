/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008, 2009 by Thomas McGuire                              *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#include "Config.h"

#include "Util.h"

#include <eq/client/configEvent.h>

#include <osg/Math>

static const float maxVerticalAngle = osg::PI;
static const float minVerticalAngle = 0.2;
static const float mouseViewSpeed = 0.005f;
static const float defaultCameraHorizontalAngle( 0.0f );
static const float defaultCameraVerticalAngle( osg::PI / 2.0f );
static const eq::Vector3f defaultCameraViewingDirection( 0., 0., -1. );

Config::Config( eq::base::RefPtr< eq::Server > parent )
    : eq::Config( parent ),
      mMoveDirection( 0.0f, 0.0f, 0.0f ),
      mCameraAngleHor( defaultCameraHorizontalAngle ),
      mCameraAngleVer( defaultCameraVerticalAngle ),
      mCameraWalkingVector( 0., 0., -1. ),
      mPointerXDiff( 0.0f ),
      mPointerYDiff( 0.0f )
{
}

bool Config::init()
{
    registerObject( &mFrameData );
    mInitData.setFrameDataID( mFrameData.getID() );
    registerObject( &mInitData );
    mFrameData.mData.angle = 0.;
    return eq::Config::init( mInitData.getID() );
}

bool Config::exit()
{
    bool ret = eq::Config::exit();
    mInitData.setFrameDataID( EQ_ID_INVALID );
    deregisterObject( &mInitData );
    deregisterObject( &mFrameData );
    return ret;
}

void Config::updateFrameData( float elapsed )
{
    //
    // Update the rotation of the model
    //
    mFrameData.mData.angle += 0.001f * elapsed;
    if ( mFrameData.mData.angle > 2 * 3.14 )
        mFrameData.mData.angle = 0.;

    //
    // Update the viewing direction based on the mouse movement
    //
    mCameraAngleHor += mouseViewSpeed * mPointerXDiff;
    if ( mCameraAngleHor > 2 * osg::PI || mCameraAngleHor < -2 * osg::PI )
        mCameraAngleHor = 0.0f;
    mCameraAngleVer += mouseViewSpeed * mPointerYDiff;
    if ( mCameraAngleVer > maxVerticalAngle )
        mCameraAngleVer = maxVerticalAngle;
    if ( mCameraAngleVer < minVerticalAngle )
        mCameraAngleVer = minVerticalAngle;
    mPointerXDiff = mPointerYDiff = 0.0f;
    eq::Vector3f cameraViewingDirection;
    cameraViewingDirection.x() = sin( mCameraAngleHor ) * sin( mCameraAngleVer );
    cameraViewingDirection.z() = -cos( mCameraAngleHor ) * sin( mCameraAngleVer );
    cameraViewingDirection.y() = cos( mCameraAngleVer );
    mCameraWalkingVector = cameraViewingDirection;
    mCameraWalkingVector.y() = 0.0f;

    //
    // Save camera data to frame data and update the camera position
    //
    mFrameData.mData.cameraPosition += mMoveDirection * elapsed;
    mFrameData.mData.cameraLookAtPoint = mFrameData.mData.cameraPosition + cameraViewingDirection;
    mFrameData.mData.cameraUpVector = eq::Vector3f( 0., 1., 0. );
}

uint32_t Config::startFrame()
{
    float elapsed = mClock.getTimef();
    mClock.reset();
    updateFrameData( elapsed );
    const uint32_t version = mFrameData.commit();
    return eq::Config::startFrame( version );	
}

void Config::setInitData( const InitData& data )
{
    mInitData = data;
}

const InitData& Config::getInitData() const
{
    return mInitData;
}

bool Config::mapData( const uint32_t initDataID )
{
    if( mInitData.getID() == EQ_ID_INVALID )
    {
        EQCHECK( mapObject( &mInitData, initDataID ) );
        unmapObject( &mInitData );
    }
    else
        EQASSERT( mInitData.getID() == initDataID );

    return true;
}

bool Config::handleEvent( const eq::ConfigEvent* event )
{
    const float moveSpeed = 0.05f;

    bool eventHandled = false;
    switch ( event->data.type )
    {
        // Set mMoveDirection to a null vector after a key is released so that the updating
        // of the camera position stops
        case eq::Event::KEY_RELEASE:
            if ( event->data.keyPress.key >= 261 && event->data.keyPress.key <= 266 )
                mMoveDirection = eq::Vector3f( 0, 0, 0 );
        break;

        // Change mMoveDirection when the appropriate key is pressed
        case eq::Event::KEY_PRESS:
            switch ( event->data.keyPress.key )
            {
                case eq::KC_LEFT:
                    mMoveDirection = norm( orthographicVector( mCameraWalkingVector ) ) * moveSpeed;
                    eventHandled = true;
                    break;

                case eq::KC_UP:
                    mMoveDirection = norm( mCameraWalkingVector ) * moveSpeed;
                    eventHandled = true;
                    break;

                case eq::KC_RIGHT:
                    mMoveDirection = -norm( orthographicVector( mCameraWalkingVector ) ) * moveSpeed;
                    eventHandled = true;
                    break;

                case eq::KC_DOWN:
                    mMoveDirection = -norm( mCameraWalkingVector ) * moveSpeed;
                    eventHandled = true;
                    break;

                case eq::KC_PAGE_UP:
                    mMoveDirection.y() = moveSpeed;
                    eventHandled = true;
                    break;

                case eq::KC_PAGE_DOWN:
                    mMoveDirection.y() = -moveSpeed;
                    eventHandled = true;
                    break;
            }
            break;

        // Turn left and right, up and down with mouse pointer
        case eq::Event::POINTER_MOTION:
            if ( event->data.pointerMotion.buttons == eq::PTR_BUTTON1 &&
                 event->data.pointerMotion.x<=event->data.context.pvp.w &&
                 event->data.pointerMotion.x>= 0 &&
                 event->data.pointerMotion.y<=event->data.context.pvp.h &&
                 event->data.pointerMotion.y>= 0){
                mPointerXDiff += event->data.pointerMotion.dx;
                mPointerYDiff += event->data.pointerMotion.dy;
                eventHandled = true;
            }
            break;
    }

    // Let Equalizer handle any events we don't handle ourselves here, like the
    // escape key for closing the application.
    if ( !eventHandled )
        return eq::Config::handleEvent( event );
}
