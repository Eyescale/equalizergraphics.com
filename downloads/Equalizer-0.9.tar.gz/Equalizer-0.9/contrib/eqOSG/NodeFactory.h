/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008 by Thomas McGuire                                    *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#ifndef NODEFACTORY_H
#define NODEFACTORY_H

#include "Channel.h"
#include "Config.h"
#include "Node.h"
#include "Pipe.h"

#include <eq/client/nodeFactory.h>

class NodeFactory : public eq::NodeFactory
{
public:
    virtual eq::Channel* createChannel( eq::Window* parent )
        { return new Channel( parent ); }
    virtual eq::Config* createConfig( eq::ServerPtr parent )
        { return new Config( parent ); }
    virtual eq::Node* createNode( eq::Config* parent )
       { return new Node( parent ); }
     virtual eq::Pipe* createPipe( eq::Node* parent )
       { return new Pipe( parent ); }
};

#endif
