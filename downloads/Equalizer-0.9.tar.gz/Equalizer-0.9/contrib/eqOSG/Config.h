/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008, 2009 by Thomas McGuire                              *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#ifndef CONFIG_H
#define CONFIG_H

#include "FrameData.h"
#include "InitData.h"

#include <eq/base/clock.h>
#include <eq/client/config.h>
#include <eq/client/server.h>
#include <eq/client/client.h>

class Config : public eq::Config
{
public:

    Config( eq::base::RefPtr< eq::Server > parent );

    /** Reimplemented */
    virtual bool init();

    /** Reimplemented */
    virtual bool exit();

    /** Reimplemented */
    virtual uint32_t startFrame();

    /**
     * Reimplemented for camera controls.
     * If a keypress happens, this function updates mMoveDirection, so that the new camera
     * position can be calculated in updateFrameData().
     * If a mouse move event happens, this function updates mPointerXDiff and mPointerYDiff,
     * so that the new camera viewing direction can be calculated in updateFrameData().
     */
    virtual bool handleEvent( const eq::ConfigEvent* event );

    void setInitData( const InitData& data );
    const InitData& getInitData() const;
    bool mapData( const uint32_t initDataID );

protected:
    void updateFrameData( float elapsed );

private:

    // The vector of the camera movement in the current frame. This value is computed in
    // handleEvent() and then later in updateFrameData(), the camera position is updated
    // based on this.
    eq::Vector3f mMoveDirection;

    // Same as the camera viewing direction, only that the y component is always zero.
    // Used in handleEvent() to calculate mMoveDirection.
    eq::Vector3f mCameraWalkingVector;

    // The differences of the mouse pointer position of this and the last frame, in pixels.
    // Used to calculate the new viewing direction
    int32_t mPointerXDiff;
    int32_t mPointerYDiff;

    // The current angles of the camera. The current camera viewing direction is calculated
    // based on this.
    float mCameraAngleHor;
    float mCameraAngleVer;

    // Distributed objects
    InitData mInitData;
    FrameData mFrameData;

    // Clock used to measure the amount of time the last frame took, to make it
    // possible to have a framerate-independent rotation
    eq::base::Clock mClock;
};

#endif
