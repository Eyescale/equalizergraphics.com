/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008 by Felix Heide                                       *
 * felix.heide@student.uni-siegen.de                                       *
 *                                                                         *
 * Copyright (C) 2008 by Thomas McGuire                                    *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#ifndef PIPE_H
#define PIPE_H

#include "EqViewer.h"
#include "FrameData.h"


#include <eq/client/pipe.h>
#include <osg/MatrixTransform>
#include <osg/Node>

/**
 * The Pipe holds the viewer and the frame data.
 * Each frame, it updates the scene graph of the viewer with the
 * new data of the frame data. The frame data is synced with the server.
 */
class Pipe : public eq::Pipe
{
public:
    Pipe( eq::Node* parent );

    const FrameData::Data& getFrameData() const;
    osg::ref_ptr<EqViewer> getViewer() const;

protected:
    virtual ~Pipe();

    /**
     * Creates the scene graph and registers the frame data, so it can be
     * synced with the server later.
     */
    virtual bool configInit( const uint32_t initID );

    /**
     * Deregisters the frame data.
     */
    virtual bool configExit();

    /**
     * Syncs the frame data with the server and calls updateSceneGraph().
     */
    virtual void frameStart( const uint32_t frameID,
                             const uint32_t frameNumber );

    /**
     * Updates the scene graph with the new data of the frame data.
     * Currently this only sets the rotation of the quad.
     */
    void updateSceneGraph();

    /**
     * Creates the complete scenegraph and returns the root node.
     * Currently, the scene graph is a red quad.
     */
    osg::ref_ptr<osg::Node> createSceneGraph();

private:
    FrameData mFrameData;
    osg::ref_ptr<osg::MatrixTransform> mRotateMatrix;
    osg::ref_ptr<EqViewer> mViewer;
    bool mUsesModel;
    std::string mModelFile;
};

#endif
