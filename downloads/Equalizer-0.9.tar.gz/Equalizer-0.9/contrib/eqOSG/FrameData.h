/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008, 2009 by Thomas McGuire                              *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#ifndef FRAMEDATA_H
#define FRAMEDATA_H

#include <eq/net/object.h>
#include <eq/client/types.h>
#include <vmmlib/vector.hpp>

/**
 * FrameData holds all data which is updated each frame.
 * It is sent by the server to all render clients.
 *
 * Currently, it contains the rotating angle of the quad.
 */
class FrameData : public eq::net::Object
{

public:

    FrameData();

    struct Data
    {
        /// The angle of the rotating model
        float angle;

        /// The position of the camrra, in world coordinates
        eq::Vector3f cameraPosition;

        /// The point the camera is looking at, in world coordinates
        eq::Vector3f cameraLookAtPoint;

        /// The up vector of the camera
        eq::Vector3f cameraUpVector;
    };

    Data mData;

protected:

    /** Reimplemented */
    virtual eq::net::Object::ChangeType getChangeType() const;

    /** Reimplemented. **/
    virtual void getInstanceData( eq::net::DataOStream& );

    /** Reimplemented. **/
    virtual void applyInstanceData( eq::net::DataIStream& );
};


#endif
