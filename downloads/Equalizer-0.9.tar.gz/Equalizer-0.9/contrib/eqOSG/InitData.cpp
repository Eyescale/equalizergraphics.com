/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008 by Thomas McGuire                                    *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#include "InitData.h"

#include <eq/eq.h>

InitData::~InitData()
{
    setFrameDataID( EQ_ID_INVALID );
}

void InitData::setFrameDataID( const uint32_t id )
{
    mFrameDataID = id;
}

uint32_t InitData::getFrameDataID() const
{
    return mFrameDataID;
}

void InitData::getInstanceData( eq::net::DataOStream& stream )
{
    stream << mFrameDataID << mModelFileName << mLoadModel;
}

void InitData::applyInstanceData( eq::net::DataIStream& stream )
{
    stream >> mFrameDataID >> mModelFileName >> mLoadModel;
    EQASSERT( mFrameDataID != EQ_ID_INVALID );
}

void InitData::setLoadModel( bool loadModel )
{
    mLoadModel = loadModel;
}

bool InitData::loadModel() const
{
    return mLoadModel;
}

void InitData::setModelFileName( const std::string &fileName )
{
    mModelFileName = fileName;
}

std::string InitData::modelFileName() const
{
    return mModelFileName;
}


bool InitData::parseCommandLine( char **argv, int argc )
{
    for ( int i = 0; i < argc; i++ )
    {
        std::string argument( argv[i] );
        std::string modelPrefix( "--model=" );
        if ( argument.find( modelPrefix ) == 0 )
        {
            std::string modelFile = argument.substr( modelPrefix.size(), std::string::npos );
            setModelFileName( modelFile );
            setLoadModel( true );
        }
    }

    return true;
}
