/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008 by Felix Heide                                       *
 * felix.heide@student.uni-siegen.de                                       *
 *                                                                         *
 * Copyright (C) 2008, 2009 by Thomas McGuire                              *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#ifdef WIN32
#define EQ_IGNORE_GLEW
#endif

#ifndef WIN32
#include <eq/eq.h> // to prevent "gl.h included before glew.h"
#endif

#include "Pipe.h"

#include "Config.h"
#include "SceneReader.h"
#include "Quad.h"

#include <osg/Geometry>

Pipe::Pipe( eq::Node* parent )
    : eq::Pipe( parent )
{
    mViewer = new EqViewer();
}

Pipe::~Pipe()
{
}

const FrameData::Data& Pipe::getFrameData() const
{
    return mFrameData.mData;
}

osg::ref_ptr<EqViewer> Pipe::getViewer() const
{
    return mViewer;
}

bool Pipe::configInit( const uint32_t initID )
{
    if( !eq::Pipe::configInit( initID ) )
        return false;

    // Get InitData and map FrameData
    Config* config = static_cast<Config*>( getConfig() );
    const InitData& initData = config->getInitData();
    const uint32_t frameDataID = initData.getFrameDataID();
    mUsesModel = initData.loadModel();
    mModelFile = initData.modelFileName();
    const bool mapped = config->mapObject( &mFrameData, frameDataID );
    EQASSERT( mapped );

    // set the scene to render
    mViewer->setSceneData(createSceneGraph().get());
    return mapped;
}

bool Pipe::configExit()
{
    getConfig()->unmapObject( &mFrameData );
    return eq::Pipe::configExit();
}

void Pipe::frameStart( const uint32_t frameID,
                       const uint32_t frameNumber )
{
    eq::Pipe::frameStart( frameID, frameNumber );
    mFrameData.sync( frameID );
    updateSceneGraph();
}

osg::ref_ptr<osg::Node> Pipe::createSceneGraph()
{
    // Create the root node
    osg::ref_ptr<osg::Group> root = new osg::Group;
    root->setDataVariance(osg::Object::STATIC);

    // Enable lighting and LIGHT0 in root node
    osg::StateSet* state = root->getOrCreateStateSet();
    state->setMode(GL_LIGHTING, osg::StateAttribute::ON);
    state->setMode(GL_LIGHT0, osg::StateAttribute::ON);

    // Create light and lightsource-Node
    osg::ref_ptr<osg::Light> light0 = new osg::Light;
    light0->setLightNum(0); //light0 is now GL-Light0
    light0->setPosition(osg::Vec4(0.f, 0.f, 0.f, 1.f));
    light0->setAmbient(osg::Vec4(1.0f,0.0f,0.0f,1.0f));
    light0->setDiffuse(osg::Vec4(1.0f,0.0f,0.0f,1.0f));
    light0->setDirection(osg::Vec3(0.f, 1.f, 0.f));
    light0->setSpotCutoff( 30.f);
    light0->setSpotExponent(50.0f);

    osg::ref_ptr<osg::LightSource> ls0 = new osg::LightSource;
    ls0->setLight(light0.get());
    ls0->setDataVariance(osg::Object::STATIC);


    //Create and Attach Translation Matrices
    osg::Matrix matrix;
    {
        // Matrix for Rotation of geode (with drawable)
        osg::ref_ptr<osg::MatrixTransform> dynamicRotationNode = new osg::MatrixTransform;
        matrix.makeRotate( 0.0, osg::Vec3( 0., 1., 0. ) );
        dynamicRotationNode->setMatrix(matrix);

        // Load either a model from file or create a quad, then attach it to the rotation node.
        bool useQuad = !mUsesModel;
        osg::ref_ptr<osg::Node> geometryChild;
        if ( mUsesModel ) {
            SceneReader sceneReader;
            geometryChild = sceneReader.readModel( mModelFile );
            if ( !geometryChild.valid() ) {
                std::cout << "Falling back to drawing a quad." << std::endl;
                useQuad = true;
            }
        }
        if ( useQuad ) {
            Quad quad;
            geometryChild = quad.createQuad();
        }
        dynamicRotationNode->addChild( geometryChild.get() );
        dynamicRotationNode->setDataVariance( osg::Object::DYNAMIC );
        mRotateMatrix = dynamicRotationNode;

        // Rotate the object 90 degree around the X axis, to match the coordinate system
        // we use
        osg::ref_ptr<osg::MatrixTransform> staticRotationNode = new osg::MatrixTransform;
        matrix.makeRotate( -osg::PI_2, osg::Vec3( 1., 0., 0. ) );
        staticRotationNode->setMatrix( matrix );
        staticRotationNode->setDataVariance( osg::Object::STATIC );
        staticRotationNode->addChild(dynamicRotationNode);

        root->addChild( staticRotationNode );
    }
    {
        // Matrix for Translation of Lightsource (with light0)
        osg::ref_ptr<osg::MatrixTransform> lightTranslateNode = new osg::MatrixTransform;
        matrix.makeTranslate(0.f,-5.f,0.f);
        lightTranslateNode->setMatrix(matrix);
        root->addChild(lightTranslateNode.get());
        lightTranslateNode->addChild(ls0.get());
        lightTranslateNode->setDataVariance(osg::Object::STATIC);
    }
    return root.get();
}

void Pipe::updateSceneGraph()
{
    osg::Matrix rotation;
    float angle = getFrameData().angle;
    rotation.makeRotate( angle, osg::Vec3( 0., 1., 0. ) );
    mRotateMatrix->setMatrix( rotation );
}

