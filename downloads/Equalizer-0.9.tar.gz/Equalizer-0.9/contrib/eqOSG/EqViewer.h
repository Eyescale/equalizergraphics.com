/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008 by Felix Heide                                       *
 * felix.heide@student.uni-siegen.de                                       *
 *                                                                         *
 * Copyright (C) 2008 by Thomas McGuire                                    *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#ifndef EQVIEWER_H
#define EQVIEWER_H

namespace eq {
    class Channel;
}

#include <osgViewer/Viewer>

/**
 * A Viewer which can be used with Equalizer.
 *
 * A normal Viewer from OSG would try to create its own windows, which
 * we don't want to, since they are set up by Equalizer for us.
 *
 * The EqViewer solves this by setting the correct context and viewport.
 *
 * Call setViewport() in your frameDraw() method.
 */
class EqViewer : public osgViewer::Viewer
{
public:
    EqViewer();

    /**
     * Sets the viewport of the Camara of the scene so that it matches
     * the viewport of the given Equalizer channel.
     */
    void setViewport(eq::Channel *channel);

private:
    osg::ref_ptr<osgViewer::GraphicsWindowEmbedded> mContext;
};

#endif
