/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008 by Felix Heide                                       *
 * felix.heide@student.uni-siegen.de                                       *
 *                                                                         *
 * Copyright (C) 2008, 2009 by Thomas McGuire                              *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#include "Channel.h"

#include "EqViewer.h"
#include "Pipe.h"
#include "Util.h"

#include <osg/ref_ptr>

Channel::Channel( eq::Window* parent )
    : eq::Channel( parent )
{
}

bool Channel::configInit( const uint32_t initID )
{
    if( !eq::Channel::configInit( initID ))
        return false;

    return true;
}

osg::Matrix Channel::setPlainViewMatrix( const Pipe *pipe ) const
{
  const FrameData::Data &data = pipe->getFrameData();
  
  
  const osg::Vec3f pos = osg::Vec3f( data.cameraPosition.x(),
                    data.cameraPosition.y(),
                    data.cameraPosition.z() );
  const osg::Vec3f view = osg::Vec3f( data.cameraLookAtPoint.x(),
                     data.cameraLookAtPoint.y(),
                     data.cameraLookAtPoint.z() );
  const osg::Vec3f up = osg::Vec3f( 
				   data.cameraUpVector.x(),
                   data.cameraUpVector.y(),
                   data.cameraUpVector.z() );
  
  pipe->getViewer()->getCamera()->setViewMatrixAsLookAt( pos, view, up );
  
  return pipe->getViewer()->getCamera()->getViewMatrix();
}

void Channel::frameDraw( const uint32_t frameID )
{
    // setup OpenGL State
    eq::Channel::frameDraw( frameID );

    // Get the pipe and the viewer
    Pipe *pipe = static_cast<Pipe*>( getPipe() );
    osg::ref_ptr<EqViewer> viewer = pipe->getViewer();

    // Set the correct viewport (which can change each frame)
    viewer->setViewport( this );

    // Set a view matrix and make sure it is multiplied with the head
    // matrix of Equalizer
    osg::Matrix headView = setPlainViewMatrix( pipe );
    headView.postMult( vmmlToOsg( getHeadTransform() ) );
    viewer->getCamera()->setViewMatrix( headView );

    // Render the scene graph
    viewer->frame();
}
