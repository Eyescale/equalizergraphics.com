/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008 by Thomas McGuire                                    *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#ifdef WIN32
#define EQ_IGNORE_GLEW 
#endif

#include "Application.h"
#include "InitData.h"
#include "NodeFactory.h"

#include <eq/client/init.h>
#include <eq/client/server.h>

using namespace std;

int main( const int argc, char** argv )
{
    // 1. parse arguments
    InitData initData;
    if ( !initData.parseCommandLine( argv, argc ) )
        return -1;

    // 2. Equalizer initialization
    NodeFactory nodeFactory;
    if( !eq::init( argc, argv, &nodeFactory ) )
    {
        std::cout << "Equalizer init failed" << endl;
        return EXIT_FAILURE;
    }

    // 3. initialization of local client node
    eq::base::RefPtr<Application> client = new Application( initData );
    if( !client->initLocal( argc, argv ) )
    {
        std::cout << "Can't init client" << endl;
        eq::exit();
        return EXIT_FAILURE;
    }

    // 4. run client
    const int ret = client->run();

    // 5. cleanup and exit
    client->exitLocal();

    client = 0;

    eq::exit();
    return ret;
}
