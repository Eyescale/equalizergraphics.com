/***************************************************************************
 * eqOSG - An example application which uses OpenSceneGraph with Equalizer *
 *                                                                         *
 * Copyright (C) 2008 by Thomas McGuire                                    *
 * thomas.mcguire@student.uni-siegen.de                                    *
 *                                                                         *
 * This program is free software; you can redistribute it and/or           *
 * modify it under the terms of the GNU Lesser General Public              *
 * License as published by the Free Software Foundation; either            *
 * version 2.1 of the License, or (at your option) any later version.      *
 *                                                                         *
 * This program is distributed in the hope that it will be useful,         *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of          *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       *
 * Lesser General Public License for more details.                         *
 *                                                                         *
 * You should have received a copy of the GNU Lesser General Public        *
 * License along with this library; if not, write to the Free Software     *
 * Foundation, Inc., 51 Franklin Street,                                   *
 * Fifth Floor, Boston, MA  02110-1301  USA                                *
 ***************************************************************************/
#ifndef INITDATA_H
#define INITDATA_H

#include <eq/net/object.h>

/**
 * The init data holds all data which is needed during initalization.
 * It is sent by the server to all render clients.
 *
 * It holds the frame data ID, so all clients can sync the frame data object.
 * It also holds whether to load a model from file, and if so, the filename of said model.
  */
class InitData : public eq::net::Object
{
public:

    ~InitData();
    void setFrameDataID( const uint32_t id );
    uint32_t getFrameDataID() const;
    void setLoadModel( bool loadModel );
    bool loadModel() const;
    void setModelFileName( const std::string& fileName );
    std::string modelFileName() const;

    /**
     * Parses the command line arguments and puts the things it can parse
     * into the init data.
     *
     * @return true if the command line was successfully parsed, false otherwise.
     */
    bool parseCommandLine( char **argv, int argc );


protected:

    /** Reimplemented */
    virtual void getInstanceData( eq::net::DataOStream& stream );

    /** Reimplemented */
    virtual void applyInstanceData( eq::net::DataIStream& stream );

private:
    uint32_t mFrameDataID;
    bool mLoadModel;
    std::string mModelFileName;
};

#endif
