#include "jacobi_test.hpp"

namespace vmml
{

bool
jacobi_test::run()
{
    bool ok = true;
    


    return ok;
}

} // namespace vmml

