#define integer f2c_fix_integer
#define uinteger f2c_fix_uinteger
typedef int f2c_fix_integer;
typedef unsigned int f2c_fix_uinteger;
