vmmlib
======

A templatized C++ vector and matrix math library. For more information
please see http://vmmlib.sourceforge.net/
