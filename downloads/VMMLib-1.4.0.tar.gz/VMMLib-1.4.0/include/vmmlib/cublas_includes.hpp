#ifndef __VMML__CUBLAS_INCLUDES__HPP__
#define __VMML__CUBLAS_INCLUDES__HPP__

#include <cuda_runtime_api.h>
#include <cublas_v2.h>

#endif /* __VMML__CUBLAS_INCLUDES__HPP__ */

