Place these files here

/Developer/Library/PrivateFrameworks/XcodeEdit.framework/Versions/A/Resources/

and restart XCode.

Hopefully they will add something to the readability of .eqc files.

-Stephen Furlani
stephen.furlani@gmail.com
