vmmlib
======

A templatized C++ vector and matrix math library. For more information
please see http://vmml.github.com/vmmlib/

License: (revised) BSD

VMMLib depends on LAPACK and BLAS, if you just want to use VMMLib basic
without depending on LAPACK/BLAS, don't include the affected header files. 



