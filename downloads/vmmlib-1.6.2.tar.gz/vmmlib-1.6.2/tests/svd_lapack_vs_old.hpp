#ifndef __VMML__SVD_LAPACK_VS_OLD__HPP__
#define __VMML__SVD_LAPACK_VS_OLD__HPP__

#include "performance_test.hpp"

namespace vmml
{

class svd_lapack_vs_old : public performance_test
{
public:
    virtual void run();


}; // class svd_lapack_vs_old

} // namespace vmml

#endif

