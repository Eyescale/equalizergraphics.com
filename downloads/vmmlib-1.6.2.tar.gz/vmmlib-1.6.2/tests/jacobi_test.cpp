#include "jacobi_test.hpp"

#define TEST( x ) \
{ \
    ok = x; \
    global_ok &= ok; \
}

namespace vmml
{

bool
jacobi_test::run()
{
    bool global_ok = true;
    


    return global_ok;
}

} // namespace vmml

