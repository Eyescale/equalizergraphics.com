
/* Copyright (c) 2005-2006, Stefan Eilemann <eilemann@gmail.com> 
   All rights reserved. */

// $Revision: 11 $

// TODO NV_fence support

#include "glAsync.h"

#include <iostream>
#include <pthread.h>

using namespace glAsync;
using namespace std;

/** The Thread instance used by the glAsync functions. */
static glAsync::Thread _thread;

// OpenGL extensions
static bool isExtensionSupported(const char *extension);

//===========================================================================
// Implementation - Application thread
//===========================================================================

//---------------------------------------------------------------------------
// Context management
//---------------------------------------------------------------------------
Bool glAsync::XMapContext( Display* display, XVisualInfo* visInfo,
                      GLXContext context )
{
    return _thread.XMapContext( display, visInfo, context );
}
Bool Thread::XMapContext( Display* display, XVisualInfo* visInfo,
                          GLXContext context )
{
    const char* displayName = DisplayString( display );
    Display*    display2    = XOpenDisplay( displayName );
    if( display2 == NULL )
    {
        cerr << "Can't open display: " << XDisplayName( displayName ) << endl;
        return False;
    }

    const Bool direct   = glXIsDirect( display, context );
    GLXContext context2 = glXCreateContext( display2, visInfo, context, direct);
    if( context2 == NULL )
    {
        XCloseDisplay( display2 ); 
        cerr << "Can't create context" << endl;
        return False;
    }

    int screen2 = DefaultScreen( display2 );
    XID drawable2 = XCreateSimpleWindow( display2, 
                                         DefaultRootWindow( display2 ),
                                         0, 0, 
                                         DisplayWidth( display2, screen2 ), 
                                         DisplayHeight( display2, screen2 ), 
                                         0, 0, 0 );
    if( !drawable2 )
    {
        XCloseDisplay( display2 );
        cerr << "Can't create drawable" << endl;
        return False;
    }

    if( _mappedContexts.empty( ))
    {
        _marker         = 0;
#ifdef GL_APPLE_fence
        _useAPPLE_fence = false;
#endif

        pthread_attr_t attributes;
        pthread_attr_init( &attributes );
        pthread_attr_setscope( &attributes, PTHREAD_SCOPE_SYSTEM );

        const int error = pthread_create( &_thread, &attributes,
                                          _childEntry, &_thread );
        if( error )
        {
            XCloseDisplay( display2 );
            cerr << "Error creating pthread: " << strerror( error ) << endl; 
            return False;
        }
    }

    ContextKey   key  = { display, context };
    ContextInfo  info = { display2, context2, drawable2 };

    _mappedContexts[key] = info;
    return True;
}

void glAsync::XUnmapContext( Display* display, GLXContext context )
{
    _thread.XUnmapContext( display, context );
}

void Thread::XUnmapContext( Display* display, GLXContext context )
{
    ContextKey           key  = { display, context };
    ContextMap::iterator iter = _mappedContexts.find(key);

    if( iter == _mappedContexts.end( ))
        return;

    _mappedContexts.erase( iter );

    ContextInfo& info = (*iter).second;
    XCloseDisplay( info.display );

    if( _mappedContexts.empty( )) // stop thread & cleanup
    {
        // stop thread
        pthread_mutex_lock( &_commandSync.mutex );
        _commands.push_back( NULL );
        
        pthread_cond_signal( &_commandSync.cond );
        pthread_mutex_unlock( &_commandSync.mutex );
        pthread_join( _thread, NULL );

        // cleanup
        const size_t nCommands = _commandCache.size();
        for( size_t i=0; i<nCommands; ++i )
            delete _commandCache[i];
        _commandCache.clear();
    }
}

Thread::Command* Thread::_newCommand( Command::ID commandID )
{
    Command* command;

    if( _commandCache.empty( ))
        command = new Command( commandID );
    else
    {
        const int last = _commandCache.size() - 1;
        command = _commandCache[last];
        _commandCache.resize( last, NULL );
    }

    command->id = commandID;
    command->marker = ++_marker;

// in reality _marker never overflows, therefore don't check it by default
#ifdef GLASYNC_CHECK_OVERFLOW
    if( _marker > 1 )
        return command;

    // overflow of marker occured
    finish( _marker - 1 );
    _marker         = 1;
    command->marker = 1;
#endif

    return command;
}

Bool glAsync::XMakeCurrent( Display* display, GLXContext context )
{
    return _thread.XMakeCurrent( display, context );
}
Bool Thread::XMakeCurrent( Display* display, GLXContext context )
{
    ContextKey key = { display, context };

    if( _mappedContexts.find( key ) == _mappedContexts.end() )
        return False;

    pthread_mutex_lock( &_commandSync.mutex );

    Command* command = _newCommand( Command::ID_XMAKECURRENT );

    command->data.XMakeCurrent.key = key;

    _commands.push_back( command );

    pthread_cond_signal( &_commandSync.cond );
    pthread_mutex_unlock( &_commandSync.mutex );

    return True;
}

//---------------------------------------------------------------------------
// state queries
//---------------------------------------------------------------------------
Bool glAsync::poll( GLuint marker )
{
    return _thread.poll( marker );
}
Bool Thread::poll( GLuint marker )
{
    if( _markerCompleted >= marker )
        return true;
    return false;
}

Bool glAsync::isIdle()
{
    return _thread.isIdle();
}

Bool Thread::isIdle()
{
    if( _markerCompleted >= _marker )
        return true;
    return false;
}

void glAsync::finish( GLuint marker )
{
    _thread.finish( marker );
}
void Thread::finish( GLuint marker )
{
    if( _markerCompleted >= marker )
        return;

    pthread_mutex_lock( &_markerSync.mutex );

    while( true )
    {
        if( _markerCompleted >= marker )
        {
            pthread_mutex_unlock( &_markerSync.mutex );
            return;
        }
        pthread_cond_wait( &_markerSync.cond, &_markerSync.mutex );
    }
}

void glAsync::finishAll()
{
    _thread.finishAll();
}
void Thread::finishAll()
{
    finish( _marker );
}

//---------------------------------------------------------------------------
// texture downloads
//---------------------------------------------------------------------------
void glAsync::bindTexture( GLenum target, GLuint texture )
{
    _thread.bindTexture( target, texture );
}
void Thread::bindTexture( GLenum target, GLuint texture )
{
    pthread_mutex_lock( &_commandSync.mutex );

    Command* command = _newCommand( Command::ID_BINDTEXTURE );

    command->data.bindTexture.target  = target;
    command->data.bindTexture.texture = texture;

    _commands.push_back( command );

    pthread_cond_signal( &_commandSync.cond );
    pthread_mutex_unlock( &_commandSync.mutex );
}

GLuint glAsync::texImage2D( GLenum target, GLint level, GLint internalformat,
                            GLsizei width, GLsizei height, GLint border,
                            GLenum format, GLenum type, const GLvoid *pixels )
{
    return _thread.texImage2D( target, level, internalformat, width, height, 
                               border, format, type, pixels );
}
GLuint Thread::texImage2D( GLenum target, GLint level, GLint internalformat,
                            GLsizei width, GLsizei height, GLint border,
                            GLenum format, GLenum type, const GLvoid *pixels )
{
    pthread_mutex_lock( &_commandSync.mutex );

    Command* command = _newCommand( Command::ID_TEXIMAGE2D );

    command->data.texImage2D.target         = target;
    command->data.texImage2D.level          = level;
    command->data.texImage2D.internalformat = internalformat;
    command->data.texImage2D.width          = width;
    command->data.texImage2D.height         = height;
    command->data.texImage2D.border         = border;
    command->data.texImage2D.format         = format;
    command->data.texImage2D.type           = type;
    command->data.texImage2D.pixels         = pixels;

    _commands.push_back( command );

    pthread_cond_signal( &_commandSync.cond );
    pthread_mutex_unlock( &_commandSync.mutex );
    
    return command->marker;
}

GLuint glAsync::texImage3D( GLenum target, GLint level, GLint internalformat,
                            GLsizei width, GLsizei height, GLsizei depth,
                            GLint border, GLenum format, GLenum type,
                            const GLvoid *pixels )
{
    return _thread.texImage3D( target, level, internalformat, width, height,
                               depth, border, format, type, pixels );
}
GLuint Thread::texImage3D( GLenum target, GLint level, GLint internalformat,
                            GLsizei width, GLsizei height, GLsizei depth,
                            GLint border, GLenum format, GLenum type,
                            const GLvoid *pixels )
{
    pthread_mutex_lock( &_commandSync.mutex );

    Command* command = _newCommand( Command::ID_TEXIMAGE3D );

    command->data.texImage3D.target         = target;
    command->data.texImage3D.level          = level;
    command->data.texImage3D.internalformat = internalformat;
    command->data.texImage3D.width          = width;
    command->data.texImage3D.height         = height;
    command->data.texImage3D.depth          = depth;
    command->data.texImage3D.border         = border;
    command->data.texImage3D.format         = format;
    command->data.texImage3D.type           = type;
    command->data.texImage3D.pixels         = pixels;

    _commands.push_back( command );

    pthread_cond_signal( &_commandSync.cond );
    pthread_mutex_unlock( &_commandSync.mutex );
    
    return command->marker;
}

//===========================================================================
// Implementation - Helper Thread
//===========================================================================
void Thread::_initChild()
{
    _cmdHandler[Command::ID_XMAKECURRENT] = &glAsync::Thread::_XMakeCurrent;
    _cmdHandler[Command::ID_BINDTEXTURE]  = &glAsync::Thread::_bindTexture;
    _cmdHandler[Command::ID_TEXIMAGE2D]   = &glAsync::Thread::_texImage2D;
    _cmdHandler[Command::ID_TEXIMAGE3D]   = &glAsync::Thread::_texImage3D;
}

void* Thread::_childEntry( void* arg )
{
    return ((Thread*)(arg))->_child();
}

void* Thread::_child()
{
    _initChild();

    // get first command
    pthread_mutex_lock( &_commandSync.mutex );
    while( _commands.empty() )
        pthread_cond_wait( &_commandSync.cond, &_commandSync.mutex );
    
    Command* command = _commands.front();
    _commands.pop_front();
    pthread_mutex_unlock( &_commandSync.mutex );

    while( command )
    {
        // execute command
        (this->*_cmdHandler[command->id])(command);

        _syncCommand( command->marker );

        // recycle command and retrieve next command
        pthread_mutex_lock( &_commandSync.mutex );
        _commandCache.push_back( command );

        while( _commands.empty() )
            pthread_cond_wait( &_commandSync.cond, &_commandSync.mutex );
        
        command = _commands.front();
        _commands.pop_front();
        pthread_mutex_unlock( &_commandSync.mutex );

    }

    assert( _mappedContexts.empty( ));
    return NULL;
}

// C&P from opengl.org
bool isExtensionSupported(const char *extension)
{
    /* Extension names should not have spaces. */
    GLubyte *where = (GLubyte *)strchr(extension, ' ');
    if (where || *extension == '\0')
        return false;

    const GLubyte *extensions = glGetString(GL_EXTENSIONS);

    /* It takes a bit of care to be fool-proof about parsing the OpenGL
     * extensions string. Don't be fooled by sub-strings, etc. */
    const GLubyte *start = extensions;
    while( true )
    {
        where = (GLubyte *) strstr((const char *) start, extension);
        if (!where)
            break;
        GLubyte *terminator = where + strlen(extension);
        if (where == start || *(where - 1) == ' ')
            if (*terminator == ' ' || *terminator == '\0')
                return true;
        start = terminator;
    }
    return false;
}

#ifdef GL_APPLE_fence
GLuint Thread::_newFence()
{
    if( _fenceCache.empty( ))
    {
        GLuint fences[10];
        glGenFencesAPPLE( 10, fences );
        for( int i=1; i<10; ++i )
            _fenceCache.push_back( fences[i] );
        return fences[0];
    }

    const int last = _fenceCache.size() - 1;
    GLuint fence = _fenceCache[last];
    _fenceCache.resize( last, 0 );
    
    return fence;
}

void Thread::_finishAllFences()
{
    for( list<GLuint>::iterator iter = _pendingFences.begin(); 
         iter != _pendingFences.end(); ++iter )
    {
        glFinishFenceAPPLE( *iter );
        _fenceCache.push_back( *iter );
    }
    _pendingFences.clear();
}
#endif

void Thread::_syncCommand( const uint currentMarker )
{
    GLuint markerCompleted;
#ifdef GL_APPLE_fence
    if( _useAPPLE_fence )
    {
        // mark current command
        GLuint fence = _newFence();
        glSetFenceAPPLE( fence );
        _pendingFences.push_back( fence );

        // see what is finished
        markerCompleted = currentMarker - _pendingFences.size();

        for( list<GLuint>::iterator iter = _pendingFences.begin(); 
             iter != _pendingFences.end(); )
        {
            if( !glTestFenceAPPLE( *iter ))
                break;

            _fenceCache.push_back( *iter );
            ++iter; // We are removing the front item next!
            ++markerCompleted;
            _pendingFences.pop_front();
        }
        
        // Finish everything if no other pending commands
        //   TODO: spin for command or fence completion before hard finish
        if( _commands.empty() && markerCompleted != currentMarker )
        {
            _finishAllFences();
            markerCompleted = currentMarker;
        }
        else if( _markerCompleted == markerCompleted )
            return;
    }
    else
#endif
    {
        if( !_commands.empty( ))
            // If the app completely satures this thread, we never signal
            // completion. Should introduce command to force a finish
            return;

        markerCompleted = currentMarker;
        glFinish();
    }

    pthread_mutex_lock( &_markerSync.mutex );
    _markerCompleted = markerCompleted;
    pthread_cond_signal( &_markerSync.cond );
    pthread_mutex_unlock( &_markerSync.mutex );
}

void Thread::_XMakeCurrent( Command* command )
{
    ContextInfo& info = _mappedContexts[command->data.XMakeCurrent.key];
    glXMakeCurrent( info.display, info.drawable, info.context );
    
#ifdef GL_APPLE_fence
    if( _useAPPLE_fence && !_pendingFences.empty( ))
    {
        _finishAllFences();
        pthread_mutex_lock( &_markerSync.mutex );
        _markerCompleted = command->marker-1;
        pthread_cond_signal( &_markerSync.cond );
        pthread_mutex_unlock( &_markerSync.mutex );
        
        glDeleteFencesAPPLE( _fenceCache.size(), &_fenceCache[0] );
        _fenceCache.clear();
    }

    _useAPPLE_fence = isExtensionSupported( "GL_APPLE_fence" );
#endif
}

void Thread::_bindTexture( Command* command )
{
    glBindTexture( command->data.bindTexture.target, 
                   command->data.bindTexture.texture );
}

void Thread::_texImage2D( Command* command )
{
    glTexImage2D( command->data.texImage2D.target,
                  command->data.texImage2D.level, 
                  command->data.texImage2D.internalformat,
                  command->data.texImage2D.width, 
                  command->data.texImage2D.height, 
                  command->data.texImage2D.border, 
                  command->data.texImage2D.format, 
                  command->data.texImage2D.type, 
                  command->data.texImage2D.pixels ); 
}

void Thread::_texImage3D( Command* command )
{
    glTexImage3D( command->data.texImage3D.target,
                  command->data.texImage3D.level, 
                  command->data.texImage3D.internalformat,
                  command->data.texImage3D.width, 
                  command->data.texImage3D.height, 
                  command->data.texImage3D.depth, 
                  command->data.texImage3D.border, 
                  command->data.texImage3D.format, 
                  command->data.texImage3D.type, 
                  command->data.texImage3D.pixels ); 
}
