#ifndef __VMML__CUBLAS_TYPES__HPP__
#define __VMML__CUBLAS_TYPES__HPP__


namespace vmml
{
	
	namespace cublas
	{
		
		
		typedef int  cublas_int;
								   
		
	} // namespace cublas
	
	
} // namespace vmml

#endif

