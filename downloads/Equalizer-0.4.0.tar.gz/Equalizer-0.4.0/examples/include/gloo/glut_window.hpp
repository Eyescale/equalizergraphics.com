#ifndef __GLOO__GLUT_WINDOW__H__
#define __GLOO__GLUT_WINDOW__H__

#include <gloo/opengl_includes.hpp>

#include <gloo/glut_input.hpp>
#include <gloo/glut_callback_targets.hpp>

#include <string>

namespace gloo
{

class glut_window : public glut_input
{
public:
    // ctor with mode flag 
    glut_window( const std::string& name, size_t width, size_t height, 
        unsigned int mode = 0 );
    
    // ctor with initstring
    glut_window( const std::string& name, size_t width, size_t height, 
        const std::string& init_string );

    ~glut_window();

    void start();   
    
    // redraw requests a redrawing of the screen -> useful for an app to 
    // signal that something has changed.
    static void redraw();

    void set_render_target( render_target* render_target_ );
    void set_reshape_target( reshape_target* target );
    void set_idle_target( idle_target* target );

    render_target* get_render_target();
    reshape_target* get_reshape_target();
    idle_target* get_idle_target();
   
protected:
    
    void _setup_glut( const std::string& init_string );
    void _setup_glut( unsigned int mode );

    void _init_window( size_t width, size_t height );
        
    //glut callbacks and related uglyness
    static glut_window* _instance;
    
    inline void display();
    inline void reshape( int width, int height );
    inline void on_idle();

    static void _display();
    static void _reshape( int width, int height );
    static void _on_idle();
    
    // member vars
    std::string _name;
    
    render_target*  _render_target;
    reshape_target* _reshape_target;
    idle_target*    _idle_target;

}; //class glut_window


// inline functions

inline void 
glut_window::reshape( int width, int height )
{
    if ( _reshape_target )
        _reshape_target->reshape( width, height );
}



inline void 
glut_window::on_idle()
{
    if ( _idle_target )
        _idle_target->on_idle();
}




}; //namespace gloo

#endif
