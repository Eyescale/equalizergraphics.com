#ifndef __GLOO__KEY_TARGET__H__
#define __GLOO__KEY_TARGET__H__

namespace gloo
{

class key_target
{
public:
    // every frame while key is down, this function will be called
    virtual void on_key_down( unsigned char key ) = 0;

}; // class key_target

} // namespace gloo

#endif

