#ifndef __GLOO__GLOO_ENUMS__HPP__
#define __GLOO__GLOO_ENUMS__HPP__

#include <sys/types.h>

#include <gloo/opengl_includes.hpp>

namespace gloo
{

enum data_type
{
    GLOO_UNKNOWN_DATA_TYPE = 0,
    
    GLOO_FLOAT_16,
    GLOO_FLOAT_32 = GL_FLOAT,
    GLOO_FLOAT_64 = GL_DOUBLE,

    GLOO_INT_8    = GL_BYTE,
    GLOO_UINT_8   = GL_UNSIGNED_BYTE,
    GLOO_INT_16   = GL_SHORT,
    GLOO_UINT_16  = GL_UNSIGNED_SHORT,
    GLOO_INT_32   = GL_INT,
    GLOO_UINT_32  = GL_UNSIGNED_INT,
    GLOO_INT_64   = 12,
    GLOO_UINT_64  = 13,
    GLOO_INT_128  = 14,
    GLOO_UINT_128 = 15,

}; // enum data_type



enum data_format
{
    GLOO_UNKNOWN_DATA_FORMAT,
    
    GLOO_ASCII,
    
    GLOO_BINARY,
    GLOO_BINARY_BIG_ENDIAN,
    GLOO_BINARY_LITTLE_ENDIAN

}; // enum data_format



enum vertex_attribute
{
    GLOO_UNKNOWN_VERTEX_ATTRIBUTE = 0,
    
    GLOO_POSITION,
    GLOO_POSITION_X,
    GLOO_POSITION_Y,
    GLOO_POSITION_Z,
    GLOO_POSITION_W,
    
    GLOO_NORMAL,
    GLOO_NORMAL_X,
    GLOO_NORMAL_Y,
    GLOO_NORMAL_Z,
    
    GLOO_TEXCOORD,
    GLOO_TEXCOORD_U,
    GLOO_TEXCOORD_V,
    GLOO_TEXCOORD_S,
    GLOO_TEXCOORD_T,

    GLOO_COLOR,
    GLOO_COLOR_RED      = GL_RED,
    GLOO_COLOR_GREEN    = GL_GREEN,
    GLOO_COLOR_BLUE     = GL_BLUE,
    GLOO_COLOR_ALPHA    = GL_ALPHA

}; // enum vertex_attribute

} // namespace gloo

#endif

