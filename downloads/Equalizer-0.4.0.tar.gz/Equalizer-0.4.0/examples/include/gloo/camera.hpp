#ifndef __GLOO__CAMERA__H__
#define __GLOO__CAMERA__H__

#include <gloo/opengl_includes.hpp>
#include <gloo/vmmlib_includes.hpp>
#include <gloo/viewport.hpp>
#include <gloo/glut_callback_targets.hpp>
#include <gloo/gl_data_helper.hpp>

#include <vector>

namespace gloo
{

class camera : public reshape_target
{
public:
    camera();
    
    inline void set_view();
    
    void look_at( const vec3f& eye_position, const vec3f& center, 
        const vec3f& up = vec3f( 0.0, 1.0, 0.0 ) );

    void look_at( const vec3f& aabb_min, const vec3f& aabb_max,
        double zoom = 1.0, ssize_t width = -1, ssize_t height = -1 );

    void set_ortho( const frustumf& frustum_ );
    void set_perspective( double left, double right, double bottom, double top,
        double near_plane, double far_plane );
    void set_perspective( const frustumf& frustum_ );
    
    virtual void reshape( size_t width, size_t height );

    inline mat4f& get_projection();
    inline const mat4f& get_projection() const;
    void set_projection( const mat4f& projection_ );

    inline mat4f& get_model_view();
    inline const mat4f& get_model_view() const;
    void set_model_view( const mat4f& model_view_ );

    inline const frustumf& get_frustum() const;

    // returns projection * modelview 
    mat4f get_proj_model_view() const;
    
    inline void apply_viewport() const;

    inline viewport& get_viewport();
    inline const viewport& get_viewport() const;

    void set_viewport( const viewport& viewport_ );
    void set_viewport( GLint x, GLint y, GLsizei width_, GLsizei height );
    
protected:
    mat4f _projection;
    mat4f _model_view;
    
    frustumf _frustum;
    
    viewport _viewport;
    
    

}; //class Camera

inline void 
camera::set_view()
{
    _viewport.apply();
    glMatrixMode( GL_PROJECTION );
    glLoadMatrixf( _projection.ml );
    glMatrixMode( GL_MODELVIEW );
    glLoadMatrixf( _model_view.ml );
}




inline void
camera::apply_viewport() const
{
    _viewport.apply();
}




inline mat4f&
camera::get_projection()
{
    return _projection;
}




inline const mat4f& 
camera::get_projection() const
{
    return _projection;
}




inline mat4f& 
camera::get_model_view()
{
    return _model_view;
}




inline const mat4f& 
camera::get_model_view() const
{
    return _model_view;
}




inline const frustumf& 
camera::get_frustum() const
{
    return _frustum;
}





inline viewport& 
camera::get_viewport()
{
    return _viewport;
}




inline const viewport& 
camera::get_viewport() const
{
    return _viewport;
}


} //namespace gloo

#endif

