#ifndef __GLOO__VIEWPORT__H__
#define __GLOO__VIEWPORT__H__

#include <gloo/opengl_includes.hpp>
#include <gloo/vmmlib_includes.hpp>
#include <gloo/glut_callback_targets.hpp>

namespace gloo
{

struct viewport : public vec4i
{
    viewport()
        : vec4i( 0, 0, 0, 0 )
    {};
    
    viewport( const vec4i& vp_data )
        : vec4i( vp_data )
    {}

    inline void apply() const;
    
}; //struct viewport



inline void
viewport::apply() const
{
    glViewport( x, y, width, height );
}


} //namespace gloo

#endif

