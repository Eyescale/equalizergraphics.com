#ifndef __GLOO__PIXEL_DATA__H__
#define __GLOO__PIXEL_DATA__H__

#include <gloo/vmmlib_includes.hpp>
#include <gloo/opengl_includes.hpp>
#include <gloo/opengl_errors.hpp>
#include <gloo/camera.hpp>
#include <gloo/gl_data_helper.hpp>
#include <gloo/image.hpp>

#include <map>

namespace gloo
{

class pixel_data
{
public:
    // Note: you might want to set the correct buffer using glReadBuffer
    // before reading pixels...

    static void read_pixels( image& image, 
        const camera& camera_, GLenum format = GL_RGBA, ssize_t channels = -1 );

    // viewport_ = vec4i( x, y, width, height )
    static void  read_pixels( image& image, 
        const vec4i& viewport_, GLenum format =  GL_RGBA, ssize_t channels = -1 );
    
    static void read_pixels( std::vector< unsigned char >& pixels, 
        const camera& camera_, GLenum format = GL_RGBA, ssize_t channels = -1 );

    // viewport_ = vec4i( x, y, width, height )
    static void  read_pixels( std::vector< unsigned char >& pixels, 
        const vec4i& viewport_, GLenum format =  GL_RGBA, ssize_t channels = -1 );

    static void  read_pixels( std::vector< float >& pixels, 
        const camera& camera_, GLenum format =  GL_RGBA, ssize_t channels = -1 );

    // viewport_ = vec4i( x, y, width, height )
    static void  read_pixels( std::vector< float >& pixels, 
        const vec4i& viewport_, GLenum format =  GL_RGBA, ssize_t channels = -1 );

protected:
    template< typename T >
    static void _read_pixels( std::vector< T >& pixels, const vec4i& viewport_, 
        GLenum format, GLenum type, ssize_t channels = -1 );

}; // class pixel_data


template< typename T >
void
pixel_data::_read_pixels(  std::vector< T >& pixels, const vec4i& screen_box, 
    GLenum format, GLenum type, ssize_t channels_ )
{
    size_t channels_per_pixel;
    if ( channels_ == -1 )
    {
        try
        {
            channels_per_pixel =
                gl_data_helper::get_singleton().get_channels_per_pixel( format );
        }
        catch ( item_not_found_exception& e )
        {
            std::cerr << "pixelformat " << format
                << " not found in gl_data_helper." << std::endl;
            std::cerr << "you should specify the channels per pixel" 
                << " for new or EXT formats." << std::endl;
            throw e;
        }
        
    }
    else
        channels_per_pixel == channels_;

    size_t width = screen_box.width - screen_box.x;
    size_t height = screen_box.height - screen_box.y;
    pixels.resize( width * height * channels_per_pixel );
    
    glReadPixels( screen_box.x, screen_box.y, screen_box.z, screen_box.w, 
        format, type, &pixels[0] );
    
    check_for_gl_error( "reading pixel data.", GLOO_HERE );

}

template< typename T >
void read_pixels( std::vector< T >& pixels, camera& camera_, 
    GLenum format = GL_RGBA, GLenum type = GL_UNSIGNED_BYTE, 
    ssize_t channels = -1 )
{
    read_pixels( pixels, camera_.get_viewport(), format, type, channels );
}


} // namespace gloo

#endif

