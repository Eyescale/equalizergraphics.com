#ifndef __GLOO__CG_UNIFORM__H__
#define __GLOO__CG_UNIFORM__H__

#include <Cg/cg.h>
#include <Cg/cgGL.h>

#include <gloo/vmmlib_includes.hpp>

#include <gloo/cg_errors.hpp>

namespace gloo
{

class cg_uniform
{
public:
    cg_uniform( CGprogram program, const std::string& name )
        : _location( cgGetNamedParameter( program, name.c_str() ) )
        , _name( name )
    {
        check_for_cg_error( std::string( "getting location of uniform " + 
            name ), GLOO_HERE );
    }
    
    inline float operator=( float value );
    inline double operator=( double value );
    
    inline const vec2f& operator=( const vec2f& values );
    inline const vec2d& operator=( const vec2d& values );
    
    inline const vec3f& operator=( const vec3f& values );
    inline const vec3d& operator=( const vec3d& values );
    
    inline const vec4f& operator=( const vec4f& values );
    inline const vec4d& operator=( const vec4d& values );
    
    inline CGparameter         get_location() const;
    inline const std::string&  get_name() const;

protected:
    CGparameter _location;
    std::string _name;
    
};



inline float
cg_uniform::operator=( float value )
{
    cgSetParameter1f( _location, value );
    return value;
}



inline double
cg_uniform::operator=( double value )
{
    cgSetParameter1d( _location, value );
    return value;
}



inline const vec2f&
cg_uniform::operator=( const vec2f& values )
{
    cgSetParameter2fv( _location, values.xy );
    return values;
}



inline const vec2d&
cg_uniform::operator=( const vec2d& values )
{
    cgSetParameter2dv( _location, values.xy );
    return values;
}



inline const vec3f&
cg_uniform::operator=( const vec3f& values )
{
    cgSetParameter3fv( _location, values.xyz );
    return values;
}



inline const vec3d&
cg_uniform::operator=( const vec3d& values )
{
    cgSetParameter3dv( _location, values.xyz );
    return values;
}



inline const vec4f&
cg_uniform::operator=( const vec4f& values )
{
    cgSetParameter4fv( _location, values.xyzw );
    return values;
}



inline const vec4d&
cg_uniform::operator=( const vec4d& values )
{
    cgSetParameter4dv( _location, values.xyzw );
    return values;
}



inline CGparameter
cg_uniform::get_location() const
{
    return _location;
}



inline const std::string&
cg_uniform::get_name() const
{
    return _name;
}


} //namespace gloo

#endif

