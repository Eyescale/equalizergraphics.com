#ifndef __GLOO__CG_ERRORS__H__
#define __GLOO__CG_ERRORS__H__

#include <iostream>
#include <string>

#include <Cg/cg.h>
#include <Cg/cgGL.h>

#include <gloo/exception.hpp>

namespace gloo
{

class cg_error_exception : public exception
{
public: 
    cg_error_exception( std::string desc, except_here here )
    : exception( desc, here )
    {}
    
}; // class cg_error_exception



static void 
check_for_cg_error( const std::string& situation, except_here here, 
    CGcontext context = 0 )
{
    CGerror error;
    const char* description = cgGetLastErrorString( &error );

    if ( error != CG_NO_ERROR ) 
    {
        // this is necessary since cgGetLastErrorString doesn't seem to 
        // always clear the error flag ( at least on Mac with ATI ).
        cgGetError();
        if ( context && error == CG_COMPILER_ERROR )
        {
            std::cerr << cgGetLastListing( context ) << std::endl;
        }

        throw cg_error_exception( std::string( "error while " + situation + ":" ) 
            + std::string( description ),
            here );
    }
}

} //namespace gloo

#endif

