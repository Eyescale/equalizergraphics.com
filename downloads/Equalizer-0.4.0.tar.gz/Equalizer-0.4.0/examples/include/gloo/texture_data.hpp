#ifndef __GLOO__TEXTURE_DATA__H__
#define __GLOO__TEXTURE_DATA__H__

#include <gloo/opengl_includes.hpp>

namespace gloo
{

struct texture_data
{
    texture_data()
        : pixels( 0 )
        , width( 0 )
        , height( 0 )
        , depth( 0 )
        , dimensions( 2 )
        , source_format( GL_RGBA )
        , source_datatype( GL_UNSIGNED_BYTE )
        , size_in_bytes( 0 )
    {}
    
    void* pixels; // buffer with pixel data ( or 0 )
    GLsizei width; 
    GLsizei height; 
    GLsizei depth; 
    GLenum source_format;   // source data format
    GLenum source_datatype; // source data type

    GLsizei dimensions;
    GLsizei size_in_bytes;

};

} //namespace gloo

#endif
