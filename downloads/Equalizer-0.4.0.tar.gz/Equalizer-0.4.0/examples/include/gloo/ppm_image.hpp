#ifndef __GLOO__PPM_IMAGE__H__
#define __GLOO__PPM_IMAGE__H__

#include <gloo/vmmlib_includes.hpp>
#include <gloo/image.hpp>

#include <string>
#include <vector>

namespace gloo
{

class ppm_image
{
public:
    void save( const std::string& filename, const image& image_, 
        bool binary = false ) const;
    void save( const std::string& filename, const float_image& image_, 
        bool binary = false ) const;
        
protected:
    void _save_ppm( const std::string& filename, size_t width, size_t height,
        const std::vector< unsigned char >& pixels, bool binary ) const;
    void _save_pgm( const std::string& filename, size_t width, size_t height,
        const std::vector< unsigned char >& pixels, bool binary ) const;

}; // class ppm_image

} // namespace gloo

#endif

