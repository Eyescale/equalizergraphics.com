#ifndef __GLOO__GLSL_UNIFORM__H__
#define __GLOO__GLSL_UNIFORM__H__

#include <gloo/vmmlib_includes.hpp>
#include <gloo/opengl_errors.hpp>

/** 
*
* @brief a wrapper to more naturally set uniform parameters for glsl programs
*
* @author jonas boesch
*
*
* TODO templatize with type?
* 
**/
namespace gloo
{

// TODO maybe replace exit()'s with exceptions

class glsl_uniform
{
public:
    glsl_uniform();
    
    inline float operator=( float value );
    inline const vec2f& operator=( const vec2f& values );
    inline const vec3f& operator=( const vec3f& values );
    inline const vec4f& operator=( const vec4f& values );

    inline GLuint operator=( GLuint value );

    inline const glsl_uniform& operator=( const glsl_uniform& uniform );
    
    inline const std::string& get_name();
    inline GLuint get_location();
    inline GLuint get_program_name();
    
protected:
    friend class glsl_program;
    friend class asm_program;
    
    void create( GLuint program, const std::string& name );

    GLuint      _location;
    
    // for error output
    GLuint      _program;
    std::string _name;
};


inline float
glsl_uniform::operator=( float value )
{
   	glUniform1f( _location, value );
	if ( check_for_gl_error() )
	{
		std::cout << "glsl_uniform: Error while setting uniform variable " 
        << _name << " to value " << value << " in shader program " 
        << _program << std::endl;
		exit(1);
	}    
    return value;
}



inline const vec2f&
glsl_uniform::operator=( const vec2f& values )
{
   	glUniform2fv( _location, 2, values.xy );
	if ( check_for_gl_error() )
	{
		std::cout << "glsl_uniform: Error while setting uniform variable " 
            << _name << " to value " << values << " in shader program " 
            << _program << std::endl;
		exit(1);
	}    
    return values;
}



inline const vec3f&
glsl_uniform::operator=( const vec3f& values )
{
   	glUniform3fv( _location, 3, values.xyz );
	if ( check_for_gl_error() )
	{
		std::cout << "glsl_uniform: Error while setting uniform variable " 
        << _name << " to value " << values << " in shader program " 
        << _program << std::endl;
		exit(1);
	}    
    return values;
}



inline const vec4f&
glsl_uniform::operator=( const vec4f& values )
{
   	glUniform4fv( _location, 4, values.xyzw );
	if ( check_for_gl_error() )
	{
		std::cout << "glsl_uniform: Error while setting uniform variable " 
        << _name << " to value " << values << " in shader program " 
        << _program << std::endl;
		exit(1);
	}    
    return values;
}



inline GLuint
glsl_uniform::operator=( GLuint value )
{
   	glUniform1i( _location, value );
	if ( check_for_gl_error() )
	{
		std::cout << "glsl_uniform: Error while setting uniform variable " 
        << _name << " to value " << value << " in shader program " 
        << _program << std::endl;
		exit(1);
	}    
    return value;
}



inline const glsl_uniform& 
glsl_uniform::operator=( const glsl_uniform& uniform )
{
    _location   = uniform._location;
    _program    = uniform._program;
    _name       = uniform._name;
    return *this;
}



inline const std::string& 
glsl_uniform::get_name()
{
    return _name;
}



inline GLuint 
glsl_uniform::get_location()
{
    return _location;
}



inline GLuint 
glsl_uniform::get_program_name()
{
    return _program;
}

} //namespace gloo

#endif
