#ifndef __GLOO__ASM_PROGRAM__HPP__
#define __GLOO__ASM_PROGRAM__HPP__

#include <gloo/opengl_includes.hpp>
#include <gloo/texture.hpp>

#include <gloo/vmmlib_includes.hpp>

#include <list>
#include <vector>
#include <string>
#include <map> 

/*
 * @brief A simple wrapper for assembly gl shaders 
 * 
 * OpenGLAsmProgram simplifies the use of gl shaders by hiding most of the
 * OpenGL shader-related ugliness. Main use is probably loading a shader
 * in two function calls, and dealing with a single object instead of all
 * the OpenGL ids.
 *
 * Usage: 
 * 1. create instance of asm_program class 
 * 2. for_each shader call createShaderFromCString or createShaderFromFileName() 
 * 3. call createProgram()
 * opt: 4. use ::enable() to activate *this program if multiple programs are used.
 * 5. happily live ever after :)
 *
 * @author jonas boesch
 *
 */
namespace gloo
{


class asm_program
{
public: 
    asm_program();
    ~asm_program();
    
    GLuint create_from_file( GLenum type, const std::string& filename );
	GLuint create_from_string( GLenum type, const std::string& shader_source );

      // deletes all shaders, uniforms and the program
	void destroy();

    // returns the gl name / id of the program
	GLuint get_name(); 

	inline void enable();
	inline void disable();
	inline void bind();
	inline void unbind();

     // use setUniformxf if using the uniform for a static ( constant ) value.
    void set_uniform4f( GLuint index, float v0, float v1, float v2, float v3 );
    void set_uniform4fv( GLuint index, const vmml::Vector4f& values );
    
protected:

    void read_file( const std::string& filename );
    
    GLuint _program;
    GLenum _type;

    std::string _source;
};



inline GLuint
asm_program::get_name()
{
    return _program;
}



inline void 
asm_program::enable()
{
	glEnable( _type );
}



inline void 
asm_program::disable()
{
	glDisable( _type );
}



inline void 
asm_program::bind()
{
    glBindProgramARB( _type, _program );
}



inline void 
asm_program::unbind()
{
    glBindProgramARB( _type, 0 );
}


} // namespace gloo

#endif

