#ifndef __GLOO__RENDER_BUFFER__H__
#define __GLOO__RENDER_BUFFER__H__

#include <gloo/opengl_includes.hpp>

namespace gloo
{

class frame_buffer_object;

class render_buffer
{
public:
    render_buffer();
    
    void create( frame_buffer_object& fbo, 
        GLenum format = GL_DEPTH_COMPONENT, 
        GLenum target =  GL_DEPTH_ATTACHMENT_EXT );
        
    inline void bind();
    inline void unbind();
    
protected:
    GLuint _name;

}; // class RenderBuffer



inline void
render_buffer::bind()
{
    glBindRenderbufferEXT( GL_RENDERBUFFER_EXT, _name );
}



inline void
render_buffer::unbind()
{
    glBindRenderbufferEXT( GL_RENDERBUFFER_EXT, 0 );
}

} // namespace gloo

#endif


