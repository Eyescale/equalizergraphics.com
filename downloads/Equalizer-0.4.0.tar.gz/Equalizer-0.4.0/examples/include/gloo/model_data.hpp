#ifndef __GLOO__MODEL_DATA__H__
#define __GLOO__MODEL_DATA__H__

#include <gloo/vmmlib_includes.hpp>
#include <gloo/exception.hpp>

#include <vector>
#include <map>
#include <iostream>

namespace gloo
{

struct model_data
{
    std::vector< vec3f >    vertices;
    std::vector< vec3f >    vertex_positions;
    std::vector< vec3f >    vertex_normals;
    std::vector< vec3ub >   vertex_colors;
    std::vector< vec2f >    texture_coords;

    std::vector< vec3i >    triangle_faces;
    std::vector< vec4i >    quad_faces;
    std::vector< std::vector< uint32_t > > polygon_faces;
   
    std::vector< std::vector< float > > other_data;
    std::vector< std::string > other_data_names;
    std::vector< std::string > other_data_elements;
    
    friend std::ostream& operator<<( std::ostream& os, const model_data& md )
    {
        const std::ios::fmtflags flags = os.flags();
        os.setf( std::ios::right, std::ios::adjustfield );
        os  << "model_data: \n"
            << "\n  vertex_positions: " << md.vertex_positions.size() 
            << "\n  vertex_normals:   " << md.vertex_normals.size() 
            << "\n  vertex_colors:    " << md.vertex_colors.size() 
            << "\n  texture_coords:   " << md.texture_coords.size() 
            << "\n  triangle_faces:   " << md.triangle_faces.size() 
            << "\n  quad_faces:       " << md.quad_faces.size() 
            << "\n  polygon_faces:    " << md.polygon_faces.size() 
            << "\n  other_data: "; 
            for( size_t i = 0; i < md.other_data.size(); ++i )
            {
                os << "\n    " << md.other_data_names[ i ] << " (" 
                    << md.other_data[i].size() << ")";
            }
        os.setf( flags );
        return os;
    };
   
   
   
    std::vector< float >& 
    register_other_data( const std::string& name, 
        const std::string& element, size_t count )
    {
        other_data.resize( other_data.size() + 1 );
        other_data.back().resize( count );
        other_data_names.push_back( name );
        other_data_elements.push_back( element );
        return other_data.back();
    }
    
    
    
    std::vector< float >*
    get_other_data_ptr( const std::string& name )
    {
        size_t index = 0;
        std::vector< std::string >::iterator it = other_data_names.begin();
        std::vector< std::string >::iterator it_end = other_data_names.end();
        for( ; it != it_end; ++it, ++index )
        {
            if ( *it == name )
            {
                return &other_data[ index ];
            }
        }
        return 0;    
    }



    std::vector< float >&
    get_other_data( const std::string& name )
    {
        size_t index = 0;
        std::vector< std::string >::iterator it = other_data_names.begin();
        std::vector< std::string >::iterator it_end = other_data_names.end();
        for( ; it != it_end; ++it, ++index )
        {
            if ( *it == name )
            {
                return other_data[ index ];
            }
        }
        std::string msg = "could not find property ";
        msg += name;
        msg += ".";
        throw item_not_found_exception( msg, GLOO_HERE );
    }
    

}; // class model_data

} // namespace gloo

#endif

