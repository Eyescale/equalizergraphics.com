#ifndef __GLOO__CG_PROGRAM__H__
#define __GLOO__CG_PROGRAM__H__

#include <gloo/vmmlib_includes.hpp>

#include <Cg/cg.h>
#include <Cg/cgGL.h>

#include <gloo/cg_uniform.hpp>
#include <gloo/cg_errors.hpp>

#include <list>
#include <vector>
#include <string>
#include <map> 


/*
 * @brief A simple wrapper for cg shaders 
 * 
 * cg_program simplifies the use of cg shaders by hiding most of the
 * shader-related ugliness. Main use is probably loading a shader
 * in two function calls, and dealing with a single object instead of all
 * the OpenGL ids.
 *
 * @author jonas boesch
 */
 
namespace gloo
{

class cg_program
{
public: 
    /** 
    *   If this is the first program that is created without specifying the
    *   context parameter, a context will be created and stored in the static
    *   cg_program::_default_context. this context will then be used for all 
    *   new programs without an explicitly specified context.
    *   WARNING: do NOT use the standard ctor in a multithreaded environment. 
    *   You will need one context per thread. 
    */
    cg_program(); 
    cg_program( CGcontext context );
    ~cg_program();

    inline void bind();
    inline void unbind(); // unbinds profile
    
    inline void enable();
    inline void disable();

    inline void use(); // bind + enable
    inline void unbind_and_disable(); // unbind + disable
    
    // get uniform
    cg_uniform* get_uniform( const std::string& name );

    // automatically selects the best profile
    // profile class should be either CG_GL_VERTEX or CG_GL_FRAGMENT
    void create_from_file( 
        CGGLenum profile_class,      
        const std::string& filename, 
        const char* main_func = 0, 
        const char** args = 0,
        CGenum program_type = CG_SOURCE
        );

    void create_from_file( 
        CGprofile profile,      
        const std::string& filename, 
        const char* main_func = 0, 
        const char** args = 0,
        CGenum program_type = CG_SOURCE
        );
    
    // automatically selects the best profile
    // profile class should be either CG_GL_VERTEX or CG_GL_FRAGMENT
    void create_from_string( 
        CGGLenum profile_class,      
        const std::string& source, 
        const char* main_func = 0, 
        const char** args = 0,
        CGenum program_type = CG_SOURCE
        );

    void create_from_string( 
        CGprofile profile,      
        const std::string& source, 
        const char* main_func = 0, 
        const char** args = 0,
        CGenum program_type = CG_SOURCE
        );
    
    
    static CGcontext    create_context();
    
    inline CGcontext    get_context() const;
    inline CGprofile    get_profile() const;
    inline CGprogram    get_program() const;

protected:
    CGcontext   _context;
    CGprofile   _profile;
    CGprogram   _program;
    
    std::map< std::string, cg_uniform* > _uniforms;
    
    static CGcontext    _default_context;

}; // class cg_program


inline void 
cg_program::use()
{
    cgGLEnableProfile( _profile );
    check_for_cg_error("enabling profile", GLOO_HERE  );

    cgGLBindProgram( _program );
    check_for_cg_error("binding shader", GLOO_HERE  );
}



inline void 
cg_program::enable()
{
    cgGLEnableProfile( _profile );
    check_for_cg_error("enabling profile", GLOO_HERE  );
}



inline void 
cg_program::disable()
{
    cgGLDisableProfile( _profile );
    check_for_cg_error("disabling profile", GLOO_HERE  );
}



inline void 
cg_program::bind()
{
    cgGLBindProgram( _program );
    check_for_cg_error("binding shader", GLOO_HERE  );
}



inline void 
cg_program::unbind()
{
    cgGLUnbindProgram( _profile );
}



inline void 
cg_program::unbind_and_disable()
{
    unbind();
    disable();
}



inline CGcontext
cg_program::get_context() const
{
    return _context;
}



inline CGprofile
cg_program::get_profile() const
{
    return _profile;
}



inline CGprogram
cg_program::get_program() const
{
    return _program;
}
    


} // namespace gloo

#endif

