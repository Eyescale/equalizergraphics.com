#ifndef __GLOO__GL_DATA_HELPER__H__
#define __GLOO__GL_DATA_HELPER__H__

#include <gloo/opengl_includes.hpp>

#include <map>

namespace gloo
{

class gl_data_helper
{
public:
    static gl_data_helper& get_singleton();
    static gl_data_helper* get_singleton_ptr();

    size_t get_channels_per_pixel( GLenum format ) const;
    
protected:
    void _initialize_channel_map();
    std::map< GLenum, size_t > _channels_per_pixel;

    // singleton instance
    static gl_data_helper* _instance;
    
private:
    gl_data_helper();
    
}; // class gl_data_helper

} // namespace gloo

#endif

