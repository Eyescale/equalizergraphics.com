#ifndef __GLOO__RESHAPE_TARGET__H__
#define __GLOO__RESHAPE_TARGET__H__

namespace gloo
{

class reshape_target
{
public:
    virtual void reshape( size_t width, size_t height ) = 0;

}; // class reshape_target

} // namespace gloo

#endif

