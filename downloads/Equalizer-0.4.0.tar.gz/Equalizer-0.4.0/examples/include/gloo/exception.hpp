#ifndef __GLOO__EXCEPTION__H__
#define __GLOO__EXCEPTION__H__

#define GLOO_HERE gloo::except_here( __FILE__, __LINE__ )

#include <cstdlib>
#include <string>
#include <sstream>
#include <iostream>
#include <cassert>

namespace gloo
{

class fake_exception
{
public:
    fake_exception( const char* desc, const char* file, const size_t line )
    {
        std::cout << "error: " << desc << "\n"
            << "in " << file << ":" << line << std::endl;
    }
    ~fake_exception()
    {
        assert( 0 );
        abort();    
    };

}; // class fake_exception



struct except_here
{
    except_here( const char* file_, const int line_ )
        : file( file_ ), line( line_ ) {}
    
    const char* file;
    const int   line;
    
}; // struct except_here



class exception : public std::exception
{
public:
    inline exception( const std::string& desc, except_here here );
    inline exception( const char* desc, const char* file, const int line );  
    inline virtual ~exception() throw();
    inline virtual const char* what() const throw();

protected:
    std::string _desc;

private:
    exception();


};



exception::exception( const std::string& desc, except_here here )
{
    std::stringstream ss;
    ss << here.file << ":" << here.line << "\n" 
        << "exception: " << desc;
    _desc = ss.str();
}


exception::exception( const char* desc, const char* file, const int line )
{
    std::stringstream ss;
    ss << file << ":" << line << "\n" 
        << "exception: " << desc;
    _desc = ss.str();
}



exception::~exception() throw()
{}



const char* 
exception::what() const throw()
{
    return _desc.c_str(); 
}

// exception class


class item_not_found_exception : public exception
{
public: 
    item_not_found_exception( std::string desc, except_here here )
    : exception( desc, here )
    {}
}; // class item_not_found_exception



class invalid_parameter_exception : public exception
{
public: 
    invalid_parameter_exception( std::string desc, except_here here )
    : exception( desc, here )
    {}
}; // class invalid_parameter_exception



class out_of_bounds_exception : public exception
{
public: 
    out_of_bounds_exception( std::string desc, except_here here )
    : exception( desc, here )
    {}
}; // class invalid_parameter_exception


} // namespace gloo

#endif
