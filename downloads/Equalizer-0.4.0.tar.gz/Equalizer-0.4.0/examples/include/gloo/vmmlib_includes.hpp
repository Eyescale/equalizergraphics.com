#ifndef __GLOO__VMMLIB_INCLUDES__H__
#define __GLOO__VMMLIB_INCLUDES__H__

/**
*
* @brief basic include header for opengl utils
*
*/

#include <vmmlib/vector2.h>
#include <vmmlib/vector3.h>
#include <vmmlib/vector4.h>
#include <vmmlib/matrix3.h>
#include <vmmlib/matrix4.h>
#include <vmmlib/frustum.h>
#include <vmmlib/frustumCuller.h>

namespace gloo
{

typedef vmml::vec2i vec2i;
typedef vmml::vec2f vec2f;
typedef vmml::vec2d vec2d;

typedef vmml::vec3i vec3i;
typedef vmml::vec3f vec3f;
typedef vmml::vec3d vec3d;
typedef vmml::vec3ub vec3ub;


typedef vmml::vec4i vec4i;
typedef vmml::vec4f vec4f;
typedef vmml::vec4d vec4d;

typedef vmml::mat3f mat3f;
typedef vmml::mat4d mat4d;
typedef vmml::mat4f mat4f;
typedef vmml::mat4d mat4d;

typedef vmml::frustumf frustumf;
typedef vmml::frustumd frustumd;
typedef vmml::FrustumCullerf frustum_cullerf;
typedef vmml::FrustumCullerd frustum_cullerd;

} //namespace gloo

#endif
