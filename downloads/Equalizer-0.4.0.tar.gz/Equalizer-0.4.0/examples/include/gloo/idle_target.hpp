#ifndef __GLOO__IDLE_TARGET__H__
#define __GLOO__IDLE_TARGET__H__

namespace gloo
{

class idle_target
{
public:
    virtual void on_idle() = 0;

}; // class idle_target

} // namespace gloo

#endif

