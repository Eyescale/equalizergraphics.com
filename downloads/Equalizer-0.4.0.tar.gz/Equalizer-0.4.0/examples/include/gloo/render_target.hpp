#ifndef __GLOO__RENDER_TARGET__H__
#define __GLOO__RENDER_TARGET__H__

namespace gloo
{

class render_target
{
public:
    virtual void draw() = 0;

}; // class render_target

} // namespace gloo

#endif

