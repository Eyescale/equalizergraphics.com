
#include <gloo/frame_buffer_object.hpp>
#include <gloo/opengl_errors.hpp>

#include <gloo/texture.hpp>

#include <cassert>
#include <fstream>

namespace gloo
{

frame_buffer_object::frame_buffer_object()
	: _name( 0 )
    , _texture( 0 )
{
    if ( ! fbo_status_ok() )
    {
        print_fbo_status();
        throw fbo_error_exception( "fbo status not ok.", GLOO_HERE );
    }
    
    glGenFramebuffersEXT( 1, &_name); 
}




frame_buffer_object::~frame_buffer_object()
{
    unbind();    
	glDeleteFramebuffersEXT( 1, &_name );	
}



void 
frame_buffer_object::bind_to_texture_2d( texture& tex, GLenum target )
{
    _target = target;

    _texture = &tex;
	_texture->bind();
        
    // bind fbo 
    bind();
    
	// attach the texture to the framebuffer
	glFramebufferTexture2DEXT( GL_FRAMEBUFFER_EXT, _target, 
        _texture->get_target(), _texture->get_name(), 0 );

	// unbind fbo + tex
    unbind();
    _texture->unbind();
	
    if ( !fbo_status_ok() ) 
	{
        print_fbo_status();
        throw fbo_error_exception( "binding frame buffer object to texture", 
            GLOO_HERE );
    }
    check_for_gl_error( "binding frame buffer object to texture", GLOO_HERE );
}



void 
frame_buffer_object::print_fbo_status()
{
	GLuint status = glCheckFramebufferStatusEXT( GL_FRAMEBUFFER_EXT );

	switch( status )
	{
		case GL_FRAMEBUFFER_COMPLETE_EXT:
			std::cout << "frame_buffer_object: Complete FBO support!"; 
			break;
		case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT:
			std::cout << "frame_buffer_object: GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT";
			break;
		case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT:
			std::cout << "frame_buffer_object: GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT";
			break;
		case GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT:
			std::cout << "frame_buffer_object: GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT";
			break;
		case GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT:
			std::cout << "frame_buffer_object: GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT";
			break;
		case GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT:
			std::cout << "frame_buffer_object: GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT";
			break;
		case GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT:
			std::cout << "frame_buffer_object: GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT";
			break;
		case GL_FRAMEBUFFER_UNSUPPORTED_EXT:
			std::cout << "frame_buffer_object: GL_FRAMEBUFFER_UNSUPPORTED_EXT";
			break;
		default:
			std::cout << "frame_buffer_object: unknown error status for fbo";
			break;
	}
	std::cout << std::endl;
}



void 
frame_buffer_object::write_colors_to_file( const std::string& fileName )
{
    glReadBuffer( _target );

    size_t width = _texture->get_width();
    size_t height = _texture->get_height();

    size_t bytes = width * height * 3;
    unsigned char* color_buffer = new unsigned char[ bytes ];

    glReadPixels( 0, 0, width, height, GL_RGB, GL_UNSIGNED_BYTE, color_buffer );
    
    std::ofstream os;
    os.open( fileName.c_str() );
    if ( os.is_open() )
    {
        os << "P3 " << width << " " << height << " " << 255 << std::endl;
        for ( size_t i = 0; i < bytes; ++i )
        {
            os << (ssize_t) color_buffer[ i ] << " ";
        }
        os << std::endl;
    }
    os.close();
    delete[] color_buffer;
}



void 
frame_buffer_object::write_colors_to_text_file( const std::string& fileName )
{
    glReadBuffer( _target );

    size_t width = _texture->get_width();
    size_t height = _texture->get_height();

    size_t elements = width * height * 4;
    float* color_buffer = new float[ elements ];

    glReadPixels( 0, 0, width, height, GL_RGBA, GL_FLOAT, 
        color_buffer );
    
    std::ofstream os;
    os.open( fileName.c_str() );
    if ( os.is_open() )
    {
        for ( size_t i = 0; i < elements; ++i )
        {
            if ( i % 4 == 0 )
                os << "| ";
            os << color_buffer[ i ] << " ";
        }
        os << std::endl;
    }
    os.close();
    delete[] color_buffer;
}



void 
frame_buffer_object::write_depth_to_file( const std::string& fileName )
{
    glReadBuffer( _target );

    size_t width = _texture->get_width();
    size_t height = _texture->get_height();

    size_t elements = width * height;
    float* color_buffer = new float[ elements ];

    glReadPixels( 0, 0, width, height, GL_DEPTH_COMPONENT, GL_FLOAT, 
        color_buffer );
    
    std::ofstream os;
    os.open( fileName.c_str() );
    if ( os.is_open() )
    {
        os << "P2 " << width << " " << height << " " << 255 << std::endl;
        for ( size_t i = 0; i < elements; ++i )
        {
            os << (ssize_t) ( 255.0f * color_buffer[ i ] ) << " ";
        }
        os << std::endl;
    }
    os.close();
    delete[] color_buffer;
}


} // namespace gloo
