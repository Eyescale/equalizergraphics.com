#include <gloo/glut_window.hpp>

#include <iostream>

namespace gloo
{

glut_window* glut_window::_instance = 0;

glut_window::glut_window( const std::string& name, size_t width, size_t height, 
    const std::string& init_string )
    : _name( name )
    , _render_target( 0 )
    , _reshape_target( 0 )
    , _idle_target( 0 )
{
    _setup_glut( init_string );
    _init_window( width, height );
	_instance = this;
}



glut_window::glut_window( const std::string& name, size_t width, size_t height, 
    unsigned int mode )
    : _name( name )
    , _render_target( 0 )
    , _reshape_target( 0 )
    , _idle_target( 0 )
{
    _setup_glut( mode );
    _init_window( width, height );
	_instance = this;
}



glut_window::~glut_window()
{}



void 
glut_window::start()
{
    std::cout << "glut_window: starting mainloop." << std::endl;
    glutMainLoop();
}


void 
glut_window::display()
{
    assert( _render_target );
    glut_input::update_targets();
    _render_target->draw();
    glutSwapBuffers();
}



void 
glut_window::redraw()
{
    glutPostRedisplay();
}



void
glut_window::_setup_glut( const std::string& init_string )
{
    int c = 0;
    char* v = 0;
    glutInit( &c, &v );
    std::cout << "glut_window: setting up glut with initstring: " 
        << init_string << std::endl; 
    glutInitDisplayString( init_string.c_str() );
}



void
glut_window::_setup_glut( unsigned int mode )
{
    int c = 0;
    char* v = 0;
    glutInit( &c, &v );
    if ( mode )
    {
        std::cout << "glut_window: setting up glut with mode flag: " << mode 
            << std::endl; 
        glutInitDisplayMode( mode );
    }
    else
    {
        std::cout << "glut_window: setting up glut with defaults: double depth rgba" 
            << std::endl; 
        glutInitDisplayMode ( GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGBA );
    }
}



void
glut_window::_init_window( size_t width, size_t height )
{
    glutInitWindowSize( width, height );
    glutCreateWindow(   _name.c_str() ); 

    glutReshapeFunc (   glut_window::_reshape );
    glutDisplayFunc (   glut_window::_display );
    glutMouseFunc(      glut_window::_on_mouse_button );
    glutMotionFunc(     glut_window::_on_mouse_dragged );
    glutKeyboardFunc (  glut_input::_on_key );
    glutKeyboardUpFunc( glut_input::_on_key_up );
    glutIdleFunc(       glut_window::_on_idle );
}



void
glut_window::_display()
{
    _instance->display();
}



void
glut_window::_reshape( int width, int height )
{
    _instance->reshape( width, height );
}



void
glut_window::_on_idle()
{
    _instance->on_idle();
}



void 
glut_window::set_render_target( render_target* render_target_ )
{
    _render_target = render_target_;
}



void 
glut_window::set_reshape_target( reshape_target* target )
{
    _reshape_target = target;
}



void 
glut_window::set_idle_target( idle_target* target )
{
    _idle_target = target;
}



render_target* 
glut_window::get_render_target()
{
    return _render_target;
}



reshape_target* 
glut_window::get_reshape_target()
{
    return _reshape_target;
}



idle_target* 
glut_window::get_idle_target()
{
    return _idle_target;
}



} //namespace gloo

