#include <gloo/gl_data_helper.hpp>
#include <gloo/exception.hpp>

namespace gloo
{
gl_data_helper* gl_data_helper::_instance = 0;


gl_data_helper&
gl_data_helper::get_singleton()
{
    return ( _instance ) ? *_instance : *(_instance = new gl_data_helper() );
}



gl_data_helper*
gl_data_helper::get_singleton_ptr()
{
    return ( _instance ) ? _instance : _instance = new gl_data_helper();
}



gl_data_helper::gl_data_helper()
{
    _initialize_channel_map();
}



size_t 
gl_data_helper::get_channels_per_pixel( GLenum format ) const
{
    std::map< GLenum, size_t >::const_iterator it 
        = _channels_per_pixel.find( format );
    if ( it != _channels_per_pixel.end() )
        return (*it).second;
    
    throw item_not_found_exception( 
        "Could not find channel size for requested format.", GLOO_HERE );
}




void 
gl_data_helper::_initialize_channel_map()
{
    _channels_per_pixel[ GL_RED ] = 1;
    _channels_per_pixel[ GL_GREEN ] = 1;
    _channels_per_pixel[ GL_BLUE ] = 1;
    _channels_per_pixel[ GL_ALPHA ] = 1;
    _channels_per_pixel[ GL_LUMINANCE ] = 1;
    _channels_per_pixel[ GL_DEPTH_COMPONENT ] = 1;

    _channels_per_pixel[ GL_LUMINANCE_ALPHA ] = 1;

    _channels_per_pixel[ GL_RGB ] = 3;
    _channels_per_pixel[ GL_BGR ] = 3;

    _channels_per_pixel[ GL_RGBA ] = 4;
    _channels_per_pixel[ GL_BGRA ] = 4;
}


} // namespace gloo

