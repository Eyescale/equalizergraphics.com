#include <gloo/glsl_uniform.hpp>

namespace gloo
{

glsl_uniform::glsl_uniform()
: _location( 0 )
, _program( 0 )
, _name( "" )
{}



void
glsl_uniform::create( GLuint program, const std::string& name )
{
    _location = glGetUniformLocation( program, name.c_str() );
	if ( check_for_gl_error() )
	{
		std::cout << "glsl_uniform: Error while getting location of uniform" 
        << " variable " << name << " in program " << program 
        << std::endl;
		exit(1);
	}    
    _program = program;
    _name = name;
}

}//namespace gloo
