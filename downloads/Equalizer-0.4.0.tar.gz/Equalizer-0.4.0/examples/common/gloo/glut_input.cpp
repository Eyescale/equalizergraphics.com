#include <gloo/glut_input.hpp>

namespace gloo
{

glut_input* glut_input::_instance = 0;

glut_input::glut_input()
    : _old_mouse_position( 0, 0 )
{
    // initialize arrays
    _key_targets.resize( 256 );
    memset( &(_key_targets[0]), 0, 256 * sizeof( key_target* ) );

    _keys_down.resize( 256 );
    memset( &(_keys_down[0]), 0, 256 * sizeof( ssize_t ) );


    _instance = this;
    
}



void 
glut_input::update_targets()
{
    for( size_t i = 0; i < 256; ++i )
    {
        if ( _keys_down[ i ] && _key_targets[ i ] != 0 )
        {
            _key_targets[ i ]->on_key_down( static_cast< unsigned char >( i ) );
        }
    }
}



void 
glut_input::_update_mouse_targets()
{
    std::list< mouse_target* >::iterator it = _mouse_targets.begin();
    std::list< mouse_target* >::iterator ite = _mouse_targets.end();
    
    for( ; it != ite; ++it )
    {
        (*it)->mouse_update( _mouse_state );
    }

}
    


void 
glut_input::set_key_target( unsigned char key, key_target* target )
{
    assert( _instance && "glut_input object not initialized." );
    _instance->_key_targets[ key ] = target;
}



void 
glut_input::add_mouse_target( mouse_target* target )
{
    assert( _instance && "glut_input object not initialized." );
    _instance->_mouse_targets.push_back( target );
    _instance->_mouse_targets.unique();    
}



void 
glut_input::_on_key( unsigned char key, int x, int y )
{
    assert( _instance && "glut_input object not initialized." );
    _instance->_keys_down[ key ] = 1;
}



void 
glut_input::_on_key_up( unsigned char key, int x, int y )
{
    assert( _instance && "glut_input object not initialized." );
    _instance->_keys_down[ key ] = 0;
    
    // safety switch to prevent stuck keys
    unsigned char kkey = tolower( key );
    if ( kkey != key )  
        _instance->_keys_down[ kkey ] = 0;
    else
        _instance->_keys_down[ toupper( key ) ] = 0;   
}



void 
glut_input::_on_mouse_button( int button, int state, int x, int y )
{
    _instance->_on_mouse_button_impl( button, state, x, y );
    _instance->_update_mouse_targets();    
}



void 
glut_input::_on_mouse_button_impl( int button, int state, int x, int y )
{
    switch( button )
    {
        case GLUT_LEFT_BUTTON:
            _mouse_state.buttons[ 0 ] = ( state == GLUT_DOWN ) ? 1 : 0;
            break;
        case GLUT_RIGHT_BUTTON:
            _mouse_state.buttons[ 1 ] = ( state == GLUT_DOWN ) ? 1 : 0;
            break;
        case GLUT_MIDDLE_BUTTON:
            _mouse_state.buttons[ 2 ] = ( state == GLUT_DOWN ) ? 1 : 0;
            break;
        default:
            break;
    }

    _mouse_state.position.set( x, y );
}



void 
glut_input::_on_mouse_dragged( int x, int y )
{
    _instance->_on_mouse_dragged_impl( x, y );
    _instance->_update_mouse_targets();    
}



void 
glut_input::_on_mouse_dragged_impl( int x, int y )
{
    _old_mouse_position = _mouse_state.position;
    _mouse_state.position.set( x, y );
    _mouse_state.diff = _mouse_state.position - _old_mouse_position;
}


} //namespace gloo
