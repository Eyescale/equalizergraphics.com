#include <gloo/asm_program.hpp>
#include <gloo/opengl_errors.hpp>

#include <iostream>
#include <fstream>

namespace gloo
{

asm_program::asm_program()
	: _program( 0 )
{}



asm_program::~asm_program()
{
	destroy();
}



GLuint 
asm_program::create_from_file( GLenum type, 
    const std::string& fileName )
{
    glGenProgramsARB( 1, &_program );
    glBindProgramARB( type, _program );
    if ( check_for_gl_error() )
    {
        std::cout << "asm_program - binding ";
        if ( type == GL_VERTEX_PROGRAM_ARB )
            std::cout << "vertex program " << std::endl;
        else if ( type == GL_FRAGMENT_PROGRAM_ARB )  
            std::cout << "fragment program " << std::endl;
        else
            std::cout << "program of type " << type << " ";
        std::cout << " failed." << std::endl;
        exit( 1 );
    }
        
    read_file( fileName );
    glProgramStringARB( type, GL_PROGRAM_FORMAT_ASCII_ARB,
					 _source.size(), _source.c_str() );
    GLint error;
    glGetIntegerv(GL_PROGRAM_ERROR_POSITION_ARB, &error);
    if ( error != -1) 
    {
        unsigned char message[1024];
        glGetProgramStringARB( type, GL_PROGRAM_ERROR_STRING_ARB, message);	
        std::cerr << "asm_program - error at position " << error 
            << " in program " << fileName << std::endl;
        exit(1);
    }
    _type = type;
    std::cout << "asm_program - loaded program from file " << fileName 
        << std::endl;
    return _program;
}



GLuint 
asm_program::create_from_string( GLenum type, 
    const std::string& shader_source )
{
    glGenProgramsARB( 1, &_program );
    glBindProgramARB( type, _program );
    if ( check_for_gl_error() )
    {
        std::cout << "asm_program - binding ";
        if ( type == GL_VERTEX_PROGRAM_ARB )
            std::cout << "vertex program " << std::endl;
        else if ( type == GL_FRAGMENT_PROGRAM_ARB )  
            std::cout << "fragment program " << std::endl;
        else
            std::cout << "program of type " << type << " ";
        std::cout << " failed." << std::endl;
        exit( 1 );
    }
    
    glProgramStringARB( type, GL_PROGRAM_FORMAT_ASCII_ARB,
					 shader_source.size(), shader_source.c_str() );
    GLint error;
    glGetIntegerv(GL_PROGRAM_ERROR_POSITION_ARB, &error);
    if ( error != -1) 
    {
        unsigned char message[1024];
        glGetProgramStringARB( type, 
            GL_PROGRAM_ERROR_STRING_ARB, message);	
        std::cerr << "asm_program - error at position " << error 
            << " in program " << _program << "( from string )" << std::endl;
        exit(1);
    }
    _source = shader_source;
    _type = type;
    return _program;
}


void 
asm_program::set_uniform4f( GLuint index, float v0, float v1, float v2, 
    float v3 )
{
    glProgramLocalParameter4fARB( _type, index, v0, v1, v2, v3 );
}



void 
asm_program::set_uniform4fv( GLuint index, const vmml::Vector4f& values )
{
    glProgramLocalParameter4fvARB( _type, index, values.xyzw );
}



/*
void
asm_program::setTextureUnit( GLuint unit, GLAsmUniform& sampler, 
    Texture& texture )
{
    enable();
	glActiveTexture(GL_TEXTURE0 + unit );
	if ( check_for_gl_errors() )
	{
		std::cout << "asm_program: Error while activating texture unit " 
        << unit << std::endl;
		exit(1);
	}
    texture.bind();
    sampler = unit;
	if ( check_for_gl_errors() )
	{
		std::cout << "asm_program: Error while setting texture sampler " 
        << sampler.getName() << " in unit " << unit << " in shader " 
        << _program << std::endl;
		assert(0);
	}
	//std::cout << "asm_program: Set texture " << samplername << " to texture unit " << unit << std::endl;
	//glUseProgram(0); 
}
*/


void
asm_program::destroy()
{
    glDeleteProgramsARB( 1, &_program );
    _program = 0;
}



void 
asm_program::read_file( const std::string& filename )
{
    using namespace std;
    ifstream in;
    in.open( filename.c_str() );
    if ( ! in.good() )
        assert( 0 && "asm_program - Reading source failed!" );
    in.seekg(0, ios::end);
    size_t length = in.tellg();
    in.seekg(0, ios::beg);
    char* source = new char[length+1];
    
    in.read( source, length);
    source[length] = '\0';
    in.close();
    _source = source;
    std::cout << "asm_program - Read source " << filename << " of length " 
        << length << std::endl;
}


} // namespace gloo


