#include <gloo/render_buffer.hpp>
#include <gloo/opengl_errors.hpp>

#include <gloo/frame_buffer_object.hpp>
#include <gloo/exception.hpp>

namespace gloo
{

render_buffer::render_buffer()
{
    glGenRenderbuffersEXT( 1, &_name );
}


void 
render_buffer::create( frame_buffer_object& fbo, GLenum format, GLenum target )
{
    fbo.bind();
    bind();
    
    glRenderbufferStorageEXT(   GL_RENDERBUFFER_EXT, 
                                format, 
                                fbo.get_width(), 
                                fbo.get_height() 
                                );
    
    glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT,
                                 target,
                                 GL_RENDERBUFFER_EXT, _name );

    fbo.unbind();
    
    if ( ! fbo.fbo_status_ok() || check_for_gl_error() )
    {
        fbo.print_fbo_status();
        check_for_gl_error( "creating render_buffer attachment to fbo. ",
            GLOO_HERE );
    }

}

} // namespace gloo

