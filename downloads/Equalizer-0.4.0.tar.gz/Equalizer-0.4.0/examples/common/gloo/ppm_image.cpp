#include <gloo/ppm_image.hpp>
#include <gloo/exception.hpp>

#include <fstream>
#include <sstream>

namespace gloo
{

void 
ppm_image::save( const std::string& filename, const image& image_, 
    bool binary ) const
{
    std::vector< unsigned char > tmp;
    const std::vector< unsigned char >& pixels = image_.pixels;

    size_t pixel_count = image_.width * image_.height;
    size_t char_count = 0;
    switch( image_.format )
    {
        case GL_RGB:
            _save_ppm( filename, image_.width, image_.height, pixels, binary );
        case GL_RGBA:
            char_count = pixel_count * 3;
            tmp.resize( char_count );
            for( size_t i = 0, j = 0; i < char_count; ++i, ++j )
            {
                tmp[ i ]    = pixels[ j ];
                tmp[ ++i ]  = pixels[ ++j ];
                tmp[ ++i ]  = pixels[ ++j ];
                ++j;
            }
            _save_ppm( filename, image_.width, image_.height, tmp, binary );
            break;
        case GL_ALPHA:
        case GL_DEPTH_COMPONENT:
        case GL_LUMINANCE:
            _save_pgm( filename, image_.width, image_.height, pixels, binary );
            break;
        default:
            throw invalid_parameter_exception( 
                "Invalid format for saving ppm_image.", GLOO_HERE );
    }

}



void 
ppm_image::save( const std::string& filename, const float_image& image_, 
    bool binary ) const
{
    std::vector< unsigned char > tmp;
    const std::vector< float >& pixels = image_.pixels;

    size_t pixel_count = image_.width * image_.height;
    size_t char_count = 0;
    switch( image_.format )
    {
        case GL_RGB:
            char_count = pixel_count * 3;
            tmp.resize( char_count );
            for( size_t i = 0, j = 0; i < char_count; ++i, ++j )
            {
                tmp[ i ] = static_cast< unsigned char >( pixels[ j ] * 256 );
                tmp[ ++i ] = static_cast< unsigned char >( pixels[ ++j ] * 256 );
                tmp[ ++i ] = static_cast< unsigned char >( pixels[ ++j ] * 256 );
            }
            _save_ppm( filename, image_.width, image_.height, tmp, binary );
            break;
        case GL_RGBA:
            char_count = pixel_count * 3;
            tmp.resize( char_count );
            for( size_t i = 0, j = 0; i < char_count; ++i, ++j )
            {
                tmp[ i ] = static_cast< unsigned char >( pixels[ j ] * 256 );
                tmp[ ++i ] = static_cast< unsigned char >( pixels[ ++j ] * 256 );
                tmp[ ++i ] = static_cast< unsigned char >( pixels[ ++j ] * 256 );
                ++j;
            }
            _save_ppm( filename, image_.width, image_.height, tmp, binary );
            break;
        case GL_ALPHA:
        case GL_DEPTH_COMPONENT:
        case GL_LUMINANCE:
            tmp.resize( pixel_count );
            for( size_t i = 0; i < pixel_count; ++i )
            {
                tmp[ i ] = static_cast< unsigned char >( pixels[ i ] * 256 );
            }
            _save_ppm( filename, image_.width, image_.height, tmp, binary );
            break;
            break;
        default:
            throw invalid_parameter_exception( 
                "Invalid format for saving ppm_image.", GLOO_HERE );
    }

}



void 
ppm_image::_save_ppm( const std::string& filename, size_t width, size_t height,
    const std::vector< unsigned char >& pixels, bool binary ) const
{
    if ( pixels.size() != width * height * 3 )
        throw invalid_parameter_exception( "tried to save ppm image.", 
            GLOO_HERE );

    std::ofstream out_stream;
    std::ios_base::openmode mode = std::ios::out;
    
    if ( binary )
        mode |= std::ios::binary;

    out_stream.open( filename.c_str(), mode );
    if ( ! out_stream.is_open() ) 
        throw exception( "opening file for writing ppm failed.", GLOO_HERE );

    std::string magic = binary ? "P6 " : "P3 ";
    std::stringstream ss;
    ss << magic << width << " " << height << " 255 \n";
    
    const std::string& header = ss.str();
    out_stream.write( header.c_str(), header.size() );
    
    size_t size_in_bytes = 3 * width * height;
    size_t row = 3 * width;
    if ( binary )
    {
        for( ssize_t i = height - 1; i > -1; --i )
        {
            out_stream.write( (char*) &pixels[ row * i ], row );
        }
        // FIXME
        //out_stream.write( (char*) &pixels[0], size_in_bytes );
    }
    else
    {
        std::stringstream data_ss;
        for( size_t i = 0, line = 0; i < size_in_bytes; ++i, ++line )
        {
            data_ss << static_cast< size_t >( pixels[ i ] ) << " ";
            if ( line == 17 ) // a ppm line should not be longer than 70 chars
            {
                data_ss << "\n";
                line = 0;
            }
        }
        data_ss << std::endl;
        const std::string& data = data_ss.str();
        out_stream.write( data.c_str(), size_in_bytes );
    }
    
    out_stream << std::endl;    
    out_stream.close();
    
    if ( out_stream.bad() )
        throw exception( "error while writing ppm file.", GLOO_HERE );
}



void 
ppm_image::_save_pgm( const std::string& filename, size_t width, size_t height, 
    const std::vector< unsigned char >& pixels, bool binary ) const
{
    std::ofstream out_stream;
    std::ios_base::openmode mode = std::ios::out;
    
    if ( binary )
        mode |= std::ios::binary;

    out_stream.open( filename.c_str(), mode );
    if ( ! out_stream.is_open() ) 
        throw exception( "opening file for writing pgm failed.", GLOO_HERE );

    std::string magic = binary ? "P5 " : "P2 ";
    std::stringstream ss;
    ss << magic << width << " " << height << " 255 \n";
    
    const std::string& header = ss.str();
    out_stream.write( header.c_str(), header.size() );
    
    size_t size_in_bytes = width * height;

    if ( binary )
    {
        // FIXME
        out_stream.write( (char*) &pixels[0], size_in_bytes );
    }
    else
    {
        std::stringstream data_ss;
        for( size_t i = 0, line = 0; i < size_in_bytes; ++i, ++line )
        {
            data_ss << static_cast< size_t >( pixels[ i ] ) << " ";
            if ( line == 17 ) // a pgm line should not be longer than 70 chars
            {
                data_ss << "\n";
                line = 0;
            }
        }
        data_ss << std::endl;
        const std::string& data = data_ss.str();
        out_stream.write( data.c_str(), size_in_bytes );
    }

    out_stream << std::endl;    
    out_stream.close();

    if ( out_stream.bad() )
        throw exception( "error while writing pgm file.", GLOO_HERE );
}



} // namespace gloo

