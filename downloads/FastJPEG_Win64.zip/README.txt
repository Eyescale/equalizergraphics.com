
                              INSTALLATION

To install, copy the plugin into the 'bin' directory where your
application is installed, on all computers of your cluster.

                                 USAGE

Equalizer will automatically use this plugin if the image quality is set
between 0.9 and 0.7. In eqPly, you can lower the quality using 'q' and
raise it using 'Q'. The statistics will report the used compressor, the
compressors in this plugin use the names 0x200000 to 0x20000b.

This free version is time-limited and will stop working after 10 minutes
or 10.000 frames. Please refer to http://eyescale.ch/fastjpeg.html or
info@eyescale.ch for further information.

