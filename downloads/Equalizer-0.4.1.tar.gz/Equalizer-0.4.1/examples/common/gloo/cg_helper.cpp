#include <gloo/cg_helper.hpp>

namespace gloo
{

cg_helper*  cg_helper::_instance = 0;


cg_helper& 
cg_helper::get_singleton()
{
    if ( ! _instance )
    {
        _instance = new cg_helper();
    }
    return *_instance;
}



cg_helper* 
cg_helper::get_singleton_ptr()
{
    if ( ! _instance )
    {
        _instance = new cg_helper();
    }
    return _instance;
}



cg_helper::cg_helper()
    : _unknown_profile( "unknown profile" )
{
    _init_map();
}



cg_helper::~cg_helper()
{

}



const std::string& 
cg_helper::get_profile_name( CGprofile profile )
{
    cg_helper& helper = get_singleton();
    
    std::map< CGprofile, std::string >::iterator it 
        = helper._profile_names.find( profile );
    if ( it != helper._profile_names.end() )
    {
        return (*it).second;
    }
    //CG_GL_UNKNOWN
    return helper._unknown_profile;
}



void 
cg_helper::_init_map()
{
    _profile_names[ CG_PROFILE_VP20   ] = "vp20";
    _profile_names[ CG_PROFILE_FP20   ] = "fp20";
    _profile_names[ CG_PROFILE_VP30   ] = "vp30";
    _profile_names[ CG_PROFILE_FP30   ] = "fp30";
    _profile_names[ CG_PROFILE_ARBVP1 ] = "arbvp1";
    _profile_names[ CG_PROFILE_FP40   ] = "fp40";
    _profile_names[ CG_PROFILE_ARBFP1 ] = "arbfp1";
    _profile_names[ CG_PROFILE_VP40   ] = "vp40";
    _profile_names[ CG_PROFILE_GLSLV  ] = "glslv";
    _profile_names[ CG_PROFILE_GLSLF  ] = "glslf";
    _profile_names[ CG_PROFILE_GLSLC  ] = "glslc";
}


} // namespace gloo

