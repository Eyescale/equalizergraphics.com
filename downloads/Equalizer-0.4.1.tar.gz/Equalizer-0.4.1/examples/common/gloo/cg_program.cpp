#include <gloo/cg_program.hpp>

namespace gloo
{

CGcontext   cg_program::_default_context = 0;

cg_program::cg_program()
    : _context( _default_context )
    , _program( 0 )
{
    if ( _default_context == 0 )
        _default_context = _context = create_context();
}


cg_program::cg_program( CGcontext context )
    : _context( context )
    , _program( 0 )
{}



cg_program::~cg_program()
{
    cgDestroyProgram( _program );
    
    std::map< std::string, cg_uniform* >::iterator it = _uniforms.begin();
    std::map< std::string, cg_uniform* >::iterator ite = _uniforms.end();
    for( ; it != ite; ++it )
    {
        delete (*it).second;
    }
}


void
cg_program::create_from_string( CGGLenum profile_class, 
    const std::string& source, const char* main_func, const char** args, 
    CGenum program_type )
{
    _profile = cgGLGetLatestProfile( profile_class );
    check_for_cg_error( "gettin latest gl profile from cg", GLOO_HERE );

    create_from_string( _profile, source, main_func, args, program_type );
}



void 
cg_program::create_from_string( CGprofile profile, const std::string& source, 
    const char* main_func, const char** args, CGenum program_type )
{
    _profile = profile;
    cgGLSetOptimalOptions( _profile );
    check_for_cg_error( "selecting profile", GLOO_HERE  );

    _program = cgCreateProgram( 
        _context, 
        program_type, 
        source.c_str(),
        _profile,
        main_func,
        args 
        );

    check_for_cg_error( std::string( "creating program from source: \n" 
        + source ), GLOO_HERE , _context );
    
    cgGLLoadProgram( _program );
    
    check_for_cg_error( std::string( "creating program from source: \n" 
        + source ), GLOO_HERE  );

}




void 
cg_program::create_from_file( CGGLenum profile_class, const std::string& filename, 
    const char* main_func, const char** args, CGenum program_type )
{
    _profile = cgGLGetLatestProfile( profile_class );
    check_for_cg_error( "gettin latest gl profile from cg", GLOO_HERE  );

    create_from_file( _profile, filename, main_func, args, program_type );
}



void 
cg_program::create_from_file( CGprofile profile, const std::string& filename, 
    const char* main_func, const char** args, CGenum program_type )
{
    _profile = profile;
    cgGLSetOptimalOptions( _profile );
    check_for_cg_error( "selecting profile", GLOO_HERE  );

    _program = cgCreateProgramFromFile( 
        _context, 
        program_type, 
        filename.c_str(),
        _profile,
        main_func,
        args 
        );

    check_for_cg_error( std::string( "creating program from: " + filename ), 
        GLOO_HERE, _context );

    cgGLLoadProgram( _program );
    
    check_for_cg_error( std::string( "creating program from: " + filename ), 
        GLOO_HERE );

}



cg_uniform* 
cg_program::get_uniform( const std::string& name )
{
    std::map< std::string, cg_uniform* >::iterator it 
        = _uniforms.find( name );

    if ( it != _uniforms.end() )
        return (*it).second;

    // no uniform with this name exists, we need to create one
    cg_uniform* uniform = new cg_uniform( _program, name );
    check_for_cg_error( std::string( "getting uniform parameter: " ) + name, 
        GLOO_HERE  );
    _uniforms[ name ] = uniform;
    return uniform;
}



CGcontext 
cg_program::create_context()
{
    return cgCreateContext();
}



} // namespace gloo

