#include <gloo/camera.hpp>

namespace gloo
{

camera::camera()
    : _viewport()
    , _projection( mat4f::IDENTITY )
    , _model_view( mat4f::IDENTITY )
{}



void 
camera::look_at( const vec3f& eye_position, const vec3f& center, 
    const vec3f& up ) 
{   
	vec3f tmp_f( center - eye_position );   
    vec3f tmp_up( up );
	tmp_f.normalise();
    tmp_up.normalise();
    
	vec3f tmp_s;
    tmp_s.cross( tmp_f, tmp_up );
    
	vec3f tmp_u;
    tmp_u.cross( tmp_s, tmp_f );
    
	_model_view.set( 
        tmp_s.x,  tmp_s.y,  tmp_s.z,  0.0f,
		tmp_u.x,  tmp_u.y,  tmp_u.z,  0.0f,
		-tmp_f.x, -tmp_f.y, -tmp_f.z, 0.0f,
        0, 0, 0, 1.0f );
        
    mat4f trans( mat4f::IDENTITY );
    trans.setTranslation( - eye_position );
    _model_view *= trans;
}




void 
camera::set_ortho( const frustumf& frustum_ )
{
    _frustum = frustum_;
    _projection = _frustum.computeOrthoMatrix();

}




void 
camera::set_perspective( double left, double right, double bottom, double top,
    double near_plane, double far_plane )
{
    _frustum.set( left, right, bottom, top, near_plane, far_plane );
    _projection = _frustum.computeMatrix();
}



void 
camera::set_perspective( const frustumf& frustum_ )
{
    _frustum = frustum_;
    _projection = _frustum.computeMatrix();
}




void 
camera::look_at( const vec3f& aabb_min, const vec3f& aabb_max,
    double zoom, ssize_t width_, ssize_t height_ )
{
    vec3f diagonal = aabb_max - aabb_min;
    const vec3f center = aabb_min + ( diagonal * 0.5 );

    double largest = diagonal.x;
    if ( diagonal.y > largest )
        largest = diagonal.y;
    if ( diagonal.z > largest )
        largest = diagonal.z;

    float zoomed = largest * zoom;

    _frustum.left       = - zoomed;
    _frustum.right      = zoomed;
    _frustum.bottom     = - zoomed;
    _frustum.top        = zoomed;
    _frustum.nearPlane  = 1.0f;
    _frustum.farPlane   = _frustum.nearPlane + 5.0 * 2.0 * zoomed;

    double width     = ( width_ == -1 ) ? _viewport.width  : width_;
    double height    = ( height == -1 ) ? _viewport.height : height_;
    
    _viewport.width = static_cast< GLsizei >( width );
    _viewport.height = static_cast< GLsizei >( height );

    double aspect = width / height;
    if ( aspect > 1.0f )
    {
        _frustum.bottom /= aspect;
        _frustum.top /= aspect;
    }
    else if ( aspect < 1.0f )
    {
        _frustum.left *= aspect;
        _frustum.right *= aspect;
    }
    
    _projection = _frustum.computeMatrix();
    look_at( vec3f( center.x, center.y, center.z + 2.0 + largest  ), center, 
        vec3f( 0.0, 1.0, 0.0 ) );
}




void 
camera::set_projection( const mat4f& projection_ )
{
    _projection = projection_;
}




void 
camera::set_model_view( const mat4f& model_view_ )
{
    _model_view = model_view_;
}



void 
camera::reshape( size_t width_, size_t height_ )
{
    if ( _viewport.width != 0 && _viewport.height != 0 )
    {
        double oldaspect = static_cast< double >( _viewport.width ) 
            / static_cast< double > ( _viewport.height );

        if ( oldaspect > 1.0 )
        {
            _frustum.bottom *= oldaspect;
            _frustum.top *= oldaspect;
        }
        else if ( oldaspect < 1.0  )
        {
            _frustum.right /= oldaspect;
            _frustum.left /= oldaspect;
        }
    }
    
    double aspect = static_cast< double >( width_ ) 
        / static_cast< double >( height_ );

    if ( aspect > 1.0f )
    {
        _frustum.bottom /= aspect;
        _frustum.top /= aspect;
    }
    else if ( aspect < 1.0f )
    {
        _frustum.left *= aspect;
        _frustum.right *= aspect;
    }

    _viewport.width  = width_;
    _viewport.height = height_;

    _projection = _frustum.computeMatrix();

}




mat4f
camera::get_proj_model_view() const
{
    return _projection * _model_view;
}




void 
camera::set_viewport( const viewport& viewport_ )
{
    _viewport = viewport_;
}




void 
camera::set_viewport( GLint x, GLint y, GLsizei width_, GLsizei height_ )
{
    _viewport.x = x;
    _viewport.y = y;
    _viewport.width = width_;
    _viewport.height = height_;
}



} //namespace gloo

