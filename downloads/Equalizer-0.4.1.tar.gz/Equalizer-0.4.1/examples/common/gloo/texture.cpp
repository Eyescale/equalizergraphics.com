#include <gloo/texture.hpp>

namespace gloo
{

texture::texture()
    : _name( 0 )
    , _width( 0 )
    , _height( 0 )
    , _depth( 0 )
{
    glGenTextures( 1, &_name );
}



texture::texture( GLenum target, GLuint name, GLuint internal_format, 
    GLuint width, GLuint height, GLuint depth )
    : _name( name )
    , _target( target )
    , _format( internal_format )
    , _width( width )
    , _height( height )
    , _depth( depth )
{}



texture::~texture()
{
    glDeleteTextures( 1, &_name );
}



void 
texture::image( texture_data& data, GLenum target, GLenum internal_format, 
    GLint level, GLint border )
{
    switch ( data.dimensions )
    {
        case 1:
            image_1d_gl( target, level, internal_format, data.width,
                border, data.source_format, data.source_datatype, data.pixels );
            break;
        case 2:
            image_2d_gl( target, level, internal_format, data.width,
                data.height, border, data.source_format, data.source_datatype, 
                data.pixels );
            break;
        case 3:
            image_3d_gl( target, level, internal_format, data.width,
                data.height, data.depth, border, data.source_format, 
                data.source_datatype, data.pixels );
            break;
        default:
            throw invalid_parameter_exception( 
                " creating texture from texture_data object", GLOO_HERE 
                );
    }
    

    check_for_gl_error( true, "creating texture." );
}



/** 
*   image_*d* functions 
*   -> allocate memory in gl for texture data
*   -> specify texture image data
*   reordered parameters to most-used pattern and specified some reasonable 
*   defaults, otherwise the same as the image_*d_gl functions.
*/


// user-friendly version. for parameters, see glTexImage1D manpage
void 
texture::image_1d( 
    const GLvoid* pixels,   // buffer with pixel data ( or 0 )
    GLsizei width, 
    GLenum target,          // texture target, e.g. GL_TEXTURE_1D
    GLenum internal_format, // see glTexImage1D manpage
    GLenum source_format,   // source data format
    GLenum source_datatype, // source data type
    GLint level,            // mipmap level of detail number
    GLint border
    )
{
    image_1d_gl( target, level, internal_format, width, border, source_format,
        source_datatype, pixels );
}


// 'original' version. replicates glTexImage1D parameters, see manpage
void 
texture::image_1d_gl( GLenum target, GLint level, GLint internalformat, 
    GLsizei width, GLint border, GLenum format, GLenum type,
    const GLvoid* pixels )
{
    _target             = target;
    _width              = width;
    _height             = 0;
    _depth              = 0;
    _format             = internalformat;

    enable();
    bind();	

    glTexImage1D( target, level, internalformat, width, border, 
        format, type, pixels );

    check_for_gl_error( true, "creating 1d texture." );
}




// user-friendly version. for parameters, see glTexImage1D manpage
void 
texture::image_2d( 
    const GLvoid* pixels,   // buffer with pixel data ( or 0 )
    GLsizei width, 
    GLsizei height,  
    GLenum target,          // texture target, e.g. GL_TEXTURE_2D
    GLenum internal_format, // see glTexImage2D manpage
    GLenum source_format,   // source data format
    GLenum source_datatype, // source data type
    GLint level,            // mipmap level of detail number
    GLint border
    )
{
    image_2d_gl( target, level, internal_format, width, height, border, 
        source_format, source_datatype, pixels );
}


// 'original' version. replicates glTexImage1D parameters, see manpage
void 
texture::image_2d_gl( GLenum target, GLint level, GLint internalformat, 
    GLsizei width, GLsizei height, GLint border, GLenum format, 
    GLenum type, const GLvoid* pixels )
{
    _target             = target;
    _width              = width;
    _height             = height;
    _depth              = 0;
    _format             = internalformat;
    
    enable();
    bind();	
    
    glTexImage2D( _target, level, _format, _width, _height, border, 
        format, type, pixels );

    check_for_gl_error( true, "creating 2d texture." );
}


// user-friendly version. for parameters, see glTexImage1D manpage
void 
texture::image_3d( 
    const GLvoid* pixels, // buffer with pixel data ( or 0 )
    GLsizei width, 
    GLsizei height,  
    GLsizei depth,  
    GLenum target,          // texture target, e.g. GL_TEXTURE_3D
    GLenum internal_format, // see glTexImage3D manpage
    GLenum source_format,   // source data format
    GLenum source_datatype, // source data type
    GLint level,            // mipmap level of detail number
    GLint border
    )
{
    image_3d_gl( target, level, internal_format, width, height, depth, border, 
        source_format, source_datatype, pixels );
}



// 'original' version. replicates glTexImage1D parameters, see manpage
void 
texture::image_3d_gl( GLenum target, GLint level, GLint internalformat, 
    GLsizei width, GLsizei height, GLsizei depth, GLint border, 
    GLenum format, GLenum type, const GLvoid* pixels )
{
    _target             = target;
    _width              = width;
    _height             = height;
    _depth              = depth;
    _format             = internalformat;
    
    enable();
    bind();	
    
    glTexImage3D( _target, level, _format, _width, _height, _depth, border, 
        format, type, pixels );

    check_for_gl_error( true, "creating 3d texture." );
}



/** 
*   sub_image_*d* functions 
*   -> specify texture sub-image data
*   reordered parameters to most-used pattern and specified some reasonable 
*   defaults, otherwise the same as the sub_image_*d_gl functions.
*/


void 
texture::sub_image( texture_data& data, GLint xoffset, GLint yoffset, 
    GLint zoffset, GLint level )
{
    switch ( data.dimensions )
    {
        case 1:
            sub_image_1d_gl( _target, level, xoffset, data.width,
                data.source_format, data.source_datatype, data.pixels );
            break;
        case 2:
            sub_image_2d_gl( _target, level, xoffset, yoffset, data.width,
                data.height, data.source_format, data.source_datatype, 
                data.pixels );
            break;
        case 3:
            sub_image_3d_gl( _target, level, xoffset, yoffset, zoffset, 
                data.width, data.height, data.depth, data.source_format, 
                data.source_datatype, data.pixels );
            break;
        default:
            throw invalid_parameter_exception( 
                " updating texture from texture_data object", 
                GLOO_HERE );
    }   

    check_for_gl_error( true, "creating texture." );
}


// user-friendly version. for parameters, see glTexSubImage1D manpage
void 
texture::sub_image_1d( 
    const GLvoid* pixels,   // buffer with pixel data ( or 0 )
    GLsizei width, 
    GLint xoffset,          // offset into the texture
    GLenum target,          // texture target, e.g. GL_TEXTURE_1D
    GLenum source_format,   // source data format
    GLenum source_datatype, // source data type
    GLint level             // mipmap level of detail number
    )
{
    sub_image_1d_gl( target, level, xoffset, width, source_format,
        source_datatype, pixels );
}


// 'original' version. replicates glTexSubImage1D parameters, see manpage
void 
texture::sub_image_1d_gl( GLenum target, GLint level, GLint xoffset, 
    GLsizei width, GLenum format, GLenum type, const GLvoid* pixels )
{
    enable();
    bind();	

    glTexSubImage1D( target, level, xoffset, width, format, type, pixels );

    check_for_gl_error( true, "creating 1d texture." );
}



// user-friendly version. for parameters, see glTexSubImage2D manpage
void 
texture::sub_image_2d( 
    const GLvoid* pixels,   // buffer with pixel data ( or 0 )
    GLsizei width, 
    GLsizei height, 
    GLint xoffset,          // offset into the texture
    GLint yoffset,          // offset into the texture
    GLenum target,          // texture target, e.g. GL_TEXTURE_1D
    GLenum source_format,   // source data format
    GLenum source_datatype, // source data type
    GLint level             // mipmap level of detail number
    )
{
    sub_image_2d_gl( target, level, xoffset, yoffset, width, height, 
        source_format, source_datatype, pixels );
}


// 'original' version. replicates glTexSubImage2D parameters, see manpage
void 
texture::sub_image_2d_gl( GLenum target, GLint level, GLint xoffset, 
    GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, 
    const GLvoid* pixels )
{
    enable();
    bind();	

    glTexSubImage2D( target, level, xoffset, yoffset, width, height, 
        format, type, pixels );

    check_for_gl_error( true, "specifying sub-image of 2d texture." );
}



// user-friendly version. for parameters, see glTexSubImage3D manpage
void 
texture::sub_image_3d( 
    const GLvoid* pixels,   // buffer with pixel data ( or 0 )
    GLsizei width, 
    GLsizei height, 
    GLsizei depth, 
    GLint xoffset,          // offset into the texture
    GLint yoffset,          // offset into the texture
    GLint zoffset,          // offset into the texture
    GLenum target,          // texture target, e.g. GL_TEXTURE_1D
    GLenum source_format,   // source data format
    GLenum source_datatype, // source data type
    GLint level             // mipmap level of detail number
    )
{
    sub_image_3d_gl( target, level, xoffset, yoffset, zoffset, width, height, 
        depth, source_format, source_datatype, pixels );
}


// 'original' version. replicates glTexSubImage2D parameters, see manpage
void 
texture::sub_image_3d_gl( GLenum target, GLint level, GLint xoffset, 
    GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, 
    GLenum format, GLenum type, const GLvoid* pixels )
{
    enable();
    bind();	

    glTexSubImage3D( target, level, xoffset, yoffset, zoffset, width, height, 
        depth, format, type, pixels );

    check_for_gl_error( true, "specifying sub-image of 2d texture." );
}


  
void 
texture::set_float_texture_param_defaults()
{
    glTexParameteri( _target, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri( _target, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri( _target, GL_TEXTURE_WRAP_S, GL_CLAMP );
    glTexParameteri( _target, GL_TEXTURE_WRAP_T, GL_CLAMP );
}




void 
texture::set_texture_param_defaults()
{
    glTexParameteri( _target, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri( _target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri( _target, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri( _target, GL_TEXTURE_WRAP_T, GL_REPEAT);    
}



void 
texture::set( GLenum target, GLuint name, GLuint internal_format, 
    GLuint width, GLuint height, GLuint depth )
{
    _target             = target;
    _width              = width;
    _height             = height;
    _depth              = depth;
    _format             = internal_format;
}


} //namespace gloo
