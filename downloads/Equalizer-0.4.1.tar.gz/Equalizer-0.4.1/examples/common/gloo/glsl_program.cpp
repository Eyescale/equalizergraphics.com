#include <gloo/glsl_program.hpp>
#include <gloo/opengl_errors.hpp>

#include <iostream>
#include <fstream>

namespace gloo
{

glsl_program::glsl_program()
	: _program( glCreateProgram() )
    , _linked( false )
{}



glsl_program::~glsl_program()
{
	destroy();
}



GLuint 
glsl_program::add_source_from_file( GLenum type, 
    const std::string& filename )
{
	GLuint shader = glCreateShader( type );
    if ( check_for_gl_error() )
    {
        std::cout << "glsl_program - creating shader of type " << type 
            << " from file " << filename << " failed." << std::endl;
        exit( 1 );
    }
    
    _shaders[ type ].push_back( shader );
    
    size_t index = _read_file( filename );
    glShaderSource( shader, 1, (const GLchar**)&_sources[index], 0 );        
    _shader_files[ shader ] = filename;

	glAttachShader( _program, shader );
    
    std::cout << "glsl_program: added source from " << filename << std::endl;
    
    return shader;
}



GLuint 
glsl_program::add_source_from_string( GLenum type, 
    const char* source )
{
	GLuint shader = glCreateShader( type );
    if ( check_for_gl_error() )
    {
        std::cout << "glsl_program - creating shader of type " << type 
            << " from source string failed." << std::endl;
        exit( 1 );
    }
    
    _shaders[ type ].push_back( shader );

    glShaderSource( shader, 1, &source, 0);        
    _shader_files[ shader ] = "from string";

	glAttachShader( _program, shader );

    std::cout << "glsl_program: added source from string" << std::endl;

	return shader;
}



void
glsl_program::_compile_shaders()
{
    GLuint shader;
    GLint  status;

    std::map< GLuint, std::list< GLuint > >::iterator type_it = _shaders.begin();
    std::map< GLuint, std::list< GLuint > >::iterator type_ite = _shaders.end();

    std::list< GLuint >::iterator it, ite;

    for ( ; type_it != type_ite; ++type_it )
    {
        it = (*type_it).second.begin();
        ite = (*type_it).second.end();
        for ( ; it != ite; ++it )
        {
            shader = *it;
            glCompileShader( shader );
            glGetShaderiv( shader, GL_COMPILE_STATUS, &status );
            
            std::cout << "glsl_program: shader " << shader
                << " [" << _shader_files[ shader ] << "]: compile status: "; 
            
            if ( status != GL_TRUE )
            {
                std::cout << " error. " << std::endl;
                print_shader_log2( (GLhandleARB&) shader );
                exit( status );
            }
            else
            {
                std::cout << " ok. " << std::endl;
            }
        }
    }
}



GLuint 
glsl_program::create()
{  
    _compile_shaders();

	glLinkProgram( _program );
    if ( check_for_gl_error() )
    {
        std::cout << "glsl_program: linking shaders of program " 
            << _program << " failed. " << std::endl;
        exit(1);
    }

    std::cout << "glsl_program: successfully compiled and linked " 
        << "shader program " << _program << "." << std::endl;

    _linked = true;
    return _program;
}



glsl_uniform& 
glsl_program::get_uniform( const std::string& name )
{
    std::map< std::string, glsl_uniform* >::iterator it = _uniforms.find( name );
    if ( it != _uniforms.end() )
        return *( (*it).second );

    if ( !_linked )
    {
        std::cout << "glsl_program - tried accessing a uniform parameter "
            << "before linking the program. Aborting..." << std::endl;
        exit( 1 );
    }
    glsl_uniform* uniform = new glsl_uniform();
    uniform->create( _program, name );
    _uniforms[ name ] = uniform;
    return *uniform;
}



void
glsl_program::setup_uniform( glsl_uniform& uniform_, const std::string& name )
{
    std::map< std::string, glsl_uniform* >::iterator it = _uniforms.find( name );
    if ( it != _uniforms.end() )
        uniform_ = *(*it).second;
    
    if ( !_linked )
    {
        std::cout << "glsl_program - tried accessing a uniform parameter "
            << "before linking the program. Aborting..." << std::endl;
        // FIXME TODO exception
        exit( 1 );
    }
    uniform_.create( _program, name );
    _uniforms[ name ] = &uniform_;   
}



void 
glsl_program::set_uniform_1f( const std::string& name, float value )
{
    std::map< std::string, glsl_uniform* >::iterator it = _uniforms.find( name );
    glsl_uniform& uniform =  ( it != _uniforms.end() ) ? *(*it).second 
        : get_uniform( name ); 
    uniform = value;
}



void
glsl_program::set_texture_unit( GLuint unit, glsl_uniform& sampler, 
    texture& texture_ )
{
    enable();
	glActiveTexture( GL_TEXTURE0 + unit );
	if ( check_for_gl_error() )
	{
		std::cout << "glsl_program: Error while activating texture unit " 
        << unit << std::endl;
		exit(1);
	}
    texture_.bind();
    sampler = unit;
	if ( check_for_gl_error() )
	{
		std::cout << "glsl_program: Error while setting texture sampler " 
        << sampler.get_name() << " in unit " << unit << " in shader " 
        << _program << std::endl;
		assert(0);
	}
	//std::cout << "glsl_program: Set texture " << samplername << " to texture unit " << unit << std::endl;
	//glUseProgram(0); 
}



void 
glsl_program::reset()
{
    destroy();
    _program = glCreateProgram();
    _linked = false;
}



void 
glsl_program::destroy()
{
    std::map< std::string, glsl_uniform* >::iterator it  = _uniforms.begin();
    std::map< std::string, glsl_uniform* >::iterator ite = _uniforms.end();
    for ( ; it != ite; ++it )
    {
        delete (*it).second;
        _uniforms.erase( it );
    }
    _uniforms.clear();

    std::list< GLuint >::iterator sit =     _vertex_shaders.begin();
    std::list< GLuint >::iterator site =    _vertex_shaders.end();
    for ( ; sit != site; ++sit )
    {
        glDetachShader( _program, *sit );    
        glDeleteShader( *sit );
    }
    _vertex_shaders.clear();
 
    sit = _fragment_shaders.begin();
    site = _fragment_shaders.end();

    for ( ; sit != site; ++sit )
    {
        glDetachShader( _program, *sit );    
        glDeleteShader( *sit );
    }
    _fragment_shaders.clear();

  	glDeleteProgram( _program );

    std::vector< char* >::iterator ssit = _sources.begin();
    for ( ; ssit != _sources.end(); ++ssit )
    {
        delete[] *ssit;
    }
	_program = 0;
    _linked = false;

}



size_t 
glsl_program::print_shader_log2( GLhandleARB shader )
{
    GLint length = 0;
    GLint written = 0;
    glGetObjectParameterivARB( shader, 
        GL_OBJECT_INFO_LOG_LENGTH_ARB, &length );
    if ( length > 0 )
    {
        GLcharARB* log = new GLcharARB[ length ];
        glGetInfoLogARB( shader, length, &written, log );
        std::cout << log;
        delete[] log;
    }
    return length;
}



void 
glsl_program::print_shader_log( GLuint obj )
{
    GLint log_length = 0;       
	glGetShaderiv( obj, GL_INFO_LOG_LENGTH, &log_length );
    
    if ( log_length > 0 )
    {
        char* log = new char[ log_length ];
        GLint chars_written  = 0;

        glGetShaderInfoLog( obj, log_length, &chars_written, log );
		std::cout << log << std::endl;
        
        delete[] log;
    }
}


void 
glsl_program::print_program_log( GLuint obj )
{
    GLint log_length = 0;

	glGetProgramiv( obj, GL_INFO_LOG_LENGTH, &log_length );
    
    if ( log_length > 0 )
    {
        char* log = new char[ log_length ];
        GLint chars_written  = 0;

        glGetProgramInfoLog( obj, log_length, &chars_written, log );
		std::cout << log << std::endl;
        
        delete[] log;
    }
}



size_t 
glsl_program::_read_file( const std::string& pFileName )
{
    using namespace std;
    ifstream in;
    in.open( pFileName.c_str() );
    if ( ! in.good() )
        assert( 0 && "glsl_program: reading shader source failed!" );
    in.seekg(0, ios::end);
    size_t length = in.tellg();
    in.seekg(0, ios::beg);
    char* buffer = new char[length+1];
    
    size_t idx = _sources.size();
    _sources.push_back( buffer );
    in.read( buffer, length);
    buffer[length] = '\0';
    in.close();
    std::cout << "glsl_program: read shader source " << pFileName << " of length " 
        << length << std::endl;
    return idx;
}


} //namespace gloo
