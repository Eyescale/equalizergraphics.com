#include <gloo/vertex_buffer_object.hpp>

#include <iostream>

namespace gloo
{


vertex_buffer_object::vertex_buffer_object()
	: _name( 0 )
    , _target( GL_ARRAY_BUFFER )
	, _size( 0 )
    , _usage( GL_STATIC_DRAW_ARB )
{}



vertex_buffer_object::~vertex_buffer_object()
{
	destroy();
}



void 
vertex_buffer_object::create( GLenum target,  GLsizeiptr size, 
    const GLvoid* data, GLenum usage )
{
	glGenBuffers( 1, &_name );
	_target = target;
	_size = size;
	_usage = usage;

	glBindBuffer( _target, _name );
	glBufferData( _target, _size, data, _usage );
    
    #if 0
    std::cout << "vertex_buffer_object::create " << std::endl;
    std::cout << "  created vbo of size " << size << std::endl;
    #endif
}



void 
vertex_buffer_object::destroy()
{
	if ( _name )
		glDeleteBuffers( 1, &_name );	
	_name = 0;
}




} // namespace gloo

