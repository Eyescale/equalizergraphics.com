#include <gloo/default_window.hpp>

namespace gloo
{

default_window::default_window( const std::string& window_title, 
    size_t height, size_t width )
    : _window( window_title, height, width, 0 ) 
    , _camera()
    , _fps_control( vec3f( 0.0, 1.0, 0.0 ), vec3f( 1.0, 0.0, 1.0 ), 
        vec3f( 0.0, 1.0, 0.0 ) )
{
    _window.set_render_target( this );
    _window.set_reshape_target( &_camera );
    _window.set_idle_target( this );

    _camera.set_perspective( -0.5, 0.5, -0.5, 0.5, 0.5, 1000.0 );

}



void
default_window::start()
{
    _window.start();
}



void
default_window::draw()
{
    glClear( GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT );

    // set up the model view matrix 
    _fps_control.compute_matrix( _camera.get_model_view() );

    // load modelview and projection matrices
    _camera.set_view();
      
    _draw_scene();

}



void
default_window::_draw_scene()
{
    std::cout << "gloo_default_window: override _draw_scene() in your "
        << "application and add your render calls there. " << std::endl;
}



void 
default_window::on_idle()
{
    _window.redraw();
}


} //namespace gloo

