
#include <gloo/pixel_buffer_object.hpp>
#include <gloo/opengl_errors.hpp>

#include <iostream>
#include <cassert>

namespace gloo
{

pixel_buffer_object::pixel_buffer_object()
	: _name ( 0 )
	, _size_in_bytes( 0 )
	, _width ( 0 )
	, _height ( 0 )
{
	glGenBuffers(1, &_name);
}



pixel_buffer_object::~pixel_buffer_object()
{
	glDeleteBuffers( 1, &_name );
}


	
void 
pixel_buffer_object::create( GLuint width_, GLuint height_, 
    size_t size_in_bytes, GLenum _usage_hint_ )
{
	_width          = width_;
	_height         = height_;
	_size_in_bytes  = size_in_bytes;
    _usage_hint     = _usage_hint_;

	// Create a buffer object for a number of vertices consisting of
	// 4 float values per vertex (xyzw/rgba)
	glBindBuffer(GL_PIXEL_PACK_BUFFER_ARB, _name);
	glBufferData(GL_PIXEL_PACK_BUFFER_ARB, size_in_bytes,
	             0, _usage_hint);
			
	if ( ! check_for_gl_error( "while creating pixel_buffer_object.") ) 
        std::cout << "pixel_buffer_object: created pbo with gl name " 
            << _name << std::endl;
	
}



// this create function uses the defaults for texture streaming
void 
pixel_buffer_object::create( texture& tex, size_t pixel_size_in_bytes )
{
	_width  = tex.get_width();
	_height = tex.get_height();
	_size_in_bytes  = pixel_size_in_bytes * _width * _height;
    _usage_hint = GL_STREAM_DRAW;

	// Create a buffer object for a number of vertices consisting of
	// 4 float values per vertex (xyzw/rgba)
	glBindBuffer( GL_PIXEL_UNPACK_BUFFER_ARB, _name );
	glBufferData(GL_PIXEL_UNPACK_BUFFER_ARB, _size_in_bytes,
	             0, _usage_hint);
			
	if ( ! check_for_gl_error( "while creating pixel_buffer_object.") ) 
        std::cout << "pixel_buffer_object: created pbo with gl name " 
            << _name << std::endl;
	

}




void
pixel_buffer_object::read_back( GLenum buffer_, GLuint width_, GLuint height_ )
{
	// bind pbo
	glBindBuffer(GL_PIXEL_PACK_BUFFER_ARB, _name );

	// Read the vertex data back from framebuffer 
	// note that this is a transfer gpu -> gpu
	glReadBuffer( buffer_ );
	glReadPixels( 0, 0, width_, height_, GL_RGBA, GL_FLOAT, 0 );
	
	// unbind pbo
	glBindBuffer(GL_PIXEL_PACK_BUFFER_ARB, 0 );

	check_for_gl_error( " during data transfor from fbo into pbo" ); 
}



void 
pixel_buffer_object::read_back_to_main_memory( GLenum pBuffer, 
    GLuint width_, GLuint height_ )
{	
	// don't use this function in release code. debug only -> slow!
	
	GLfloat* debug = new GLfloat[ _size_in_bytes ];
	glReadPixels( 0, 0, width_, height_, GL_RGBA, GL_FLOAT, debug);
	std::cout << "Debug out: " << std::endl;
	for ( int i = 0; i < width_*height_; i++ )
	{
		int j = 4 * i;
		if ( i % 32 == 0 )
			std::cout << std::endl << "=== " << i / 32 << " ===" << std::endl;
		std::cout << "v(" << debug[j] << "/"<< debug[j+1] << "/"<< debug[j+2] << "/"<< debug[j+3] << ") ";
	}
	std::cout << "Debug out end." << std::endl;
	delete[] debug;
}



// slow if usage hint is not GL_STREAM_DRAW
void 
pixel_buffer_object::stream_to_texture( texture& texture_, 
    texture_data& data_ )
{   
    texture_.bind();
    
	glBindBuffer( GL_PIXEL_UNPACK_BUFFER_ARB, _name );
    
    // map the texture image buffer
    void* pbo_memory = glMapBuffer( GL_PIXEL_UNPACK_BUFFER_ARB, GL_WRITE_ONLY );
    
    // modify (sub-)buffer data 
    memcpy( pbo_memory, data_.pixels, data_.size_in_bytes );
    
    // unmap the texture image buffer
    glUnmapBuffer( GL_PIXEL_UNPACK_BUFFER_ARB ); 
    
    // update (sub-)teximage from texture image buffer
    //
    texture_data nulldata( data_ );
    nulldata.pixels = 0;
    
    texture_.sub_image( nulldata, 0, 0, 0 );

    // start drawing...
}


} // namespace gloo
