#include <gloo/pixel_data.hpp>

namespace gloo
{

void
pixel_data::read_pixels( image& image_, const camera& camera, GLenum format, 
    ssize_t channels ) 
{
    const viewport& vp = camera.get_viewport();

    _read_pixels(  image_.pixels, vp, format, 
        GL_UNSIGNED_BYTE, channels );
    
    image_.width = vp.width - vp.x;
    image_.height = vp.height - vp.y;
    image_.format = format;
}


void
pixel_data::read_pixels( image& image_, 
    const vec4i& viewport_, GLenum format, ssize_t channels ) 
{
    _read_pixels( image_.pixels, viewport_, format, GL_UNSIGNED_BYTE, channels );

    image_.width = viewport_.width - viewport_.x;
    image_.height = viewport_.height - viewport_.y;
    image_.format = format;
}



void
pixel_data::read_pixels( std::vector< unsigned char >& pixels, 
    const camera& camera, GLenum format, ssize_t channels ) 
{
    _read_pixels( pixels, camera.get_viewport(), format, GL_UNSIGNED_BYTE, 
        channels );
}


void
pixel_data::read_pixels( std::vector< unsigned char >& pixels, 
    const vec4i& viewport_, GLenum format, ssize_t channels ) 
{
    _read_pixels( pixels, viewport_, format, GL_UNSIGNED_BYTE, channels );
}



void
pixel_data::read_pixels( std::vector< float >& pixels, 
    const camera& camera, GLenum format, ssize_t channels ) 
{
    _read_pixels( pixels, camera.get_viewport(), format, 
        GL_FLOAT, channels );
}



void
pixel_data::read_pixels( std::vector< float >& pixels, 
    const vec4i& viewport_, GLenum format, ssize_t channels ) 
{
    _read_pixels( pixels, viewport_, format, GL_FLOAT, channels );
}


} // namespace gloo

