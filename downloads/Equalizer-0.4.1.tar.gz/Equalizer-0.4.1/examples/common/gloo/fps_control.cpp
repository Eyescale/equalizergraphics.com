#include <gloo/fps_control.hpp>

namespace gloo
{

fps_control::fps_control( const vec3f& eye_, const vec3f& look_, 
    const vec3f& up_ ) 
    : _eye_position( eye_ )
    , _look( look_ )
    , _up( up_ )
    , _mouse_diff( 0, 0 )
    , _control_mode( FPS_WALK )
    , _step_size( 0.1 )
{}



fps_control::fps_control( const vec3f& up_ ) 
    : _eye_position( 0.0, 0.0, 0.0 )
    , _look( vec3f( 1.0, 1.0, 1.0 ) - up_ )
    , _up( up_ )
    , _mouse_diff( 0, 0 )
    , _control_mode( FPS_WALK )
    , _step_size( 0.1 )
{}



void 
fps_control::turn( float angle_in_radians )
{
    mat4f rot( mat4f::IDENTITY );
    rot.rotate( angle_in_radians, _up );
    _look = rot * _look; 
}



} // namespace gloo

