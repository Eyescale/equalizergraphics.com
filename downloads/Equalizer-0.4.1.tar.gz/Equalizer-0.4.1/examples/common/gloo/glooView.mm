#import "glooView.h"

@implementation glooView

- (void) drawRect: (NSRect) bounds
{
    [self update];
}



- (void) reshape
{
    NSSize bounds = [self frame].size;
    //std::cout << bounds.width << " " << bounds.height << std::endl;
    if ( _reshape_target )
        _reshape_target->reshape( bounds.width, bounds.height );
    else
        glViewport( 0, 0, bounds.width, bounds.height );
    [super reshape];
    [self drawRect:[self frame]];
}



- (void) update
{
    if ( ! _example )
    {
        _example = new gloo::cocoa_example();
        _render_target  = _example;
        _reshape_target = _example->get_camera_ptr();
    }
    
    //assert( _render_target );
    if ( _render_target )
        _render_target->draw();
    else
    {
        glClearColor( 1, 1, 1, 1);
        glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    }
    glFlush();
}

@end
