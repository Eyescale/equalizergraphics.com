/* glooView */

#import <Cocoa/Cocoa.h>

#include <OpenGL/gl.h>

#include <gloo/render_target.h>
#include <gloo/mouse_target.h>
#include <gloo/key_target.h>
#include <gloo/idle_target.h>
#include <gloo/reshape_target.h>

#include "gloo_cocoa_example.h"

@interface glooView : NSOpenGLView
{
    gloo::render_target*    _render_target;
    gloo::reshape_target*   _reshape_target;
    gloo::idle_target*      _idle_target;
    
    gloo::cocoa_example*    _example;

}

- (void) drawRect: (NSRect) bounds ;
- (void) update;
- (void) reshape;

@end
