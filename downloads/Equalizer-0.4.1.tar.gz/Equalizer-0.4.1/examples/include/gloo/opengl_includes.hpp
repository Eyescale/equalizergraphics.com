#ifndef __GLOO__OPENGL_INCLUDES__H__
#define __GLOO__OPENGL_INCLUDES__H__

#ifndef GL_GLEXT_PROTOTYPES
#define GL_GLEXT_PROTOTYPES
#endif

#ifdef _WIN32

#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h>

#else 

#ifdef __APPLE__

#include <OpenGL/gl.h>
#include <GLUT/glut.h>

#else 
// linux

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

#endif

#endif



#endif
