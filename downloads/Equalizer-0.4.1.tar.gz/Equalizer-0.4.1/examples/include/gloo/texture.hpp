#ifndef __GLOO__TEXTURE__H__
#define __GLOO__TEXTURE__H__

#include <gloo/opengl_includes.hpp>
#include <gloo/opengl_errors.hpp>
#include <gloo/texture_data.hpp>

/**
 *
 * @brief lightweight wrapper for opengl textures
 *
 *
 * @note the create_xd functions have different parameter ordering compared to
 *   glTexImageXD, so defaults can be used without having to always supply 
 *   all the parameters
 *
 * @author jonas boesch
 */

namespace gloo
{

class texture
{
public: 
    texture();
    texture( GLenum target, GLuint name, GLuint internal_format = 0, 
        GLuint width = 0, GLuint height = 0, GLuint depth = 0 );
    ~texture();

    inline void bind();
    inline void unbind();   

    inline void enable();   
    inline void disable();   

    /** 
    *   image_*d* functions 
    *   -> allocate memory in gl for texture data
    *   -> specify texture image data
    *
    *   reordered parameters to most-used pattern and specified some reasonable 
    *   defaults, otherwise the same as the image_*d_gl functions.
    */
    
    void image( texture_data& data, GLenum target, 
        GLenum internal_format = GL_RGBA, GLint level = 0, GLint border = 0 );

    // user-friendly version. for parameters, see glTexImage1D manpage
    void image_1d( 
        const GLvoid* pixels, // buffer with pixel data ( or 0 )
        GLsizei width, 
        GLenum target           = GL_TEXTURE_1D,    // texture target
        GLenum internal_format  = GL_RGBA,          // see glTexImage2D manpage
        GLenum source_format    = GL_RGBA,          // source data format
        GLenum source_datatype  = GL_UNSIGNED_BYTE, // source data type
        GLint level = 0, // mipmap level of detail number
        GLint border = 0
    );
    
    // 'original' version. replicates glTexImage1D parameters, see manpage
    void image_1d_gl( GLenum target, GLint level, GLint internalformat, 
        GLsizei width, GLint border, GLenum format, GLenum type,
        const GLvoid* pixels );
    
    
    // user-friendly version. for parameters, see glTexImage2D manpage
    void image_2d( 
        const GLvoid* pixels, // buffer with pixel data ( or 0 )
        GLsizei width, 
        GLsizei height,  
        GLenum target           = GL_TEXTURE_2D,    // texture target
        GLenum internal_format  = GL_RGBA,          // see glTexImage2D manpage
        GLenum source_format    = GL_RGBA,          // source data format
        GLenum source_datatype  = GL_UNSIGNED_BYTE, // source data type
        GLint level = 0, // mipmap level of detail number
        GLint border = 0
    );

    // 'original' version. replicates glTexImage2D parameters, see manpage
    void image_2d_gl( GLenum target, GLint level, GLint internalformat, 
        GLsizei width, GLsizei height, GLint border, GLenum format, 
        GLenum type, const GLvoid* pixels );


    // user-friendly version. for parameters, see glTexImage3D manpage
    void image_3d( 
        const GLvoid* pixels, // buffer with pixel data ( or 0 )
        GLsizei width, 
        GLsizei height,  
        GLsizei depth,  
        GLenum target           = GL_TEXTURE_3D,    // texture target
        GLenum internal_format  = GL_RGBA,          // see glTexImage3D manpage
        GLenum source_format    = GL_RGBA,          // source data format
        GLenum source_datatype  = GL_UNSIGNED_BYTE, // source data type
        GLint level = 0, // mipmap level of detail number
        GLint border = 0
    );

    // 'original' version. replicates glTexImage3D parameters, see manpage
    void image_3d_gl( GLenum target, GLint level, GLint internalformat, 
        GLsizei width, GLsizei height, GLsizei depth, GLint border, 
        GLenum format, GLenum type, const GLvoid* pixels );


    /** 
    *   sub_image_*d* functions 
    *   -> replace part of texture image with new data (specify sub-image)
    * 
    *   reordered parameters to most-used pattern and specified some reasonable 
    *   defaults, otherwise the same as the sub_image_*d_gl functions.
    */

    void sub_image( texture_data& data, GLint xoffset = 0, GLint yoffset = 0, 
        GLint zoffset = 0, GLint level = 0 );
    
    // user-friendly version. for parameters, see glTexImage1D manpage
    void sub_image_1d( 
        const GLvoid* pixels,   // buffer with pixel data
        GLsizei width,
        GLint xoffset           = 0,                // offset into the texture
        GLenum target           = GL_TEXTURE_1D,    // texture target
        GLenum source_format    = GL_RGBA,          // source data format
        GLenum source_datatype  = GL_UNSIGNED_BYTE, // source data type
        GLint level             = 0 // mipmap level of detail number
    );
    
    // 'original' version. replicates glTexImage1D parameters, see manpage
    void sub_image_1d_gl( GLenum target, GLint level, GLint xoffset, 
        GLsizei width, GLenum format, GLenum type, const GLvoid* pixels );
    
    
    // user-friendly version. for parameters, see glTexImage2D manpage
    void sub_image_2d( 
        const GLvoid* pixels,   // buffer with pixel data
        GLsizei width, 
        GLsizei height, 
        GLint xoffset           = 0,                // offset into the texture
        GLint yoffset           = 0,                // offset into the texture
        GLenum target           = GL_TEXTURE_2D,    // texture target
        GLenum source_format    = GL_RGBA,          // source data format
        GLenum source_datatype  = GL_UNSIGNED_BYTE, // source data type
        GLint level             = 0 // mipmap level of detail number
    );

    // 'original' version. replicates glTexImage2D parameters, see manpage
    void sub_image_2d_gl( GLenum target, GLint level, GLint xoffset, 
        GLint yoffset, GLsizei width, GLsizei height, GLenum format, 
        GLenum type, const GLvoid* pixels );

    // user-friendly version. for parameters, see glTexImage3D manpage
    void sub_image_3d( 
        const GLvoid* pixels, // buffer with pixel data ( or 0 )
        GLsizei width, 
        GLsizei height,  
        GLsizei depth,
        GLint xoffset           = 0,                // offset into the texture
        GLint yoffset           = 0,                // offset into the texture
        GLint zoffset           = 0,                // offset into the texture
        GLenum target           = GL_TEXTURE_3D,    // texture target
        GLenum source_format    = GL_RGBA,          // source data format
        GLenum source_datatype  = GL_UNSIGNED_BYTE, // source data type
        GLint level             = 0 // mipmap level of detail number
    );

    // 'original' version. replicates glTexImage3D parameters, see manpage
    void sub_image_3d_gl( GLenum target, GLint level, GLint xoffset,
        GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, 
        GLsizei depth, GLenum format, GLenum type, const GLvoid* pixels );
    
    
    // this function exists to use the texture class with already 
    // created textures ( useful when refactoring old code or so )
    void set( GLenum target, GLuint name, GLuint internal_format = 0, 
        GLuint width = 0, GLuint height = 0, GLuint depth = 0 );
    
    inline GLuint get_name();
    inline GLenum get_target();
    inline GLuint get_width();
    inline GLuint get_height();
    inline GLenum get_format();

    // convenience ( nearest, clamp )
    void set_float_texture_param_defaults();
    // convenience ( linear, repeat )
    void set_texture_param_defaults();

protected:
    GLuint _name;
    GLenum _target;
    GLuint _width;
    GLuint _height;
    GLuint _depth;
    GLenum _format;
};



inline void 
texture::bind()
{ 
    glBindTexture( _target, _name ); 
	check_for_gl_error( true, "binding texture " );
}


inline void 
texture::unbind() 
{ 
    glBindTexture( _target, 0 ); 
}    



inline void 
texture::enable()
{ 
    glEnable( _target ); 
}


inline void 
texture::disable() 
{ 
    glDisable( _target ); 
}    



inline GLenum 
texture::get_target()
{
    return _target;
}



inline GLuint 
texture::get_name()
{
    return _name;
}



inline GLuint 
texture::get_width()
{
    return _width;
}



inline GLuint 
texture::get_height()
{
    return _height;
}



inline GLenum 
texture::get_format()
{
    return _format;
}


}; //namespace opengl_utils

#endif

