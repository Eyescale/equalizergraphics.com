#ifndef __GLOO__GLUT_FPS_CONTROL__H__
#define __GLOO__GLUT_FPS_CONTROL__H__

#include <gloo/fps_control.hpp>
#include <gloo/glut_callback_targets.hpp>

#include <gloo/glut_input.hpp>

namespace gloo
{

struct glut_fps_control 
    : public fps_control
    , public mouse_target
    , public key_target
{
    glut_fps_control( const vec3f& eye, const vec3f& look, 
        const vec3f& up ) 
        : fps_control( eye, look, up )
        , old_mouse_position( 0, 0 )
        , mouse_look_enabled( true )
    {
        glut_input::set_key_target( 'w', this );
        glut_input::set_key_target( 'a', this );
        glut_input::set_key_target( 's', this );
        glut_input::set_key_target( 'd', this );
        glut_input::set_key_target( 'q', this );
        glut_input::set_key_target( 'e', this );
        glut_input::set_key_target( 'r', this );
        glut_input::set_key_target( 'f', this );
        glut_input::add_mouse_target( this );
    }
    
    virtual void mouse_update( const mouse_state& mouse_state_ )
    {
        if ( mouse_look_enabled )
        {
            _mouse_diff = mouse_state_.diff;
            _mouse_diff.y = -_mouse_diff.y;
        }
        
        if ( mouse_state_.buttons[ 0 ] == 1 )
        {
            mouse_look_enabled = true;
        }
        else 
        {
            mouse_look_enabled = false;
        }
    };
    
    virtual void on_key_down( unsigned char key ) 
    {
        switch( key )
        {
            case 'w':
                move_forward();
                break;
            case 'a':
                strafe_left();
                break;
            case 's':
                move_backward();
                break;
            case 'd':
                strafe_right();
                break;
            case 'q':
                turn_left();
                break;
            case 'e':
                turn_right();
                break;
            case 'r':
                move_up();
                break;
            case 'f':
                move_down();
                break;
            default:
                break;
        }
    };
    
    vec2i old_mouse_position;
    bool mouse_look_enabled;

}; // struct glut_fps_control


} //namespace gloo

#endif
