#ifndef __GLOO__GLUT_CALLBACK_TARGETS__H__
#define __GLOO__GLUT_CALLBACK_TARGETS__H__

#include <gloo/opengl_includes.hpp>
#include <gloo/vmmlib_includes.hpp>
#include <gloo/fps_control.hpp>

#include <gloo/render_target.hpp>
#include <gloo/key_target.hpp>
#include <gloo/mouse_target.hpp>
#include <gloo/reshape_target.hpp>
#include <gloo/idle_target.hpp>

namespace gloo
{

// convenience implementations

struct simple_mouse_target : public mouse_target
{
    simple_mouse_target() 
        : old_mouse_position( 0, 0 )
        , mouse_diff( 0, 0 )
    {}
    
    virtual void on_mouse_button( int button, int state, int x, int y )
    {
        if ( button == GLUT_LEFT_BUTTON )
        {
            old_mouse_position.set( x, y );
        }
    };
    
    virtual void on_mouse_dragged( int x, int y )
    {
        vec2i new_pos( x, y );
        mouse_diff = new_pos - old_mouse_position;
        old_mouse_position = new_pos;
    };
    
    vec2i old_mouse_position;
    vec2i mouse_diff;

};



} // namespace gloo

#endif
