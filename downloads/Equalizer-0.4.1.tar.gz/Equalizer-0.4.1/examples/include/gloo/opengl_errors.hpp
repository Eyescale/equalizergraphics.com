#ifndef __GLOO__OPEN_GL_ERRORS__H__
#define __GLOO__OPEN_GL_ERRORS__H__

#include <gloo/opengl_includes.hpp>
#include <gloo/exception.hpp>

#include <iostream>
#include <string>
#include <cassert>

namespace gloo
{

class opengl_error_exception : public exception
{
public: 
    opengl_error_exception( const std::string& desc, GLenum gl_error_, 
        except_here here )
    : exception( desc, here )
    {
        _desc += "\n";
        _desc += "error: ";
        _desc += (const char*) gluErrorString( gl_error_ );
        _desc += "\n";
    }

}; // class opengl_error_exception



static void check_for_gl_error( const std::string situation, except_here here )
{
	GLenum err = glGetError();
	if ( err == GL_NO_ERROR ) 
		return;
    throw opengl_error_exception( situation, err, here );
}


// adapter so the old code still works
// TODO update all glerror checks to new version
static bool check_for_gl_error( bool exitOnError = false, 
    const std::string& situation = "" )
{
	GLenum err = glGetError();
	if ( err == GL_NO_ERROR ) 
		return false;

    throw opengl_error_exception( situation, err, GLOO_HERE );
	return true;
};

}; //namespace gloo

#endif

