#ifndef __GLOO__GLUT_INPUT__H__
#define __GLOO__GLUT_INPUT__H__

#include <gloo/opengl_includes.hpp>
#include <gloo/vmmlib_includes.hpp>
#include <gloo/glut_callback_targets.hpp>

#include <vector>
#include <list>

namespace gloo
{

// TODO respect modifier keys
class glut_input
{
public:
    glut_input();

    void update_targets();
    static void set_key_target( unsigned char key, key_target* target ); 
    static void add_mouse_target( mouse_target* target ); 

protected:
    void _update_mouse_targets();

    static glut_input* _instance;
    static void _on_key( unsigned char key, int x, int y );
    static void _on_key_up( unsigned char key, int x, int y );
    static void _on_mouse_button( int button, int state, int x, int y );
    static void _on_mouse_dragged( int x, int y );

    void _on_mouse_button_impl( int button, int state, int x, int y );
    void _on_mouse_dragged_impl( int x, int y );
    
    std::vector< ssize_t > _keys_down;
    std::vector< key_target* > _key_targets;
    std::list< mouse_target* > _mouse_targets;
    
    mouse_state _mouse_state;
    vec2i _old_mouse_position;
    

}; // class glut_input

};//namespace gloo

#endif
