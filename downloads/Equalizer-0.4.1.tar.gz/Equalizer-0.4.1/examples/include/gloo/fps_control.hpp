#ifndef __GLOO__FPS_CONTROL__H__
#define __GLOO__FPS_CONTROL__H__

#include <gloo/vmmlib_includes.hpp>

/**
*
* @brief a class that allows first-person-shooter-like movement 
* ( think quake )
*
* @author jonas boesch
*/

namespace gloo
{

enum FPS_CONTROL_MODE
{
    FPS_WALK    = 1,
    FPS_FLY     = 2
};


class fps_control
{
public:
    fps_control( const vec3f& eye_, const vec3f& look_, 
        const vec3f& up_ = vec3f( 0.0, 1.0, 0.0 ) );
    
    fps_control( const vec3f& up_ );
    
    template< typename T >
    inline vmml::Matrix4< T > compute_matrix();

    template< typename T >
    inline void compute_matrix( vmml::Matrix4< T >& mv );

    template< typename T >
    void compute_matrix( vmml::Matrix4< T >& mv, vec2i& mouse_diff_ );
    
    inline void strafe_left();
    inline void strafe_right();
    inline void turn_left();
    inline void turn_right();
    void turn( float angle_in_radians );

    inline void move_forward();
    inline void move_backward();
    inline void move_up();
    inline void move_down();
    
    inline void     set_step_size( float step_size );
    inline float    get_step_size() const;
    
    inline void         set_eye_position( const vec3f& step_size );
    inline const vec3f& get_eye_position() const;
    inline void         set_look( const vec3f& step_size );
    inline const vec3f& get_look() const;
    inline void         set_up( const vec3f& step_size );
    inline const vec3f& get_up() const;
    inline void         set_right( const vec3f& step_size );
    inline const vec3f& get_right() const;
    
    inline const vec2i& get_mouse_diff() const;
    inline void         set_mouse_diff( const vec2i& mouse_diff );

protected:
    vec3f _eye_position;
    vec3f _look;
    vec3f _up;
    vec3f _right;
    
    float _step_size;

    vec2i _mouse_diff;
    
    FPS_CONTROL_MODE _control_mode;
    
}; // class fps_control



template< typename T >
inline vmml::Matrix4< T > 
fps_control::compute_matrix()
{
    vmml::Matrix4< T > mat;
    compute_matrix( mat );
    return mat;
}


template< typename T >
inline void
fps_control::compute_matrix( vmml::Matrix4< T >& mv )
{
    compute_matrix( mv, _mouse_diff );
}



template< typename T >
void
fps_control::compute_matrix( vmml::Matrix4< T >& mv, vec2i& mouse_diff_ )
{
    _look.normalize();

    // pi / 180.0
    //#define M_PI_DIV_BY_180 0.017453292519943295
    // 1/3 * ( pi / 180 )
    #define MUL_FACTOR 0.0058177641733144318
    // compute the right vector
    _right.cross( _look, _up );
    _right.normalize();

    if( mouse_diff_.x != 0 )
    {
        mat4d rot;
        rot.rotate( - mouse_diff_.x  * MUL_FACTOR, _up );
        _look = rot * _look;
    }
    
    if( mouse_diff_.y != 0 )
    {
        mat4d rot;
        rot.rotate( mouse_diff_.y * MUL_FACTOR, _right );
        _look = rot * _look;
    }

    mouse_diff_ = 0;

    _look.normalise();

    vec3f u( _up );
    u.cross( _right, _look );
    u.normalize();
    
    // fps control matrix
    // right.x  right.y right.z -dot(right,eye)
    // up.x     up.y    up.z    -dot(up,eye)
    // -look.x  -look.y -look.z dot(look,eye)
    // 0        0       0       1.0
            
    mv.set( 
       _right.x, _right.y, _right.z, -vec3f::dot( _right, _eye_position ),
       u.x,      u.y,      u.z,      -vec3f::dot( u,      _eye_position ),  
       -_look.x, -_look.y, -_look.z,  vec3f::dot( _look,  _eye_position ),  
       0, 0, 0, 1.0 );

       
}


inline void 
fps_control::strafe_left()
{
    _eye_position -= _right * _step_size;
}



inline void 
fps_control::strafe_right()
{        
    _eye_position += _right * _step_size;
}



inline void 
fps_control::move_forward()
{
    _eye_position += _look * _step_size;        
}



inline void 
fps_control::move_backward()
{
    _eye_position -= _look * _step_size;        
}



inline void 
fps_control::move_up()
{
    _eye_position += _up * _step_size;        
}



inline void 
fps_control::move_down()
{
    _eye_position -= _up * _step_size;        
}



inline void 
fps_control::turn_left()
{
    // two degrees in radians
    turn( -0.034906585039886591 );
}



inline void 
fps_control::turn_right()
{        
    // two degrees in radians
    turn( 0.034906585039886591 );
}



inline void
fps_control::set_eye_position( const vec3f& eye )
{
    _eye_position = eye;
}



inline const vec3f&
fps_control::get_eye_position() const
{
    return _eye_position;
}



inline void
fps_control::set_look( const vec3f& look_ )
{
    _look = look_;
}



inline const vec3f&
fps_control::get_look() const
{
    return _look;
}



inline void
fps_control::set_up( const vec3f& up_ )
{
    _up = up_;
}



inline const vec3f&
fps_control::get_up() const
{
    return _up;
}



inline void
fps_control::set_right( const vec3f& right_ )
{
    _right = right_;
}



inline const vec3f&
fps_control::get_right() const
{
    return _right;
}



inline void
fps_control::set_step_size( float step_size )
{
    _step_size = step_size;
}



inline float
fps_control::get_step_size() const
{
    return _step_size;
}



inline const vec2i&
fps_control::get_mouse_diff() const
{
    return _mouse_diff;
}



inline void
fps_control::set_mouse_diff( const vec2i& mouse_diff )
{
    _mouse_diff = mouse_diff;
}


} // namespace gloo

#endif
