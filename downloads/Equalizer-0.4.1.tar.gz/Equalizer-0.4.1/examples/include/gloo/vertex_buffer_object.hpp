#ifndef __GLOO__VERTEX_BUFFER_OBJECT__H__
#define __GLOO__VERTEX_BUFFER_OBJECT__H__

#include <gloo/opengl_includes.hpp>

/*
 *  @brief A lightweight wrapper for opengl vertex buffer objects ( vbos )
 *
 *  @author jonas boesch
 *
 */

namespace gloo
{

class vertex_buffer_object
{
public: 
	vertex_buffer_object();
	~vertex_buffer_object();
	
    /*
    * target - GL_ARRAY_BUFFER or GL_ELEMENT_ARRAY_BUFFER 
    * size - buffer size in bytes
    * data - ptr to data
    * usage ( text from gl spec ) 
    GL_STREAM_DRAW The data store contents will be specified once by the
        application, and used at most a fewtimes as the source of a GL 
        (drawing) command.
    GL_STREAM_READ The data store contents will be specified once by reading 
        data from the GL, and queried at most a few times by the application.
    GL_STREAM_COPY The data store contents will be specified once by reading 
        data from the GL, and used at most a few times as the source of a 
        GL (drawing) command.
    GL_STATIC_DRAW The data store contents will be specified once by the 
        application, and used many times as the source for GL (drawing) commands.
    GL_STATIC_READ The data store contents will be specified once by reading 
        data from the GL, and queried many times by the application. 
    GL_STATIC_COPY The data store contents will be specified once by reading 
        data from the GL, and used many times as the source for GL (drawing) 
        commands.
    GL_DYNAMIC_DRAW The data store contents will be respecified repeatedly by 
        the application, and used many times as the source for GL (drawing) 
        commands.
    GL_DYNAMIC_READ The data store contents will be respecified repeatedly by 
        reading data from the GL, and queried many times by the application.
    GL_DYNAMIC_COPY The data store contents will be respecified repeatedly by 
        reading data from the GL, and used many times as the source for GL 
        (drawing) commands.
    */          
	void create( GLenum target, GLsizeiptr size, const GLvoid* data, 
        GLenum usage );
	
    // destroys the vbo ( using it again requires re-create()-ing it) 
	void destroy();
	
	inline void bind();
	inline void unbind();
    
	inline void enable();
	inline void disable();
    
    // overwrite the whole buffer with new data
	inline void write( GLsizeiptr size, const GLvoid* data );
    // overwrite part of the buffer with new data
	inline void write_range( GLintptr offset, GLsizeiptr size, const GLvoid* data );

	// map the data ( get a writeable pointer to the data )
    // access flags: GL_READ_ONLY, GL_WRITE_ONLY, GL_READ_WRITE  
	inline void* map( GLenum access = GL_READ_WRITE );
	inline void unmap();

	// signal gl to discard the data currently in the vbo 
	inline void discard();

    inline GLuint get_name() const;
    inline GLenum get_target() const;
    inline GLuint get_size() const;
    inline GLenum get_usage_hint() const;
    
    // set up this vbo to be used as vertex source
    inline void vertex_pointer( GLint size = 3, GLenum type = GL_FLOAT, 
        GLsizei stride = 0, const GLvoid* offset_in_bytes = 0 );
    // set up this vbo to be used as vertex source
    inline void use_as_vertex_source( GLint size = 3, GLenum type = GL_FLOAT, 
        GLsizei stride = 0, const GLvoid* offset_in_bytes = 0 );
    
    // set up this vbo to be used as normal source
    inline void normal_pointer( GLenum type = GL_FLOAT, GLsizei stride = 0,
        const GLvoid* offset_in_bytes = 0 );
    // set up this vbo to be used as normal source
    inline void use_as_normal_source( GLenum type = GL_FLOAT, GLsizei stride = 0,
        const GLvoid* offset_in_bytes = 0 );
    
    // set up this vbo to be used as color source 
    inline void color_pointer( GLint size = 4, GLenum type = GL_UNSIGNED_BYTE, 
        GLsizei stride = 0, const GLvoid* offset_in_bytes = 0 );
    // set up this vbo to be used as color source
    inline void use_as_color_source( GLint size = 4, GLenum type = GL_UNSIGNED_BYTE, 
        GLsizei stride = 0, const GLvoid* offset_in_bytes = 0 );
        
    // set up this vbo to be used as secondary color source
    inline void secondary_color_pointer( GLint size = 4, 
        GLenum type = GL_UNSIGNED_BYTE, GLsizei stride = 0, 
        const GLvoid* offset_in_bytes = 0 );
    // set up this vbo to be used as secondary color source
    inline void use_as_secondary_color_source( GLint size = 4, 
        GLenum type = GL_UNSIGNED_BYTE, GLsizei stride = 0, 
        const GLvoid* offset_in_bytes = 0 );
    
    // set up this vbo to be used as tex coord pointer source
    inline void tex_coord_pointer( GLint size = 2, GLenum type = GL_FLOAT, 
        GLsizei stride = 0, const GLvoid* offset_in_bytes = 0 );
    // set up this vbo to be used as tex coord pointer source
    inline void use_as_tex_coord_source( GLint size = 2, GLenum type = GL_FLOAT, 
        GLsizei stride = 0, const GLvoid* offset_in_bytes = 0 );
    	
protected:	
	GLuint _name;
	GLenum _target;
	GLuint _size;
	GLenum _usage;
    
    GLenum _ptr_target;
	
};


//
// implementation of inline functions
//

inline void 
vertex_buffer_object::bind() 
{ 
    glBindBuffer( _target, _name ); 
}



inline void 
vertex_buffer_object::unbind() 
{ 
    glBindBuffer( _target, 0 ); 
}



inline void 
vertex_buffer_object::enable() 
{ 
    glEnableClientState( _target ); 
}



inline void 
vertex_buffer_object::disable()
{
    glDisableClientState( _target ); 
}


inline GLuint 
vertex_buffer_object::get_name() const
{
    return _name;
}



inline GLenum 
vertex_buffer_object::get_target() const
{
    return _target;
}



inline GLuint 
vertex_buffer_object::get_size() const
{
    return _size;
}



inline GLenum 
vertex_buffer_object::get_usage_hint() const
{
    return _usage;
}


inline void 
vertex_buffer_object::write( GLsizeiptr size, const GLvoid* data )
{
	glBindBuffer( _target, _name );
	glBufferData( _target, _size, data, _usage );
}



inline void 
vertex_buffer_object::write_range( GLintptr offset, GLsizeiptr size, 
    const GLvoid* data )
{
	glBindBuffer( _target, _name );
	glBufferSubData( _target, offset, size, data );
}



inline void
vertex_buffer_object::discard()
{
	glBindBuffer( _target, _name );
	glBufferData( _target, _size, 0, _usage );
}



inline void* 
vertex_buffer_object::map( GLenum access )
{
	glBindBuffer( _target, _name );
	return glMapBuffer( _target, access );
}



inline void 
vertex_buffer_object::unmap()
{
	glUnmapBuffer( _target );
}



inline void 
vertex_buffer_object::vertex_pointer( GLint size, GLenum type, 
    GLsizei stride, const GLvoid* offset_in_bytes )
{
    glBindBuffer( _target, _name );
    glVertexPointer( size, type, stride, offset_in_bytes );
    glEnableClientState( _ptr_target = GL_VERTEX_ARRAY );
}



inline void 
vertex_buffer_object::use_as_vertex_source( GLint size, GLenum type, 
    GLsizei stride, const GLvoid* offset_in_bytes )
{
    vertex_pointer( size, type, stride, offset_in_bytes );
}



inline void 
vertex_buffer_object::normal_pointer( GLenum type, GLsizei stride, 
    const GLvoid* offset_in_bytes )
{
    glBindBuffer( _target, _name );
    glNormalPointer( type, stride, offset_in_bytes );
    glEnableClientState( _ptr_target = GL_NORMAL_ARRAY );
}



inline void 
vertex_buffer_object::use_as_normal_source( GLenum type, GLsizei stride, 
    const GLvoid* offset_in_bytes )
{
    normal_pointer( type, stride, offset_in_bytes );
}



inline void 
vertex_buffer_object::color_pointer( GLint size, GLenum type, 
    GLsizei stride, const GLvoid* offset_in_bytes )
{
    glBindBuffer( _target, _name );
    glColorPointer( size, type, stride, offset_in_bytes );
    glEnableClientState( _ptr_target = GL_COLOR_ARRAY );
}



inline void 
vertex_buffer_object::use_as_color_source( GLint size, GLenum type, 
    GLsizei stride, const GLvoid* offset_in_bytes )
{
    color_pointer( size, type, stride, offset_in_bytes );
}



inline void 
vertex_buffer_object::secondary_color_pointer( GLint size, GLenum type, 
    GLsizei stride, const GLvoid* offset_in_bytes )
{
    glBindBuffer( _target, _name );
    glSecondaryColorPointer( size, type, stride, offset_in_bytes );
    glEnableClientState( _ptr_target = GL_SECONDARY_COLOR_ARRAY );
}



inline void 
vertex_buffer_object::use_as_secondary_color_source( GLint size, GLenum type, 
    GLsizei stride, const GLvoid* offset_in_bytes )
{
    secondary_color_pointer( size, type, stride, offset_in_bytes );
}



inline void 
vertex_buffer_object::tex_coord_pointer( GLint size, GLenum type, 
    GLsizei stride, const GLvoid* offset_in_bytes )
{
    glBindBuffer( _target, _name );
    glTexCoordPointer( size, type, stride, offset_in_bytes );
    glEnableClientState( _ptr_target = GL_TEXTURE_COORD_ARRAY );
}



inline void 
vertex_buffer_object::use_as_tex_coord_source( GLint size, GLenum type, 
    GLsizei stride, const GLvoid* offset_in_bytes )
{
    tex_coord_pointer( size, type, stride, offset_in_bytes );
}


} //namespace gloo

#endif

