#ifndef __GLOO__FRAME_BUFFER_OBJECT__H__
#define __GLOO__FRAME_BUFFER_OBJECT__H__

#include <gloo/opengl_includes.hpp>
#include <gloo/opengl_errors.hpp>
#include <gloo/texture.hpp>
#include <gloo/exception.hpp>


#include <string>

/*
 *  @brief A lightweight wrapper for opengl frame buffer objects ( fbos )
 *
 *  @author jonas boesch
 *
 */
namespace gloo
{

class fbo_error_exception : public opengl_error_exception
{
public: 
    fbo_error_exception( std::string desc, except_here here )
    : opengl_error_exception( desc, glGetError(), here )
    {
        _desc += "framebuffer error.\n";
    }
    
}; // class fbo_error_exception


class frame_buffer_object
{
public:
	frame_buffer_object();
	~frame_buffer_object();

    void bind_to_texture_2d( texture& tex, 
        GLenum target = GL_COLOR_ATTACHMENT0_EXT );
    
    inline void bind();
    static inline void unbind();

    inline GLuint get_name() const;
    inline texture& get_texture() const;

    // forwards to texture->...
    inline GLuint get_width() const;
    inline GLuint get_height() const;

    // status checks, might not be supported...
    inline GLenum get_fbo_status();
    inline bool fbo_status_ok();
	void print_fbo_status();
    
    void write_colors_to_file( const std::string& fileName );
    void write_colors_to_text_file( const std::string& fileName );
    void write_depth_to_file( const std::string& fileName );
    
protected:
	GLuint _name;
    GLenum _target;
    texture* _texture;

};



inline void 
frame_buffer_object::bind()
{
    glBindFramebufferEXT( GL_FRAMEBUFFER_EXT, _name );
}


inline void 
frame_buffer_object::unbind()
{
    glBindFramebufferEXT( GL_FRAMEBUFFER_EXT, 0 );
}



inline GLuint 
frame_buffer_object::get_name() const
{
    return _name;
}



inline GLuint 
frame_buffer_object::get_width() const
{
    return ( _texture ) ? _texture->get_width() : 0;
}



inline GLuint 
frame_buffer_object::get_height() const
{
    return ( _texture ) ? _texture->get_height() : 0;
}



inline 
texture& 
frame_buffer_object::get_texture() const
{
    return *_texture;
}



inline GLenum
frame_buffer_object::get_fbo_status()
{
    return glCheckFramebufferStatusEXT( GL_FRAMEBUFFER_EXT );
}



inline bool
frame_buffer_object::fbo_status_ok()
{
    return ( glCheckFramebufferStatusEXT( GL_FRAMEBUFFER_EXT ) 
        == GL_FRAMEBUFFER_COMPLETE_EXT );
}


} // namespace gloo

#endif

