#ifndef __GLOO__GLSL_PROGRAM__H__
#define __GLOO__GLSL_PROGRAM__H__

#include <gloo/vmmlib_includes.hpp>
#include <gloo/texture.hpp>

#include <gloo/glsl_uniform.hpp>

#include <list>
#include <vector>
#include <string>
#include <map> 

/*
 * @brief A simple wrapper for glsl shaders 
 * 
 * GLSLProgram simplifies the use of glsl shaders by hiding most of the
 * OpenGL shader-related ugliness. Main use is probably loading a shader
 * in two function calls, and dealing with a single object instead of all
 * the OpenGL ids.
 *
 * Usage: 
 * 1. create instance of glsl_program class 
 * 2. for_each shader call add_source_from_string or add_source_from_file() 
 * 3. call create()
 * opt: 4. use ::bind() to activate *this program if multiple programs are used.
 * 5. happily live ever after :)
 *
 * @author jonas boesch
 *
 */
namespace gloo
{

class glsl_program
{
public: 
    glsl_program();
    ~glsl_program();
    
    GLuint add_source_from_file( GLenum type, const std::string& filename );
	GLuint add_source_from_string( GLenum type, const char* source );

    // compiles all sources and readies the program for use
	GLuint create();
    // deletes all shaders, uniforms and the program
	void destroy();
    
    void reset();

    // returns the gl name / id of the program
	GLuint get_name(); 

	inline void enable();
	inline void disable();
	inline void bind();
	inline void unbind();

    // howto: get uniform for sampler using getUniform, then 
    // setTextureUnit with sampler and texture
    // important: texture units have to be set in descending order,
    // e.g. 3,2,1,0
	void set_texture_unit( GLuint unit, glsl_uniform& sampler, 
        texture& texture );

    /** 
    *   uniforms
    *   
    *   use glsl_uniform as class if using the uniform for a dynamic
    *   (often changing) variable. Then, just use the operator= to assign the
    *   new value ( -> behaves like any 'normal' c++ variable ).
    */
    
    // creates a new uniform object and returns the reference
    glsl_uniform& get_uniform( const std::string& name );
 
    // uses an externally allocated uniform object
    void setup_uniform( glsl_uniform& uniform_, const std::string& name );

    // use setUniformxf if using the uniform for a static ( constant ) value.
    void set_uniform_1f( const std::string& name, float value );
    
protected:
    void _compile_shaders();

    // debug output 
    void print_shader_log( GLuint obj );
    size_t print_shader_log2( GLhandleARB shader );
    void print_program_log( GLuint obj );
    
    size_t _read_file( const std::string& fileName );
    

    GLuint _program;
    bool _linked;
    
    std::map< GLenum, std::list< GLuint > >_shaders;
    
    std::list< GLuint > _vertex_shaders;
    std::list< GLuint > _fragment_shaders;
    
    std::map< std::string, glsl_uniform* > _uniforms;

    std::map< GLuint, std::string > _shader_files;
    
    // store all active shaders in memory
    // TODO make configable
    std::vector< char* > _sources;
};



inline void 
glsl_program::enable()
{
	glUseProgram( _program );
}



inline void 
glsl_program::disable()
{
	glUseProgram( 0 );
}


inline void 
glsl_program::bind()
{
	glUseProgram( _program );
}



inline void 
glsl_program::unbind()
{
	glUseProgram( 0 );
}


} //namespace gloo

#endif

