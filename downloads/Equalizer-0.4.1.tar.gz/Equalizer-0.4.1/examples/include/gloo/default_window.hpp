#ifndef __GLOO__DEFAULT_WINDOW__H__
#define __GLOO__DEFAULT_WINDOW__H__

#include <gloo/glut_window.hpp>
#include <gloo/glut_callback_targets.hpp>

#include <gloo/camera.hpp>
#include <gloo/glut_fps_control.hpp>

namespace gloo
{

/**
*  @brief default window provides a glut window with some reasonable defaults
*  such as mouse and w,a,s,d keyboard controls for moving in the world.
*  Just inherit from it at put all render code into the _draw_scene()-function.
*/

class default_window : public render_target, public idle_target
{
public:
    default_window( const std::string& window_title, 
        size_t height = 512, size_t width = 512 );
    
    virtual void draw();
    
    void start(); // starts glut mainloop
    virtual void on_idle();

protected:
    virtual void _draw_scene();

    glut_window             _window;
    camera                  _camera;

    glut_fps_control        _fps_control;
    
};

} // namespace gloo

#endif
