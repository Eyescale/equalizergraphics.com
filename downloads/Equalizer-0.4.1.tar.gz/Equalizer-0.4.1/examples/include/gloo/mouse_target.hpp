#ifndef __GLOO__MOUSE_TARGET__H__
#define __GLOO__MOUSE_TARGET__H__

#include <gloo/vmmlib_includes.hpp>

namespace gloo
{

struct mouse_state
{
    mouse_state()
        : position( 0, 0 )
        , diff( 0, 0 )
        , buttons( 0, 0, 0 )
    {}
    
    vec2i position;
    vec2i diff;
    vec3i buttons; // 0 - left, 1 - right, 2 - middle

}; // struct mouse_state


class mouse_target
{
public:
    virtual void mouse_update( const mouse_state& mouse_state_ ) = 0;

}; // class mouse_target

} // namespace gloo

#endif

