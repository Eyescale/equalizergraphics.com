#ifndef __GLOO__PIXEL_BUFFER_OBJECT__H__
#define __GLOO__PIXEL_BUFFER_OBJECT__H__

#include <gloo/opengl_includes.hpp>
#include <gloo/texture.hpp>
#include <gloo/texture_data.hpp>

namespace gloo
{

/**
* @brief wrapper class for pixel_buffer_object
* see http://www.opengl.org/registry/specs/ARB/pixel_buffer_object.txt
*
* @author jonas boesch
*/

class pixel_buffer_object
{

public:
	pixel_buffer_object();
	~pixel_buffer_object();
	
	// Streaming Textures: use GL_STREAM_DRAW usage hint 
	// Render to Vertex Array: use GL_DYNAMIC_DRAW usage hint

	// general create function
    void create( GLuint width, GLuint height, size_t size_in_bytes, 
        GLenum usage_hint = GL_STREAM_COPY );

    // this create function uses the defaults for texture streaming
    void create( texture& tex, size_t pixel_size_in_bytes );
    
	void read_back( GLenum buffer, GLuint width, GLuint height );

	// use only for debugging -> slooooow 
	void read_back_to_main_memory( GLenum pBuffer, GLuint width = 32, GLuint height = 1);
	
	void stream_to_texture( texture& texture_, texture_data& data_ );


    inline GLuint get_name() const;
    inline GLuint get_size_in_bytes() const;
    inline GLuint get_width() const;
    inline GLuint get_height() const;
    inline GLuint get_usage_hint() const;

protected:
	GLuint _name;
	GLuint _size_in_bytes;
	GLuint _width;
	GLuint _height;
    GLenum _usage_hint;


}; // class pixel_buffer_object



inline GLuint 
pixel_buffer_object::get_name() const
{
    return _name;
}



inline GLuint 
pixel_buffer_object::get_size_in_bytes() const
{
    return _size_in_bytes;
}



inline GLuint 
pixel_buffer_object::get_width() const
{
    return _width;
}



inline GLuint 
pixel_buffer_object::get_height() const
{
    return _height;
}



inline GLenum 
pixel_buffer_object::get_usage_hint() const
{
    return _usage_hint;
}


} // namespace gloo

#endif

