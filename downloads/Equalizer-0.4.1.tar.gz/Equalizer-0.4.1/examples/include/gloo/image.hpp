#ifndef __GLOO__IMAGE__H__
#define __GLOO__IMAGE__H__

#include <gloo/opengl_includes.hpp>

#include <vector>

namespace gloo
{

template< typename T >
struct image_data
{

image_data() : width( 0 ), height( 0 ) {};

std::vector< T > pixels;

size_t width;
size_t height;
GLenum format;

}; // struct image_data


struct image : public image_data< unsigned char >
{}; // struct image

struct float_image : public image_data< float >
{}; // struct float_image

} // namespace gloo

#endif

