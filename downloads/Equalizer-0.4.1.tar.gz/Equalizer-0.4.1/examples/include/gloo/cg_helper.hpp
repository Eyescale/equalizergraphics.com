#ifndef __GLOO__CG_HELPER__HPP__
#define __GLOO__CG_HELPER__HPP__

#include <Cg/cg.h>
#include <Cg/cgGL.h>

#include <map>
#include <string>

namespace gloo
{

class cg_helper
{
public:
    static cg_helper& get_singleton();
    static cg_helper* get_singleton_ptr();
    ~cg_helper();

    static const std::string& get_profile_name( CGprofile profile );

protected:
    static cg_helper* _instance;
    const std::string _unknown_profile;
    
    void _init_map();
    std::map< CGprofile, std::string > _profile_names;

private:
    cg_helper();
    
}; // class cg_helper

} // namespace gloo

#endif

