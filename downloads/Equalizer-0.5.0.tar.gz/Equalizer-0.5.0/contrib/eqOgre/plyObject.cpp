
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#include "plyObject.h"
#include <stdio.h>
#include <assert.h>
#include <iostream>
#include <math.h>
#include <fstream>

using namespace ply;

Object::Object()
{
	_faces = NULL;
	vertices = NULL;

    nVertices = 0;
}

Object::~Object()
{
	if (_faces != NULL)
	{
		free(_faces);
		_faces = NULL;
	}

	if (vertices != NULL)
	{
		free(vertices);
		vertices = NULL;
	}
}

bool Object::readFile (const char *filename)
{
	std::string binFile;
	binFile.assign(filename);
	binFile.append(".og32");

	if (readBin(binFile.data()))
		return true;
	else if (readPly(filename))
	{
		writeBin(binFile.data());
		return true;
	}

	return false;
}

bool Object::readBin (const char *filename)
{
	std::ifstream inStream;
	
	inStream.open(filename, std::ios_base::binary);

	if (inStream.fail())
		return false;

	int version	= 1;

	inStream.read((char *)&version, sizeof(int));
	inStream.read((char *)&_nface,  sizeof(int));
	inStream.read((char *)&nVertices, sizeof(int));

	inStream.read((char *)&m_BBoxMin, sizeof(rt::Vector3));
	inStream.read((char *)&m_BBoxMax, sizeof(rt::Vector3));
	inStream.read((char *)&m_fBBoxSize, sizeof(rtFloat));

	_faces = (Face*) malloc(sizeof(Face) * _nface);
	vertices = (Vertex*) malloc(sizeof(Vertex) * nVertices);

	inStream.read((char *)_faces,  sizeof(Face) * _nface);
	inStream.read((char *)vertices,  sizeof(Vertex) * nVertices);

	inStream.close();

	return true;
}

void Object::writeBin (const char *filename)
{
	std::ofstream outStream(filename, std::ios_base::binary);

	int version;

	outStream.write((char *)&version, sizeof(int));
	outStream.write((char *)&_nface,  sizeof(int));
	outStream.write((char *)&nVertices, sizeof(int));

	outStream.write((char *)&m_BBoxMin, sizeof(rt::Vector3));
	outStream.write((char *)&m_BBoxMax, sizeof(rt::Vector3));
	outStream.write((char *)&m_fBBoxSize, sizeof(rtFloat));

	outStream.write((char *)_faces,  sizeof(Face) * _nface);
	outStream.write((char *)vertices,  sizeof(Vertex) * nVertices);

	outStream.close();
}

bool Object::readPly( const char *filename )
{
    int       nElems;
    char    **elemNames;
    int       fileType;
    float     version;

    PlyFile *file = ply_open_for_reading( (char *)filename, 
											&nElems, 
											&elemNames,
											&fileType, 
											&version );

	m_strName.assign(filename);

	std::cout << "\n"
			  << "file name is "		<< filename << "\n"
			  << "element number is "	<< nElems	<< "\n"
			  << "file type is "		<< fileType << "\n"
			  << "file version is "		<< version	<< std::endl;

    if( !file )
        return false;

    for( int i=0; i<nElems; i++ )
    {
        int nElems, nProps;

        PlyProperty **props = 
            ply_get_element_description( file, elemNames[i], &nElems, &nProps );

		std::cout << "\n"
				  << "Element type is " << elemNames[i] << "\n"
				  << "Element number is " << nElems	  << std::endl;

        // vertices
        if( strcmp( elemNames[i], "vertex" ) == 0 )
        {
            bool color = false;
            // look for color in model
            for( int j=0; j<nProps; j++ )
                if( strcmp( props[j]->name, "red" )==0 )
                    color = true;
            
            vertices = (Vertex *)malloc( nElems * sizeof( Vertex ));
            readVertices( file, nElems, color, vertices );

            nVertices = nElems;
       }

        // faces
        else if( strcmp( elemNames[i], "face" ) == 0 )
        {
            assert( vertices );

            _faces = (Face*) malloc( nElems * sizeof( Face ));

			_nface = nElems;
            readFaces( file, vertices, nVertices, _faces, nElems );

            //free( vertices );
            //nVertices = 0;
            ply_close( file );

			std::cout << "\nply load successfully!" << std::endl;
            return true;
        }
    }

    ply_close( file );

    return false;
}

//---------------------------------------------------------------------------
// readVertices
//---------------------------------------------------------------------------
void Object::readVertices( PlyFile *file, int num, bool color, Vertex *vertices )
{
	// setup read
	int nVProps = 3;

	// C++ does not allow offsetof on non-POD types. Work around this using
	// pointer voodoo knowing that our non-POD ColorVertex is 'well-behaved'
	struct IndexVertex
	{
		float  pos[3];
		float color[3];
	} dummy;
	const int xOffset = ((char*)&dummy.pos[0] - (char*)&dummy );
	const int yOffset = ((char*)&dummy.pos[1] - (char*)&dummy );
	const int zOffset = ((char*)&dummy.pos[2] - (char*)&dummy );

	PlyProperty vProps[6] =
	{ 
            { "x", PLY_FLOAT, PLY_FLOAT, xOffset, 0, 0, 0, 0 },
            { "y", PLY_FLOAT, PLY_FLOAT, yOffset, 0, 0, 0, 0 },
            { "z", PLY_FLOAT, PLY_FLOAT, zOffset, 0, 0, 0, 0 }
        };
    char colors[3][6] = { "red", "green", "blue" };

    if( color )
    {
        for( int i=3; i<6; i++ )
        {
            vProps[i].name = colors[i-3];
            vProps[i].external_type = PLY_UCHAR;   
            vProps[i].internal_type = PLY_FLOAT;   
            
            vProps[i].is_list = 0;         
        }

        // non-POD offsets: see comment above
        const int rOffset = ((char*)&dummy.color[0] - (char*)&dummy );
        const int gOffset = ((char*)&dummy.color[1] - (char*)&dummy );
        const int bOffset = ((char*)&dummy.color[2] - (char*)&dummy );

		vProps[3].offset = rOffset;
        vProps[4].offset = gOffset;
        vProps[5].offset = bOffset;        
        nVProps = 6;
    }
    else
        nVProps = 3;

	std::cout << "Reading " << num << " vertices";

    ply_get_element_setup( file, "vertex", nVProps, vProps );

    // read vertices
    for( int i=0; i<num; i++ )
    {
        if( i%10000 == 0 )
			std::cout << ".";

        ply_get_element( file, &dummy);
		vertices[i].vPos.Set(dummy.pos[0], dummy.pos[1], dummy.pos[2]);
		vertices[i].vColor.Set(dummy.color[0], dummy.color[1], dummy.color[2]);

        if( color )
        {
			vertices[i].vColor.x /= 256.;
            vertices[i].vColor.y /= 256.;
            vertices[i].vColor.z /= 256.;
        }
        else
        {
            vertices[i].vColor.x = 1.;
            vertices[i].vColor.y = 1.;
            vertices[i].vColor.z = 1.;
        }

		// get bounding box.
		if (i == 0)
		{
			m_BBoxMin = vertices[0].vPos;
			m_BBoxMax = vertices[0].vPos;
		}
		else
		{
			Min(m_BBoxMin, m_BBoxMin, vertices[i].vPos);
			Max(m_BBoxMax, m_BBoxMax, vertices[i].vPos);
		}
    }

	rt::Vector3 bbox;
	bbox = m_BBoxMax - m_BBoxMin;
	m_fBBoxSize = bbox.Mod();

	std::cout << "\nVertices loaded successfully." << std::endl;
}


//---------------------------------------------------------------------------
// readFaces
//---------------------------------------------------------------------------
void Object::readFaces(PlyFile *file, 
                       Vertex *vertices, 
					   const int nVertices, 
                       Face* faces, 
					   const int nFaces )
{
    // setup read
    int nFProps = 1;

    struct IndexFace {
        int  nVertices;
        int* vertices;
    } face;

	FacesOfVertex* pFOV = (FacesOfVertex*) malloc (sizeof(FacesOfVertex) * nVertices);
	memset(pFOV, 0, sizeof(FacesOfVertex) * nVertices);

    PlyProperty fProps[] = {{
        "vertex_indices", PLY_INT, PLY_INT, offsetof( IndexFace, vertices ),
        1, PLY_INT, PLY_INT, offsetof( IndexFace, nVertices ) }};

	std::cout << "Reading " << nFaces << " faces";

    ply_get_element_setup( file, "face", nFProps, fProps );
            
    // read faces
	int tmpCount;
    unsigned wrongNormals = 0;
    for( int i=0; i<nFaces; i++ )
    {
        if( i%10000 == 0 )
			std::cout << ".";

        // read face
        ply_get_element( file, &face );
        assert( face.nVertices == 3 );

        // dereference face indices
        for( int j=0; j<3; j++ )
		{
			faces[i].vertIndex[j] = face.vertices[j];

			tmpCount = pFOV[face.vertices[j]].nCount;
			if (tmpCount < 10)
			{
				pFOV[face.vertices[j]].faces[tmpCount] = i;
				pFOV[face.vertices[j]].nCount++;
			}
		}
        
        // calculate normal
        if( !calculateNormal( faces[i] ))
			std::cout << "\nwrong normal!!!" << std::endl;
    }

	// compute each vertex normal.
	std::cout << "\n\nComputing vertices normals ";
	for (int i=0; i<nVertices; i++)
	{
        if( i%10000 == 0 )
			std::cout << ".";

		//calculateNormal(vertices[i], i, faces, nFaces);
		calculateNormal(pFOV[i], i);
	}

	free(pFOV);

	std::cout << "\nfaces loaded successfully." << std::endl;
}

void Object::calculateNormal(FacesOfVertex& fov, int nVertIndex)
{
	vertices[nVertIndex].vNormal.Set(0.0f, 0.0f, 0.0f);

	for (int i=0; i<fov.nCount; i++)
	{
		vertices[nVertIndex].vNormal += _faces[fov.faces[i]].vNormal;
	}

	vertices[nVertIndex].vNormal = vertices[nVertIndex].vNormal / fov.nCount;
}

//---------------------------------------------------------------------------
// calculateNormal
//---------------------------------------------------------------------------
bool Object::calculateNormal( Face& face )
{
	// N=(P0-P1)��(P0-P2)
	double ax = 1000.*vertices[face.vertIndex[0]].vPos.x - 1000.*vertices[face.vertIndex[1]].vPos.x;
    double ay = 1000.*vertices[face.vertIndex[0]].vPos.y - 1000.*vertices[face.vertIndex[1]].vPos.y;
    double az = 1000.*vertices[face.vertIndex[0]].vPos.z - 1000.*vertices[face.vertIndex[1]].vPos.z;
    
	double bx = 1000.*vertices[face.vertIndex[0]].vPos.x - 1000.*vertices[face.vertIndex[2]].vPos.x;
    double by = 1000.*vertices[face.vertIndex[0]].vPos.y - 1000.*vertices[face.vertIndex[2]].vPos.y;
    double bz = 1000.*vertices[face.vertIndex[0]].vPos.z - 1000.*vertices[face.vertIndex[2]].vPos.z;
    
	face.vNormal.Set(ay*bz - az*by, az*bx - ax*bz, ax*by - ay*bx);

	face.vNormal.Normalize();

	return true;
}

void Object::calculateNormal(Vertex& vert, int vertIndex, Face* pFaces, int nFaces)
{
	rt::Vector3	accNormal (0.0f, 0.0f, 0.0f);
	int nCount = 0;

	for (int i=0; i<nFaces; i++)
	{
		for (int j=0; j<3; j++)
			if (vertIndex == pFaces[i].vertIndex[j])
			{
				accNormal += pFaces[i].vNormal;
				nCount++;
			}
	}

	vert.vNormal = accNormal / nCount;
}

void Object::Min(rt::Vector3& vMin, rt::Vector3& va, rt::Vector3& vb)
{
	vMin.x = (va.x < vb.x) ? va.x : vb.x;
	vMin.y = (va.x < vb.y) ? va.x : vb.y;
	vMin.z = (va.x < vb.z) ? va.x : vb.z;
}

void Object::Max(rt::Vector3& vMax, rt::Vector3& va, rt::Vector3& vb)
{
	vMax.x = (va.x > vb.x) ? va.x : vb.x;
	vMax.y = (va.x > vb.y) ? va.x : vb.y;
	vMax.z = (va.x > vb.z) ? va.x : vb.z;
}