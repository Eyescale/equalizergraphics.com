
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#include "eoInitData.h"

using namespace eo;

InitData::InitData()
        : _frameDataID( EQ_UNDEFINED_UINT32 )
{
}

InitData::~InitData()
{
    setFrameDataID( EQ_ID_INVALID );
}

void InitData::getInstanceData( eqNet::DataOStream& os )
{
    os << _frameDataID;
}

void InitData::applyInstanceData( eqNet::DataIStream& is )
{
    is >> _frameDataID;

    EQASSERT( _frameDataID != EQ_ID_INVALID );
	EQINFO << "New InitData instance" << std::endl;
}