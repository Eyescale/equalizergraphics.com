
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#ifndef EO_OGRE_ROOT_H_
#define EO_OGRE_ROOT_H_

#include <Ogre/Ogre.h>

class OgreRoot : public Ogre::Root
{
public:
	OgreRoot(const Ogre::String& pluginFileName = "plugins.cfg", 
			 const Ogre::String& configFileName = "ogre.cfg", 
			 const Ogre::String& logFileName	= "Ogre.log");

protected:
	void setupResources(void);
};

#endif
