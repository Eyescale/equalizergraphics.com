
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#include <eq/eq.h>
#include "eoNode.h"
#include "eoPipe.h"
#include "eoWindow.h"
#include "eoChannel.h"
#include "eoConfig.h"

using namespace eqBase;
using namespace std;

class NodeFactory : public eq::NodeFactory
{
public:
    virtual eq::Config*  createConfig( eqBase::RefPtr< eq::Server > parent )  
    { 
		return new eo::Config( parent ); 
	}
    virtual eq::Node*    createNode( eq::Config* parent )  
    {
		return new eo::Node( parent );
	}
    virtual eq::Pipe*    createPipe( eq::Node* parent )
    {
		return new eo::Pipe( parent );
	}
    virtual eq::Window*  createWindow( eq::Pipe* parent )
    { 
		return new eo::Window( parent ); 
	}
    virtual eq::Channel* createChannel( eq::Window* parent )
    { 
		return new eo::Channel( parent );
	}
};

int main(const int argc, char** argv)
{
    // 1. Equalizer initialization
    NodeFactory nodeFactory;
    if( !eq::init( argc, argv, &nodeFactory ))
    {
        EQERROR << "Equalizer init failed" << endl;
        return EXIT_FAILURE;
    }
    
    // 2. get a configuration
    bool        error  = false;
	eo::Config* config = (eo::Config*) eq::getConfig( argc, argv );
    if( config )
    {
        // 3. init config
        if( config->init())
        {
            // 4. run main loop
            while( config->isRunning( ))
            {
                config->startFrame();
                config->finishFrame();
            }
        
            // 5. exit config
            config->exit();
        }
        else
        {
            EQERROR << "Config initialization failed: " 
                    << config->getErrorMessage() << endl;
            error = true;
        }

        // 6. release config
        eq::releaseConfig( config );
    }
    else
    {
        EQERROR << "Cannot get config" << endl;
        error = true;
    }    

    // 7. exit
    eq::exit();
    return error ? EXIT_FAILURE : EXIT_SUCCESS;
}
