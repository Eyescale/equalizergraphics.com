
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#ifndef EO_INITDATA_H_
#define EO_INITDATA_H_

#include <eq/eq.h>

namespace eo
{
	class InitData : public eqNet::Object
	{
	public:
		InitData();
		~InitData();

        void setFrameDataID( const uint32_t id )   { _frameDataID = id; }
        uint32_t           getFrameDataID() const  { return _frameDataID; }

	protected:
        virtual void getInstanceData( eqNet::DataOStream& os );
        virtual void applyInstanceData( eqNet::DataIStream& is );

    private:
        uint32_t         _frameDataID;
	};
};

#endif