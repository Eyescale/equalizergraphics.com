
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#include "ogreRoot.h"
#include "ogreFrameListener.h"

OgreRoot::OgreRoot ( const Ogre::String& pluginFileName, 
					 const Ogre::String& configFileName, 
					 const Ogre::String& logFileName)
 : Ogre::Root(pluginFileName, configFileName, logFileName)
{
	setupResources();

	restoreConfig();

	initialise(false);
}

/// Method which will define the source of resources (other than current folder)
void OgreRoot::setupResources(void)
{
	// Load resource paths from config file
	Ogre::ConfigFile cf;
	cf.load("../share/Equalizer/eqOgre/resources.cfg");

	// Go through all sections & settings in the file
	Ogre::ConfigFile::SectionIterator seci = cf.getSectionIterator();

	Ogre::String secName, typeName, archName;
	while (seci.hasMoreElements())
	{
		secName = seci.peekNextKey();
		Ogre::ConfigFile::SettingsMultiMap *settings = seci.getNext();
		Ogre::ConfigFile::SettingsMultiMap::iterator i;
		for (i = settings->begin(); i != settings->end(); ++i)
		{
			typeName = i->first;
			archName = i->second;

			Ogre::ResourceGroupManager::getSingleton().addResourceLocation(
				archName, typeName, secName);
		}
	}
}