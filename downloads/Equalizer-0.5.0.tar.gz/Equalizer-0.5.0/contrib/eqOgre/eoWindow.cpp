
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#include "eoWindow.h"

#include "eoNode.h"
#include "eoPipe.h"
#include "ogPlyMesh.h"
#include "OgreRoot.h"
#include "tinyxml/tinyxml.h"

namespace eo
{
Window::Window( eq::Pipe* parent )
        : eq::Window( parent )
        , OgreWindow( &static_cast< Node* >( getNode( ))->getRoot( ))
{
}

bool Window::configInit( const uint32_t initID )
{
	// create os specific on-screen window and 
	// initialize generic OpenGL state.
    if( !eq::Window::configInit( initID ))
        return false;

	// setup data to be shared in the pipe.
	// the first window create all data and the mananger.
	// other windows use the first window's manager.
	eo::Pipe*  pipe        = static_cast< eo::Pipe*> ( getNode()->getPipes()[0] );
    Window*    firstWindow = static_cast< Window* >( pipe->getWindows()[0] );

    if( firstWindow == this )
	{
		// just setup ogre scene.
		if (!setup())
		{
			setErrorMessage( "Ogre setup failed" );
			return false;
		}

		mFrameListener->setConfig( static_cast< eo::Config*> (getConfig()) );
    }
	else
	{
		if (!createWindow())
		{
			setErrorMessage( "Ogre setup failed" );
			return false;
		}

		_sceneManager = _ogreRoot->getSceneManager("ExampleSMInstance"); 
		_camera = _sceneManager->getCamera("PlayerCam");

		// Create one viewport, entire window
		createViewports();
	}
}

bool Window::configExit()
{
    return eq::Window::configExit();
}

bool Window::createWindow()
{
    Node*                  node         = static_cast< Node* >( getNode( ));
    OgreRoot&              root         = node->getRoot();
    const eq::WindowSystem windowSystem = getPipe()->getWindowSystem();
    const unsigned         parentWnd    =
        windowSystem == eq::WINDOW_SYSTEM_WGL ? (unsigned)getWGLWindowHandle() :
        windowSystem == eq::WINDOW_SYSTEM_AGL ? (unsigned)getCarbonWindow() :
        windowSystem == eq::WINDOW_SYSTEM_GLX ? (unsigned)getXDrawable() : 0;
    
	if( parentWnd )
	{
		NameValuePairList params; // typedef std::map<std::string,std::string>

		// get window's parent handler and create contex absolutely.
		params["externalWindowHandle"] = StringConverter::toString( parentWnd );
		params["externalGLControl"]    = StringConverter::toString( 1 );

        const eq::PixelViewport& pvp  = getPixelViewport();

		// get the pointer as its unique name.
		char name[32];
		sprintf(name, "%d", this);

		// create window by size of pvp.
		_ogreWindow = root.createRenderWindow( name, pvp.w, pvp.h, false,
                                               &params );
	}
	else
        _ogreWindow = root.getAutoCreatedWindow();

	return true;
}

using namespace eo;

void Window::render()
{
	_ogreWindow->update(false);
}

// destroy scene
void Window::release()
{
	destroyScene();
}

void Window::setupPlyMesh()
{
	std::string strEnt;

	// load mesh 1.
	strEnt.assign("rockerArm");
	PlyMesh	plyMesh(strEnt.data(), "..\\models\\rockerArm.ply");

	Entity* thisEntity = _sceneManager->createEntity(strEnt, strEnt);
	thisEntity->setCastShadows( true );
	thisEntity->setMaterialName(strEnt);

	SceneNode* thisSceneNode = _sceneManager->getRootSceneNode()->createChildSceneNode();
	thisSceneNode->setPosition(0, 130, 0);
	thisSceneNode->pitch(Radian(Degree(-90)));
	thisSceneNode->roll(Radian(Degree(-90)));
	thisSceneNode->attachObject(thisEntity);
}

void Window::setupLights()
{
	Light *light;

	light = _sceneManager->createLight( "Light1" );
	light->setType( Light::LT_POINT );
	light->setPosition( Vector3(0, 150, 250) );

	light->setDiffuseColour( 0.5, 0.5, 0.3 );
	light->setSpecularColour( 0.5, 0.5, 0.3 );

	light = _sceneManager->createLight( "Light3" );
	light->setType( Light::LT_DIRECTIONAL );
	light->setDiffuseColour( ColourValue( .45, .45, .45 ) );
	light->setSpecularColour( ColourValue( .35, .35, .35 ) );
	light->setDirection( Vector3( 1, -1, 0 ) ); 

	light = _sceneManager->createLight( "Light2" );
	light->setType( Light::LT_SPOTLIGHT );
	light->setDiffuseColour( 0, 0.2, 1.0 );
	light->setSpecularColour( 0, 0.2, 1.0 );

	light->setDirection( 1, -1, 1 );
	light->setPosition( Vector3( -100, 100, -100 ) );

	light->setSpotlightRange( Degree(35), Degree(50) );
}

void Window::createScene(void)
{
	setupPlyMesh();

	Entity *ent;

	_sceneManager->setAmbientLight( ColourValue( 0, 0, 0 ) );

	_sceneManager->setShadowTechnique( SHADOWDETAILTYPE_TEXTURE );

	Plane plane( Vector3::UNIT_Y, 0 );
	MeshManager::getSingleton().createPlane("ground",
		ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME, plane,
		1500,1500,20,20,true,1,5,5,Vector3::UNIT_Z);
	ent = _sceneManager->createEntity( "groundEntity", "ground" );
	_sceneManager->getRootSceneNode()->createChildSceneNode()->attachObject(ent);

	ent->setMaterialName("Examples/Rockwall");

	ent->setCastShadows(false);

	setupLights();
}

void Window::setViewport(float left, float top, float width, float height)
{
	if (_ogreWindow->getNumViewports() <= 0)
		return;

	Ogre::Viewport* vp = _ogreWindow->getViewport(0);

	vp->setDimensions(  Ogre::Real(left),
						Ogre::Real(top),
						Ogre::Real(width),
						Ogre::Real(height) );
}

void Window::setFrustum(const vmml::mat4f& mat)
{
    Ogre::Matrix4 projMat;

	for (int i=0; i<4; i++)
		for (int j=0; j<4; j++)
			projMat[i][j] = mat.getElement(i, j);

	_camera->setCustomProjectionMatrix(true, projMat);
}
}
