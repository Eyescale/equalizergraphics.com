
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#ifndef EO_PIPE_H_
#define EO_PIPE_H_

#include <eq/eq.h>
#include "eoFrameData.h"

namespace eo
{
	class Pipe : public eq::Pipe
	{
	public:
        Pipe( eq::Node* parent ) : eq::Pipe( parent ) {}
        const FrameData& getFrameData() const { return _frameData; }

	protected:
        virtual ~Pipe() {}

        virtual bool configInit( const uint32_t initID );
        virtual bool configExit();
        virtual void frameStart( const uint32_t frameID, 
                                 const uint32_t frameNumber );

	private:
        FrameData			_frameData;
	};
};

#endif
