
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#include "eoConfig.h"
#include "eoFrameEvent.h"

using namespace eo;

Config::Config( eqBase::RefPtr< eq::Server > parent )
        : eq::Config( parent )
{
}

bool Config::init()
{
    // init distributed objects
    registerObject( &_frameData );

    _initData.setFrameDataID( _frameData.getID( ));
    registerObject( &_initData );

    // init config
    if( !eq::Config::init( _initData.getID( )))
        return false;

	return true;
}

bool Config::exit()
{
    const bool ret = eq::Config::exit();

    _initData.setFrameDataID( EQ_ID_INVALID );
    deregisterObject( &_initData );
    deregisterObject( &_frameData );

    return ret;
}

uint32_t Config::startFrame()
{
    // update database
    const uint32_t version = _frameData.commit();

    return eq::Config::startFrame( version );
}

bool Config::handleEvent( const eq::ConfigEvent* event )
{
    if( eq::Config::handleEvent( event ))
        return true;

    switch( event->data.type )
    {
		case eo::OgreEvent::FRAMELISTENER:
			_frameData.data.mTranslateVector = ((eo::OgreEvent*)event)->_camTranslate;
			_frameData.data.mRotX = ((eo::OgreEvent*)event)->_cameraRotateX;
			_frameData.data.mRotY = ((eo::OgreEvent*)event)->_cameraRotateY;
			break;

        default:
            break;
    }

    return eq::Config::handleEvent( event );
}
