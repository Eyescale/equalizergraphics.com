
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */


#ifndef EO_OGRE_FRAMEVENT_H
#define EO_OGRE_FRAMEVENT_H

#include <eq/eq.h>

namespace eo
{
struct OgreEvent : public eq::ConfigEvent
{
public:
    enum Type
    {
        FRAMELISTENER = eq::ConfigEvent::USER
    };

    OgreEvent()
        {
            size = sizeof( OgreEvent );
        }

	float			_cameraRotateX;
	float			_cameraRotateY;
	vmml::Vector3f	_camTranslate;
};

};

#endif // EO_OGRE_FRAMEVENT_H

