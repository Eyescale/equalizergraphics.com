
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#ifndef EO_CHANNEL_H_
#define EO_CHANNEL_H_

#include <eq/eq.h>
#include <Ogre/Ogre.h>

namespace eo
{
	class Channel : public eq::Channel
	{
	public:
        Channel( eq::Window* parent ) : eq::Channel( parent ) {}

    protected:
        virtual ~Channel(){}

		virtual void frameDraw( const uint32_t frameID );
	};
};

#endif
