#ifndef PLYFACE_H_
#define PLYFACE_H_

#include "rtVector3.h"

namespace ply
{
	class Vertex
	{
	public:
		rt::Vector3		vPos;
		rt::Vector3		vNormal;
		rt::Vector3		vColor;


	};

	class Face
	{
	public:
		int				vertIndex[3];
		//Vertex			vert[3];
		rt::Vector3		vNormal;
	};
}

#endif