
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#ifndef EO_NODE_H_
#define EO_NODE_H_

#include "eoInitData.h"
#include "ogreRoot.h"

#include <eq/eq.h>
#include <Ogre/Ogre.h>

class OgreRoot;

namespace eo
{

	class Node : public eq::Node
	{
	public:
        Node( eq::Config* parent );

        const InitData& getInitData() const { return _initData; }
		OgreRoot& getRoot() {return _ogreRoot;}

	protected:
        virtual bool configInit( const uint32_t initID );
		virtual bool configExit();
        virtual void frameStart( const uint32_t frameID, 
                                 const uint32_t frameNumber );
        virtual void frameDrawFinish( const uint32_t frameID,
                                      const uint32_t frameNumber )
            { /* nop, see frameStart */ }

	protected:
		OgreRoot		_ogreRoot;

	private:
        InitData		_initData;
	};
};

#endif
