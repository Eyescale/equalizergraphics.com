
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#ifndef EO_CONFIG_H_
#define EO_CONFIG_H_

#include <eq/eq.h>
#include "eoFrameData.h"
#include "eoInitData.h"

namespace eo
{
	class Config : public eq::Config
	{
	public:
		Config( eqBase::RefPtr< eq::Server > parent );

        virtual bool init();
        virtual bool exit();

        virtual uint32_t startFrame();

	protected:
        virtual bool handleEvent( const eq::ConfigEvent* event );

		InitData		_initData;
		FrameData		_frameData;
	};
};

#endif
