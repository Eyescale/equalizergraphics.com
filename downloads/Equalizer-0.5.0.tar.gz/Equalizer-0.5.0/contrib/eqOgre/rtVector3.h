#ifndef RTVECTOR_H_
#define RTVECTOR_H_

#include "common.h"
#include <math.h>

namespace rt
{

	class Vector3
	{
	public:
		Vector3 () {};
		Vector3 (const rtFloat fx, const rtFloat fy, const rtFloat fz) 
		{
			x = fx;
			y = fy;
			z = fz;
		}

		Vector3 (const Vector3& vec)
		{
			x = vec.x;
			y = vec.y;
			z = vec.z;
		}

		Vector3& operator= (const Vector3& right)
		{
			x = right.x;
			y = right.y;
			z = right.z;

			return *this;
		}

		Vector3& operator+= (const Vector3& right)
		{
			x += right.x;
			y += right.y;
			z += right.z;

			return *this;
		}

		const Vector3& operator- (const Vector3& left) const
		{
			static Vector3 tmp;

			tmp.x = x - left.x;
			tmp.y = y - left.y;
			tmp.z = z - left.z;

			return tmp;
		}

		const Vector3& operator/ (const float right) const
		{
			static Vector3 tmp;

			tmp.x = x / right;
			tmp.y = y / right;
			tmp.z = z / right;

			return tmp;
		}

		void Set(const rtFloat fx, const rtFloat fy, const rtFloat fz)
		{
			x = fx;
			y = fy;
			z = fz;
		}

		rtFloat Mod2()
		{
			return x*x + y*y + z*z;
		}

		rtFloat Mod()
		{
			return sqrtf(Mod2());
		}

		Vector3& Normalize()
		{
			rtFloat mod = Mod();

			if (mod == 0)
			{
				x = 0;
				y = 0;
				z = 1;
			}
			else
			{
				x = x/mod;
				y = y/mod;
				z = z/mod;
			}

			return *this;
		}

	public:
		rtFloat		x;
		rtFloat		y;
		rtFloat		z;
	};
};

#endif