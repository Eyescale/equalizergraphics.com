
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#ifndef EO_WINDOW_H_
#define EO_WINDOW_H_

#include "ogreWindow.h"

#include <eq/eq.h>
#include <Ogre/Ogre.h>

namespace eo
{
    class Window : public eq::Window, public OgreWindow
	{
	public:
		Window( eq::Pipe* parent );

		// render one frame.
		void render();
		// destroy scene
		void release();

		void setViewport(float left, float top, float width, float height);
		void setFrustum(const vmml::mat4f& mat);

		float getNearDist() const { return _camera->getNearClipDistance(); }
		float getFarDist()  const { return _camera->getFarClipDistance(); }

	protected:
		virtual bool createWindow(void);

		virtual bool configInit( const uint32_t initID );
		virtual bool configExit();

		virtual void createScene(void);

	private:
		void setupPlyMesh();
		void setupLights();
	};
};

#endif
