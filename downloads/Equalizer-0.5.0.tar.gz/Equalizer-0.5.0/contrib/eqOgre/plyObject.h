#ifndef PLYOBJECT_H_
#define PLYOBJECT_H_

#include "ply.h"
#include <vector>
#include "rtVector3.h"
#include "plyFace.h"

#include <string>

namespace ply
{
	class Object
	{
	typedef struct FacesOfVertex {
		int	nCount;
		int faces[10];
	} FacesOfVertex;

	public:
		Object();
		~Object();

		bool readPly( const char *filename );

		bool readFile (const char *filename);
		bool readBin (const char *filename);
		void writeBin (const char *filename);

		Face* getFace() {return _faces;}
		int getFaceNum() {return _nface;}

		rtFloat getBBoxSize() {return m_fBBoxSize;}

		int getVerticesNum() { return nVertices;}
		Vertex* getVertices() { return vertices; }

	private:

		void readVertices( PlyFile *file, int num, bool color, Vertex *vertices );
		void readFaces(	PlyFile *file, 
						Vertex *vertices, 
						const int nVertices, 
						Face* faces, 
						const int nFaces );
		bool calculateNormal( Face& face );
		void calculateNormal(Vertex& vert, int vertIndex, Face* pFaces, int nFaces);
		void calculateNormal(FacesOfVertex& fov, int nVertIndex);

		void Min(rt::Vector3& vMin, rt::Vector3& va, rt::Vector3& vb);
		void Max(rt::Vector3& vMax, rt::Vector3& va, rt::Vector3& vb);

		std::string		m_strName;

		Face*			_faces;
		int				_nface;

		Vertex			*vertices;
		int				nVertices;

		rt::Vector3		m_BBoxMin;
		rt::Vector3		m_BBoxMax;

		rtFloat			m_fBBoxSize;
	};
}
#endif
