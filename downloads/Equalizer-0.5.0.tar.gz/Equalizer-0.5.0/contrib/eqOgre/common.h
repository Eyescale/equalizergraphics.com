#ifndef COMMON_H_
#define COMMON_H_

typedef  float rtFloat;


#endif