
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#include "eoNode.h"
#include "ogreRoot.h"
#include "eoFrameData.h"
#include "eoConfig.h"

namespace eo
{
Node::Node( eq::Config* parent )
        : eq::Node( parent )
        , _ogreRoot( "plugins.cfg", "../share/Equalizer/ogre.cfg", "Ogre.log" )
{}

bool Node::configInit( const uint32_t initID )
{
    eq::Config* config = getConfig();
    const bool  mapped = config->mapObject( &_initData, initID );
    EQASSERT( mapped );

    return eq::Node::configInit( initID );
}

bool Node::configExit()
{
    eq::Config* config = getConfig();
    config->unmapObject( &_initData );

    return eq::Node::configExit();
}

void Node::frameStart( const uint32_t frameID, const uint32_t frameNumber ) 
{
	// ogre's event responds.
	_ogreRoot._fireFrameStarted();

	// start rendering.
	startFrame( frameNumber ); 

	// ogre's event responds.
	_ogreRoot._fireFrameEnded();

    // Don't wait for pipes to release frame locally, sync not needed since all
    // dynamic data is multi-buffered
    releaseFrameLocal( frameNumber );
}
}
