
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#ifndef OGRE_PLY_MESH_H_
#define OGRE_PLY_MESH_H_

#include "plyObject.h"

#include <Ogre/Ogre.h>
#include <string>

namespace Ogre
{
	class PlyMesh
	{
	public:
		PlyMesh(const char* filename);
		PlyMesh(const char* meshName, const char* filename);

		Ogre::MeshPtr getMeshPrt()	{ return m_MeshPtr; }

		std::string&  getMeshName() { return m_strMeshName; }
		std::string&  getMatName()  { return m_strMatName; }
		
		void SetLoadScale(float fScale) { m_fLoadScale = fScale; }

	private:
		Ogre::MeshPtr createPlyMesh (ply::Object& plyObj);
		Ogre::MeshPtr createColourCube();

		void createMaterial();

	protected:
		Ogre::MeshPtr		m_MeshPtr;

		float				m_fLoadScale;

		std::string			m_strMeshName;
		std::string			m_strMatName;
	};
};

#endif
