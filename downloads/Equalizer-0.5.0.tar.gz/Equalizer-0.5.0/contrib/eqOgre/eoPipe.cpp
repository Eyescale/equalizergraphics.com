
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#include "eoPipe.h"
#include "eoConfig.h"
#include "eoNode.h"

using namespace eo;

bool Pipe::configInit( const uint32_t initID )
{
	const eo::Node*     node    = static_cast<eo::Node*>( getNode( ));
	const InitData& initData    = node->getInitData();
	const uint32_t  frameDataID = initData.getFrameDataID();
	eo::Config*     config      = (eo::Config*) getConfig();

	const bool mapped = config->mapObject( &_frameData, frameDataID );
	EQASSERT( mapped );

	return eq::Pipe::configInit( initID );
}

bool Pipe::configExit()
{
    eq::Config* config = getConfig();
    config->unmapObject( &_frameData );

    return eq::Pipe::configExit();
}

void Pipe::frameStart( const uint32_t frameID, const uint32_t frameNumber )
{
    _frameData.sync( frameID );
    startFrame( frameNumber );
}