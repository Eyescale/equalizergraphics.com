
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#include "ogreWindow.h"
#include <Ogre/OgreConfigFile.h>

using namespace Ogre;

OgreWindow::OgreWindow(Root* pRoot)
		: _ogreWindow( 0 )
        , _sceneManager( 0 )
{
	mFrameListener = 0;

	_ogreRoot = pRoot;
}

OgreWindow::~OgreWindow()
{
	destroyScene();

	if (mFrameListener)
	{
		delete mFrameListener;
		mFrameListener = 0;
	}
}

bool OgreWindow::setup(void)
{
	createWindow();

	// Load resources
	loadResources();

	// Set default mipmap level (NB some APIs ignore this)
	TextureManager::getSingleton().setDefaultNumMipmaps(5);

	chooseSceneManager();
	createCamera();
	createViewports();

	// Create the scene
	createScene();

	createFrameListener();

	return true;
}

void OgreWindow::chooseSceneManager(void)
{
	// Create the SceneManager, in this case a generic one
	_sceneManager = _ogreRoot->createSceneManager(ST_GENERIC, "ExampleSMInstance");
}

void OgreWindow::createCamera(void)
{
	// Create the camera
	_camera = _sceneManager->createCamera("PlayerCam");

	// Position it at 500 in Z direction
	_camera->setPosition(Vector3(-100,120,300));
	// Look back along -Z
	_camera->lookAt(Vector3(0,0,-300));
	_camera->setNearClipDistance(5);

}

void OgreWindow::createFrameListener(void)
{
	mFrameListener= new OgreFrameListener(_ogreWindow, _camera);
	mFrameListener->showDebugOverlay(true);
	_ogreRoot->addFrameListener(mFrameListener);
}

void OgreWindow::createViewports(void)
{
	// Create one viewport, entire window
	Viewport* vp = _ogreWindow->addViewport(_camera);
	vp->setBackgroundColour(ColourValue(0,1,0));

	// Alter the camera aspect ratio to match the viewport
	_camera->setAspectRatio(
		Real(vp->getActualWidth()) / Real(vp->getActualHeight()));
}

void OgreWindow::loadResources(void)
{
	// Initialise, parse scripts etc
	ResourceGroupManager::getSingleton().initialiseAllResourceGroups();
}
