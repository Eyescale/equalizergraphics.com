
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#ifndef OGREWINDOW_H_
#define OGREWINDOW_H_

#include <Ogre/Ogre.h>
#include "ogreFrameListener.h"

namespace Ogre
{

	class OgreWindow
	{
	public:
		OgreWindow(Root* pRoot);
		virtual ~OgreWindow();

		Camera*					getCamera() { return _camera; }

	protected:
		Root*					_ogreRoot;

        Ogre::RenderWindow*		_ogreWindow;
        Ogre::SceneManager*		_sceneManager;
        Ogre::Camera*			_camera;

		OgreFrameListener*		mFrameListener;

		// These internal methods package up the stages in the startup process
		/** Sets up the application - returns false if the user chooses to abandon configuration. */
		virtual bool setup(void);

		void createCamera(void);

		void chooseSceneManager(void);

		/** Configures the application - returns false if the user chooses to abandon configuration. */
		virtual bool createWindow(void) = 0;

		virtual void createFrameListener(void);

		virtual void createScene(void) = 0;    // pure virtual - this has to be overridden

		virtual void destroyScene(void){}    // Optional to override this

		virtual void createViewports(void);

		/// Optional override method where you can perform resource group loading
		/// Must at least do ResourceGroupManager::getSingleton().initialiseAllResourceGroups();
		virtual void loadResources(void);
	};

};

#endif
