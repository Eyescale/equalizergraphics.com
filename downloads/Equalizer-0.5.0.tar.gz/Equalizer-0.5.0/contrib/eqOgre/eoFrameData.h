
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#ifndef EO_FRAMEDATA_H_
#define EO_FRAMEDATA_H_

#include <eq/eq.h>

namespace eo
{
	class FrameData : public eqNet::Object
	{
	public:
        FrameData()
            {
                reset();
                setInstanceData( &data, sizeof( Data ));
                EQINFO << "New FrameData " << std::endl;
            }

        void reset()
            {
                data.mTranslateVector   = vmml::Vector3f::ZERO;
                data.mRotX = 0.0f;
                data.mRotY = 0.0f;
            }

        struct Data
        {
			float			mRotX;
			float			mRotY;

			vmml::Vector3f	mTranslateVector;
        } data;
    
    protected:
        virtual ChangeType getChangeType() const { return INSTANCE; }
	};
};

#endif
