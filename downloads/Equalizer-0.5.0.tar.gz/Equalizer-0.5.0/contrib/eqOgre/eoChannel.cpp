
/* Copyright (c) 2007-2008, Rick Arkin <rick.changhui@gmail.com> 
   All rights reserved. */

#include "eoChannel.h"
#include "eoWindow.h"
#include "eoPipe.h"
#include "eoFrameData.h"

namespace eo
{

void Channel::frameDraw( const uint32_t frameID )
{
	eo::Window* pWin = (eo::Window*)getWindow();

    // setup ogre viewport as eqserver's config.
    eq::PixelViewport pvp	 = getPixelViewport();
	eq::Viewport	  vp	 = getViewport();
    eq::PixelViewport winPvp = pWin->getPixelViewport();

	// eq::Channel's pixel viewport is defind by bottow-left point, (0, 0) is the bottom-left corner.
	// ogre viewport is defind by top-left point, and (0, 0) is the top-left corner.
	// That need a conversion from eq::Channel to ogre viewport, (y = h - x).
    pWin->setViewport((float)pvp.x/(float)winPvp.w, 
					  1.0f - (float)(pvp.h + pvp.y)/(float)winPvp.h,
					  (float)pvp.w/(float)winPvp.w, 
					  (float)pvp.h/(float)winPvp.h);

    // setup ogre frustum as eq.
    setNearFar(pWin->getNearDist(), pWin->getFarDist());
    vmml::Frustumf frust = getFrustum();
	pWin->setFrustum(frust.computeMatrix());

    // setup viewmat.
    Pipe*      pipe      = static_cast<Pipe*>( getPipe( ));
    Ogre::Vector3 relVec(	pipe->getFrameData().data.mTranslateVector.x,
                            pipe->getFrameData().data.mTranslateVector.y,
                            pipe->getFrameData().data.mTranslateVector.z);
    const Ogre::Radian tmpYaw(pipe->getFrameData().data.mRotX);
    const Ogre::Radian tmpPitch(pipe->getFrameData().data.mRotY);

    pWin->getCamera()->moveRelative(relVec);
    pWin->getCamera()->yaw(tmpYaw);
    pWin->getCamera()->pitch(tmpPitch);

    // render one frame.
    pWin->render();
}
}
