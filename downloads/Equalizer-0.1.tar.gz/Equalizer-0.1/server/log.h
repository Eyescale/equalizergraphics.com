
/* Copyright (c) 2006, Stefan Eilemann <eile@equalizergraphics.com> 
   All rights reserved. */

#ifndef EQS_LOG_H
#define EQS_LOG_H

#include <eq/client/log.h>

namespace eqs
{
    enum LogTopics
    {
        LOG_TASKS    = eq::LOG_CUSTOM,
        LOG_ASSEMBLY
    };
}
#endif // EQS_LOG_H
