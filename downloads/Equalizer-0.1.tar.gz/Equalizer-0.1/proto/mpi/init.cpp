
// Prototype to test MPI initialization w/o the usage of mpirun

