Collage
=======

Cross-platform C++ library for building heterogenous, distributed applications.

![Dependencies](http://eyescale.github.com/images/Collage.png "Collage Dependencies")