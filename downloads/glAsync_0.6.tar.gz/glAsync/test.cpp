// g++ -o test -I/usr/X11R6/include test.cpp glAsync.cpp -L/usr/X11R6/lib -lGL -lX11

#include "glAsync.h"

#include <X11/X.h>
#include <GL/glx.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#define TEXTURE_SIZE (1024)

#define TD( base, time )              \
 (((double)(time.tv_sec)  - (double)(base.tv_sec))  * 1000. +  \
  ((double)(time.tv_usec) - (double)(base.tv_usec)) / 1000. )

static Bool WaitForNotify(Display *, XEvent *e, char *arg)
{
    return (e->type == MapNotify) && (e->xmap.window == (::Window)arg);
}

XID createWindow( Display* display, int size[4] )
{
    int screen = DefaultScreen( display );
    XID parent = RootWindow( display, screen );
 
    if( size[2] == -1 ) size[2] = DisplayWidth( display, screen ) - size[0];
    if( size[3] == -1 ) size[3] = DisplayHeight( display, screen ) - size[1];

    int attributes[100], *aptr=attributes;    
    *aptr++ = GLX_RGBA;
    *aptr++ = 1;
    *aptr++ = GLX_RED_SIZE;
    *aptr++ = 8;
    //*aptr++ = GLX_ALPHA_SIZE;
    //*aptr++ = 1;
    *aptr++ = GLX_DEPTH_SIZE;
    *aptr++ = 1;
    *aptr++ = GLX_STENCIL_SIZE;
    *aptr++ = 8;
    *aptr++ = GLX_DOUBLEBUFFER;
    *aptr = None;

    XVisualInfo *visInfo = glXChooseVisual( display, screen, attributes );
    if ( !visInfo )
        fprintf( stderr, "Error: can't allocate GLX-resources\n" );

    XSetWindowAttributes wa;
    wa.colormap = XCreateColormap( display, parent,
        visInfo->visual, AllocNone );
    wa.background_pixmap = None;
    wa.border_pixel = 0;
    wa.event_mask = StructureNotifyMask | VisibilityChangeMask;
    wa.override_redirect = True;

    XID drawable = XCreateWindow( display, parent,
        size[0], size[1], size[2], size[3], 0,
        visInfo->depth, InputOutput, visInfo->visual,
        CWBackPixmap|CWBorderPixel|CWEventMask|CWColormap,
        &wa );
    
    XMapWindow( display, drawable );

    // wait for MapNotify event
    XEvent event;

    XIfEvent( display, &event, WaitForNotify, (XPointer)drawable );
    XFlush( display );

    GLXContext context = NULL;
    while ( !context )
        context = glXCreateContext( display, visInfo, NULL, True );
    glXMakeCurrent( display, drawable, context );
    
    // get window size
    glGetIntegerv(GL_VIEWPORT, size);

    // init glAsync library
    bool ret = glAsync::XMapContext( display, visInfo, context );
    assert( ret );
    ret = glAsync::XMakeCurrent( display, context );
    assert( ret );

    return drawable;
}    

void draw()
{
    int    nQuads = 500;
    glBegin( GL_QUADS );
    while( nQuads-- )
    {
        glTexCoord2f( 0., 0. );
        glVertex3f( .1, .1, -.5 );
        
        glTexCoord2f( 1., 0. );
        glVertex3f( .9, .1, -.5 );
        
        glTexCoord2f( 1., 1. );
        glVertex3f( .9, .9, -.5 );
        
        glTexCoord2f( 0., 1. );
        glVertex3f( .1, .9, -.5 );
    }
    glEnd();
}

int main( int argc, char *argv[] )
{
    int windowSize[] = { 0, 0, -1, -1 };

    Display *display  = XOpenDisplay( NULL );
    XID      drawable = createWindow( display, windowSize );
    
    // memory buffer for textures
    char *buffer[2];
    const size_t size = TEXTURE_SIZE * TEXTURE_SIZE * 4;

    buffer[0] = (char *)malloc( size );
    buffer[1] = (char *)malloc( size );
    memset( buffer[0], 64, size );
    memset( buffer[1], 192, size );

    fprintf( stderr, "\n     OpenGL renderer string: %s\n",
	     glGetString( GL_RENDERER ) );
    fprintf( stderr, "     Window Geometry: %dx%d+%d+%d\n\n", 
	     windowSize[2], windowSize[3], windowSize[0], windowSize[1] );

    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    glOrtho( 0, 1, 0, 1, 0.1, 1 );

    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();
    
    glClearColor( 1, 0, 0, 1 );
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glXSwapBuffers( display, drawable );

    GLuint textures[2];
    GLuint markers[2] = { 0, 0 };
    int    which = 0;

    glGenTextures( 2, textures );
    glEnable( GL_TEXTURE_2D );
    glDisable( GL_LIGHTING );
    glDisable( GL_DEPTH_TEST );
    glColor3f( 0, 1, 0 );

    glBindTexture( GL_TEXTURE_2D, textures[0] );
    glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
    glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );

    glBindTexture( GL_TEXTURE_2D, textures[1] );
    glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
    glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );

    struct timeval res;
    struct timeval base;

    size_t nFrames = 0;
    gettimeofday(&base,0);
    gettimeofday(&res,0);

    // synchronous texture download pass
    while( TD( base, res ) < 10000. )
    {
        which = !which;
        
        glBindTexture( GL_TEXTURE_2D, textures[which] );
        glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA8, TEXTURE_SIZE, TEXTURE_SIZE,
                      0, GL_RGBA, GL_UNSIGNED_BYTE, buffer[which] );
        
        glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
        draw();
        
        glXSwapBuffers( display, drawable );
        gettimeofday(&res,0);
        nFrames++;
    }

    const float syncFPS = nFrames * 1000. / TD( base, res );
        
    nFrames = 0;
    gettimeofday(&base,0);
    gettimeofday(&res,0);

    // asynchronous texture download
    glAsync::bindTexture( GL_TEXTURE_2D, textures[which] );
    markers[which] = glAsync::texImage2D( GL_TEXTURE_2D, 0, GL_RGBA8, 
                                          TEXTURE_SIZE, TEXTURE_SIZE, 0, 
                                          GL_RGBA, GL_UNSIGNED_BYTE,
                                          buffer[which] );
        
    while( TD( base, res ) < 10000. )
    {
        which = !which;
        glAsync::bindTexture( GL_TEXTURE_2D, textures[which] );
        markers[which] = glAsync::texImage2D( GL_TEXTURE_2D, 0, GL_RGBA8, 
                                              TEXTURE_SIZE, TEXTURE_SIZE,
                                              0, GL_RGBA, GL_UNSIGNED_BYTE,
                                              buffer[which] );
        
        glAsync::finish( markers[!which] );
        glBindTexture( GL_TEXTURE_2D, textures[!which] );
            
        glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
        draw();
        
        glXSwapBuffers( display, drawable );
        gettimeofday(&res,0);
        nFrames++;
    }
    // since we have one texture download pending, draw an additional frame
    // to get a fair comparison to the synchronous case
    glAsync::finish( markers[which] );
    glBindTexture( GL_TEXTURE_2D, textures[which] );
        
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    draw();
        
    glXSwapBuffers( display, drawable );
    gettimeofday(&res,0);
    nFrames++;

    const float asyncFPS = nFrames * 1000. / TD( base, res );

    fprintf( stderr, " synchronous %f fps, async %f fps, speedup %d%%\n", 
             syncFPS, asyncFPS, (int)(asyncFPS/syncFPS * 100 - 100) );

    exit( EXIT_SUCCESS );
}
