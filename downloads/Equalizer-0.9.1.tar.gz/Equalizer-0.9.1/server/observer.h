
/* Copyright (c) 2009-2010, Stefan Eilemann <eile@equalizergraphics.com> 
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License version 2.1 as published
 * by the Free Software Foundation.
 *  
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef EQSERVER_OBSERVER_H
#define EQSERVER_OBSERVER_H

#include "types.h"
#include "observerVisitor.h"    // used in inline method

#include <eq/client/eye.h>      // enum
#include <eq/client/observer.h> // base class
#include <string>

namespace eq
{
namespace server
{
    struct ObserverPath;

    /**
     * The observer. @sa eq::Observer
     */
    class Observer : public eq::Observer
    {
    public:
        /** 
         * Constructs a new Observer.
         */
        Observer();

        /** Creates a new, deep copy of a observer. */
        Observer( const Observer& from, Config* config );

        /** Destruct this observer. */
        virtual ~Observer();

        /**
         * @name Data Access
         */
        //@{
        /** @return the index path to this observer. */
        ObserverPath getPath() const;

        /** @return the position of an eye in world-space coordinates. */
        const Vector3f& getEyePosition( const eq::Eye eye ) const
            { return _eyes[ eye ]; }

        /** @return the inverse of the current head matrix. */
        const Matrix4f& getInverseHeadMatrix() const
            { return _inverseHeadMatrix; }

        /** @return the config of this observer. */
        Config* getConfig() { return _config; }
        //@}

        /**
         * @name Operations
         */
        //@{
        /** Initialize the observer parameters. */
        void init();

        /** 
         * Traverse this observer using a observer visitor.
         * 
         * @param visitor the visitor.
         * @return the result of the visitor traversal.
         */
        VisitorResult accept( ObserverVisitor& visitor )
            { return visitor.visit( this ); }
        VisitorResult accept( ObserverVisitor& visitor ) const
            { return visitor.visit( this ); }

        /** Unmap this observer and all its children. */
        void unmap();
        //@}
        
    protected:
        /** @sa Object::deserialize */
        virtual void deserialize( net::DataIStream& is, 
                                  const uint64_t dirtyBits );

    private:
        virtual void getInstanceData( net::DataOStream& os );

        /** The parent Config. */
        Config* _config;
        friend class Config;

        /** Cached inverse head matrix. */
        Matrix4f _inverseHeadMatrix;

        /** The eye positions in world space. */ 
        Vector3f _eyes[eq::EYE_ALL];

        union // placeholder for binary-compatible changes
        {
            char dummy[64];
        };

        void _updateEyes();
    };
}
}
#endif // EQSERVER_OBSERVER_H
