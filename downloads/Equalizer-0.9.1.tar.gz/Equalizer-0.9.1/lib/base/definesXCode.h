#ifndef EQ_DEFINES_H
#define EQ_DEFINES_H
#ifndef AGL
#  define AGL
#endif
#ifndef Darwin
#  define Darwin
#endif
#ifndef GLEW_MX
#  define GLEW_MX
#endif
#ifndef GLX
#  define GLX
#endif
#ifndef LEOPARD
#  define LEOPARD
#endif
#endif // EQ_DEFINES_H
